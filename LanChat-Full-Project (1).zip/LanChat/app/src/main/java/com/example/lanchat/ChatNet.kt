package com.example.lanchat

import android.content.Context
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.net.wifi.WifiManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Base64
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.*
import java.net.*
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

data class PeerDevice(
    val id: String,
    var name: String,
    var ip: String,
    var lastSeen: Long = System.currentTimeMillis(),
    var isOnline: Boolean = true,
    var avatarBase64: String? = null,
    var pingMs: Long = -1
)

data class NetMessage(
    val id: String,
    val senderId: String,
    val senderName: String,
    val content: String,
    val timestamp: Long,
    val isMe: Boolean = false,
    val replyToId: String? = null,
    val replyToSender: String? = null,
    val replyToText: String? = null,
    var isDeleted: Boolean = false,
    val imageBase64: String? = null,
    val audioBase64: String? = null,
    val audioDurationSeconds: Int = 0,
    val isEncrypted: Boolean = false
)

class ChatNet(
    private val context: Context,
    private var myName: String,
    private var myAvatarBase64: String? = null,
    private var secretPassphrase: String = "",
    private val onDeviceFound: (PeerDevice) -> Unit,
    private val onDeviceStatusChanged: (PeerDevice) -> Unit,
    private val onMessageReceived: (NetMessage) -> Unit,
    private val onMessageDeleted: (String) -> Unit,
    private val onBuzzerReceived: (String) -> Unit
) {
    companion object {
        const val UDP_PORT = 8888
        const val TCP_PORT = 8889
        const val TCP_FILE_PORT = 8890
        const val HTTP_APK_SHARE_PORT = 8080
        const val UDP_AUDIO_PORT = 8892
        const val AUDIO_SAMPLE_RATE = 16000
    }

    private var multicastLock: WifiManager.MulticastLock? = null
    private var udpSocket: DatagramSocket? = null
    private var audioSocket: DatagramSocket? = null
    private var tcpServer: ServerSocket? = null
    private var apkShareServer: ServerSocket? = null

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var isRunning = false
    val myId = "android_" + (1000..9999).random()

    private val knownDevices = mutableMapOf<String, PeerDevice>()
    private val seenMessageIds = hashSetOf<String>()

    // Live Walkie-Talkie state
    private var audioTrack: AudioTrack? = null
    private var audioRecord: AudioRecord? = null
    private var isRecordingWalkie = false

    fun updateMyProfile(name: String, avatar: String?) {
        myName = name
        myAvatarBase64 = avatar
        sendHelloBroadcast()
    }

    fun updateSecretPassphrase(passphrase: String) {
        secretPassphrase = passphrase.trim()
    }

    fun start() {
        if (isRunning) return
        isRunning = true

        try {
            val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            multicastLock = wifi.createMulticastLock("LanChatMulticastLock").apply {
                setReferenceCounted(true)
                acquire()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        initAudioPlayback()
        startUdpListener()
        startAudioListener()
        startTcpServer()
        startApkShareServer()
        startHeartbeatLoop()
        startTimeoutCheckerLoop()
        startPingLoop()
    }

    // 1. تشفير وفك تشفير AES-256 للقناة بكلمة سر
    private fun encryptText(plainText: String, pass: String): String {
        if (pass.isBlank()) return plainText
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val keyBytes = digest.digest(pass.toByteArray(Charsets.UTF_8))
            val keySpec = SecretKeySpec(keyBytes, "AES")

            val iv = ByteArray(16)
            SecureRandom().nextBytes(iv)
            val ivSpec = IvParameterSpec(iv)

            val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
            cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec)
            val encrypted = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))

            val ivStr = Base64.encodeToString(iv, Base64.NO_WRAP)
            val encStr = Base64.encodeToString(encrypted, Base64.NO_WRAP)
            "enc_aes256:$ivStr:$encStr"
        } catch (e: Exception) {
            plainText
        }
    }

    private fun decryptText(cipherText: String, pass: String): Pair<String, Boolean> {
        if (!cipherText.startsWith("enc_aes256:")) {
            return Pair(cipherText, false)
        }
        if (pass.isBlank()) {
            return Pair("🔒 رسالة مشفرة (اضغط على 'التشفير' وأدخل كلمة السر لقراءتها)", true)
        }
        return try {
            val parts = cipherText.split(":")
            if (parts.size < 3) return Pair(cipherText, false)
            val iv = Base64.decode(parts[1], Base64.NO_WRAP)
            val encrypted = Base64.decode(parts[2], Base64.NO_WRAP)

            val digest = MessageDigest.getInstance("SHA-256")
            val keyBytes = digest.digest(pass.toByteArray(Charsets.UTF_8))
            val keySpec = SecretKeySpec(keyBytes, "AES")
            val ivSpec = IvParameterSpec(iv)

            val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
            cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec)
            val decrypted = cipher.doFinal(encrypted)
            Pair(String(decrypted, Charsets.UTF_8), true)
        } catch (e: Exception) {
            Pair("🔒 كلمة سر التشفير غير متطابقة", true)
        }
    }

    // 2. إرسال Hello كل 4 ثوانٍ مع فحص الـ 20 ثانية لحالة غير متصل
    private fun startHeartbeatLoop() {
        scope.launch {
            while (isRunning) {
                try {
                    sendHelloBroadcast()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                delay(4000)
            }
        }
    }

    private fun sendHelloBroadcast() {
        val myIp = getLocalIpAddress() ?: return
        val json = JSONObject().apply {
            put("type", "hello")
            put("id", myId)
            put("name", myName)
            put("ip", myIp)
            put("status", "online")
            put("timestamp", System.currentTimeMillis())
            if (!myAvatarBase64.isNullOrEmpty()) {
                put("avatar", myAvatarBase64)
            }
        }.toString()

        val bytes = json.toByteArray(Charsets.UTF_8)
        try {
            val broadcastAddr = InetAddress.getByName("255.255.255.255")
            udpSocket?.send(DatagramPacket(bytes, bytes.size, broadcastAddr, UDP_PORT))
        } catch (e: Exception) {}

        for (subAddr in getSubnetBroadcastAddresses()) {
            try {
                udpSocket?.send(DatagramPacket(bytes, bytes.size, subAddr, UDP_PORT))
            } catch (e: Exception) {}
        }

        // إرسال مباشر Unicast للأجهزة المحفوظة
        synchronized(knownDevices) {
            for (peer in knownDevices.values) {
                if (peer.ip.isNotEmpty() && peer.ip != myIp) {
                    try {
                        val peerAddr = InetAddress.getByName(peer.ip)
                        udpSocket?.send(DatagramPacket(bytes, bytes.size, peerAddr, UDP_PORT))
                    } catch (e: Exception) {}
                }
            }
        }
    }

    private fun startTimeoutCheckerLoop() {
        scope.launch {
            while (isRunning) {
                val now = System.currentTimeMillis()
                synchronized(knownDevices) {
                    for (peer in knownDevices.values) {
                        if (peer.isOnline && (now - peer.lastSeen > 20000)) {
                            peer.isOnline = false
                            withContext(Dispatchers.Main) {
                                onDeviceStatusChanged(peer)
                            }
                        }
                    }
                }
                delay(2000)
            }
        }
    }

    // 3. قياس سرعة الاستجابة والـ Ping (Signal Quality)
    private fun startPingLoop() {
        scope.launch {
            while (isRunning) {
                delay(7000)
                val myIp = getLocalIpAddress() ?: continue
                synchronized(knownDevices) {
                    for (peer in knownDevices.values) {
                        if (peer.isOnline && peer.ip.isNotEmpty() && peer.ip != myIp) {
                            try {
                                val json = JSONObject().apply {
                                    put("type", "ping")
                                    put("id", myId)
                                    put("t", System.currentTimeMillis())
                                }.toString()
                                val bytes = json.toByteArray(Charsets.UTF_8)
                                val peerAddr = InetAddress.getByName(peer.ip)
                                udpSocket?.send(DatagramPacket(bytes, bytes.size, peerAddr, UDP_PORT))
                            } catch (e: Exception) {}
                        }
                    }
                }
            }
        }
    }

    // 4. استماع حزم الـ UDP والـ Mesh Relay
    private fun startUdpListener() {
        scope.launch {
            try {
                udpSocket = DatagramSocket(null).apply {
                    reuseAddress = true
                    broadcast = true
                    bind(InetSocketAddress(UDP_PORT))
                }
                val buffer = ByteArray(65507)

                while (isRunning) {
                    val packet = DatagramPacket(buffer, buffer.size)
                    udpSocket?.receive(packet)
                    val text = String(packet.data, 0, packet.length, Charsets.UTF_8)
                    handleIncomingPacket(text, packet.address.hostAddress ?: "")
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private suspend fun handleIncomingPacket(rawJson: String, packetSenderIp: String) {
        try {
            val json = JSONObject(rawJson)
            val type = json.optString("type")
            val senderId = json.optString("id")
            val msgId = json.optString("msgId")

            if (senderId == myId) return

            // Mesh Relay: تتبع الرسائل ومنع التكرار وتمرير الرسائل للأجهزة البعيدة
            val ttl = json.optInt("ttl", 3)
            val recipientId = json.optString("recipientId", "public")

            if (msgId.isNotEmpty()) {
                synchronized(seenMessageIds) {
                    if (seenMessageIds.contains(msgId)) {
                        return
                    }
                    seenMessageIds.add(msgId)
                    if (seenMessageIds.size > 2000) seenMessageIds.clear()
                }

                // إذا كانت الرسالة ليست لي وليست عامة و ttl > 1 نقوم بتمريرها (Relay)
                if (recipientId != "public" && recipientId != myId && ttl > 1) {
                    forwardPacketAsMeshRelay(rawJson, ttl - 1)
                }
            }

            when (type) {
                "hello" -> {
                    val senderName = json.optString("name", "مستخدم شبكة")
                    val senderIp = if (packetSenderIp.isNotEmpty()) packetSenderIp else json.optString("ip")
                    val avatar = json.optString("avatar", null)

                    val peer: PeerDevice
                    var isNew = false
                    synchronized(knownDevices) {
                        if (!knownDevices.containsKey(senderId)) {
                            peer = PeerDevice(
                                id = senderId,
                                name = senderName,
                                ip = senderIp,
                                lastSeen = System.currentTimeMillis(),
                                isOnline = true,
                                avatarBase64 = avatar
                            )
                            knownDevices[senderId] = peer
                            isNew = true
                        } else {
                            peer = knownDevices[senderId]!!
                            val wasOffline = !peer.isOnline
                            peer.lastSeen = System.currentTimeMillis()
                            peer.name = senderName
                            peer.ip = senderIp
                            if (avatar != null) peer.avatarBase64 = avatar
                            peer.isOnline = true
                            if (wasOffline) isNew = true
                        }
                    }

                    withContext(Dispatchers.Main) {
                        if (isNew) onDeviceFound(peer) else onDeviceStatusChanged(peer)
                    }
                }

                "ping" -> {
                    val t = json.optLong("t", 0)
                    if (t > 0 && packetSenderIp.isNotEmpty()) {
                        val pongJson = JSONObject().apply {
                            put("type", "pong")
                            put("id", myId)
                            put("t", t)
                        }.toString()
                        val bytes = pongJson.toByteArray(Charsets.UTF_8)
                        val target = InetAddress.getByName(packetSenderIp)
                        udpSocket?.send(DatagramPacket(bytes, bytes.size, target, UDP_PORT))
                    }
                }

                "pong" -> {
                    val t = json.optLong("t", 0)
                    if (t > 0) {
                        val latency = System.currentTimeMillis() - t
                        synchronized(knownDevices) {
                            val peer = knownDevices[senderId]
                            if (peer != null) {
                                peer.pingMs = latency
                                withContext(Dispatchers.Main) {
                                    onDeviceStatusChanged(peer)
                                }
                            }
                        }
                    }
                }

                "buzzer" -> {
                    val callerName = json.optString("senderName", "شخص على الشبكة")
                    withContext(Dispatchers.Main) {
                        triggerLocalBuzzerAlert()
                        onBuzzerReceived(callerName)
                    }
                }

                "chat" -> {
                    if (recipientId == "public" || recipientId == myId) {
                        val senderName = json.optString("senderName", "مجهول")
                        val rawContent = json.optString("content", "")
                        val (plainContent, wasEncrypted) = decryptText(rawContent, secretPassphrase)

                        val timestamp = json.optLong("timestamp", System.currentTimeMillis())
                        val replyId = json.optString("replyToId", null)
                        val replySender = json.optString("replyToSender", null)
                        val replyText = json.optString("replyToText", null)
                        val img = json.optString("imageBase64", null)
                        val audio = json.optString("audioBase64", null)
                        val duration = json.optInt("audioDuration", 0)

                        val msg = NetMessage(
                            id = msgId,
                            senderId = senderId,
                            senderName = senderName,
                            content = plainContent,
                            timestamp = timestamp,
                            isMe = false,
                            replyToId = replyId,
                            replyToSender = replySender,
                            replyToText = replyText,
                            imageBase64 = img,
                            audioBase64 = audio,
                            audioDurationSeconds = duration,
                            isEncrypted = wasEncrypted
                        )
                        withContext(Dispatchers.Main) {
                            onMessageReceived(msg)
                        }
                    }
                }

                "delete_message" -> {
                    val targetMsgId = json.optString("messageId")
                    if (targetMsgId.isNotEmpty()) {
                        withContext(Dispatchers.Main) {
                            onMessageDeleted(targetMsgId)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // 5. شبكة التتابع (Mesh Relay Forwarding)
    private fun forwardPacketAsMeshRelay(rawJson: String, newTtl: Int) {
        scope.launch {
            try {
                val modified = JSONObject(rawJson).apply {
                    put("ttl", newTtl)
                }.toString()
                val bytes = modified.toByteArray(Charsets.UTF_8)
                val broadcastAddr = InetAddress.getByName("255.255.255.255")
                udpSocket?.send(DatagramPacket(bytes, bytes.size, broadcastAddr, UDP_PORT))
            } catch (e: Exception) {}
        }
    }

    // 6. إرسال الرسائل والبصمات الصوتية والصور مع تكرار مرتين لضمان الوصول
    fun sendMessage(
        targetIp: String?,
        targetUserId: String?,
        content: String,
        replyTo: NetMessage? = null,
        imageBase64: String? = null,
        audioBase64: String? = null,
        audioDuration: Int = 0,
        onSent: (NetMessage) -> Unit
    ) {
        scope.launch {
            try {
                val msgId = "msg_${System.currentTimeMillis()}_${(100..999).random()}"
                val isEncrypted = secretPassphrase.isNotBlank()
                val processedContent = encryptText(content, secretPassphrase)

                val json = JSONObject().apply {
                    put("type", "chat")
                    put("msgId", msgId)
                    put("id", myId)
                    put("senderName", myName)
                    put("recipientId", targetUserId ?: "public")
                    put("content", processedContent)
                    put("timestamp", System.currentTimeMillis())
                    put("ttl", 3)
                    if (replyTo != null) {
                        put("replyToId", replyTo.id)
                        put("replyToSender", replyTo.senderName)
                        put("replyToText", replyTo.content)
                    }
                    if (imageBase64 != null) put("imageBase64", imageBase64)
                    if (audioBase64 != null) {
                        put("audioBase64", audioBase64)
                        put("audioDuration", audioDuration)
                    }
                }.toString()

                val bytes = json.toByteArray(Charsets.UTF_8)
                synchronized(seenMessageIds) {
                    seenMessageIds.add(msgId)
                }

                if (targetIp.isNullOrEmpty()) {
                    val broadcastAddr = InetAddress.getByName("255.255.255.255")
                    val packet = DatagramPacket(bytes, bytes.size, broadcastAddr, UDP_PORT)
                    udpSocket?.send(packet)
                    delay(50)
                    udpSocket?.send(packet)

                    for (sub in getSubnetBroadcastAddresses()) {
                        try {
                            udpSocket?.send(DatagramPacket(bytes, bytes.size, sub, UDP_PORT))
                        } catch (e: Exception) {}
                    }
                } else {
                    val peerAddr = InetAddress.getByName(targetIp)
                    val packet = DatagramPacket(bytes, bytes.size, peerAddr, UDP_PORT)
                    udpSocket?.send(packet)
                    delay(50)
                    udpSocket?.send(packet)
                }

                val localMsg = NetMessage(
                    id = msgId,
                    senderId = myId,
                    senderName = myName,
                    content = content,
                    timestamp = System.currentTimeMillis(),
                    isMe = true,
                    replyToId = replyTo?.id,
                    replyToSender = replyTo?.senderName,
                    replyToText = replyTo?.content,
                    imageBase64 = imageBase64,
                    audioBase64 = audioBase64,
                    audioDurationSeconds = audioDuration,
                    isEncrypted = isEncrypted
                )
                withContext(Dispatchers.Main) {
                    onSent(localMsg)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // 7. التنبيه العاجل والنداء اللاسلكي (Urgent Buzzer / Nudge)
    fun sendBuzzer(targetIp: String?) {
        scope.launch {
            try {
                val json = JSONObject().apply {
                    put("type", "buzzer")
                    put("id", myId)
                    put("senderName", myName)
                }.toString()

                val bytes = json.toByteArray(Charsets.UTF_8)
                val targetAddr = if (targetIp.isNullOrEmpty()) {
                    InetAddress.getByName("255.255.255.255")
                } else {
                    InetAddress.getByName(targetIp)
                }
                val packet = DatagramPacket(bytes, bytes.size, targetAddr, UDP_PORT)
                udpSocket?.send(packet)
                delay(50)
                udpSocket?.send(packet)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun triggerLocalBuzzerAlert() {
        try {
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            val pattern = longArrayOf(0, 300, 150, 300, 150, 500)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
            } else {
                vibrator.vibrate(pattern, -1)
            }

            val toneGen = ToneGenerator(AudioManager.STREAM_ALARM, 100)
            toneGen.startTone(ToneGenerator.TONE_CDMA_EMERGENCY_RINGBACK, 1200)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // 8. حذف الرسائل عند الجميع
    fun sendDeleteForEveryone(messageId: String, targetIp: String?) {
        scope.launch {
            try {
                val json = JSONObject().apply {
                    put("type", "delete_message")
                    put("id", myId)
                    put("messageId", messageId)
                }.toString()

                val bytes = json.toByteArray(Charsets.UTF_8)
                val targetAddr = if (targetIp.isNullOrEmpty()) {
                    InetAddress.getByName("255.255.255.255")
                } else {
                    InetAddress.getByName(targetIp)
                }
                val packet = DatagramPacket(bytes, bytes.size, targetAddr, UDP_PORT)
                udpSocket?.send(packet)
                delay(50)
                udpSocket?.send(packet)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // 9. اللاسلكي المباشر PTT
    private fun initAudioPlayback() {
        try {
            val minBufSize = AudioTrack.getMinBufferSize(
                AUDIO_SAMPLE_RATE,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            audioTrack = AudioTrack(
                AudioManager.STREAM_VOICE_CALL,
                AUDIO_SAMPLE_RATE,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                minBufSize * 2,
                AudioTrack.MODE_STREAM
            )
            audioTrack?.play()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun startAudioListener() {
        scope.launch {
            try {
                audioSocket = DatagramSocket(null).apply {
                    reuseAddress = true
                    bind(InetSocketAddress(UDP_AUDIO_PORT))
                }
                val buffer = ByteArray(1024)
                while (isRunning) {
                    val packet = DatagramPacket(buffer, buffer.size)
                    audioSocket?.receive(packet)
                    audioTrack?.write(packet.data, 0, packet.length)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun startWalkieTalkie(targetIp: String?) {
        if (isRecordingWalkie) return
        isRecordingWalkie = true

        scope.launch {
            try {
                val minBufSize = AudioRecord.getMinBufferSize(
                    AUDIO_SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )
                audioRecord = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    AUDIO_SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    minBufSize
                )
                audioRecord?.startRecording()
                val targetAddr = if (targetIp.isNullOrEmpty()) {
                    InetAddress.getByName("255.255.255.255")
                } else {
                    InetAddress.getByName(targetIp)
                }

                val buffer = ByteArray(640)
                while (isRecordingWalkie && isRunning) {
                    val read = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                    if (read > 0) {
                        val packet = DatagramPacket(buffer, read, targetAddr, UDP_AUDIO_PORT)
                        audioSocket?.send(packet)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                stopWalkieTalkie()
            }
        }
    }

    fun stopWalkieTalkie() {
        isRecordingWalkie = false
        try {
            audioRecord?.stop()
            audioRecord?.release()
            audioRecord = null
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // 10. خادم مشاركة الـ APK بدون إنترنت عبر الواي فاي (HTTP Server on Port 8080)
    private fun startApkShareServer() {
        scope.launch {
            try {
                apkShareServer = ServerSocket(HTTP_APK_SHARE_PORT)
                while (isRunning) {
                    val client = apkShareServer?.accept() ?: continue
                    scope.launch {
                        try {
                            serveApkToClient(client)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun serveApkToClient(client: Socket) {
        try {
            val apkFile = File(context.applicationInfo.sourceDir)
            val output = client.getOutputStream()

            val header = "HTTP/1.1 200 OK\r\n" +
                    "Content-Type: application/vnd.android.package-archive\r\n" +
                    "Content-Disposition: attachment; filename=\"LanChat.apk\"\r\n" +
                    "Content-Length: ${apkFile.length()}\r\n" +
                    "Connection: close\r\n\r\n"

            output.write(header.toByteArray(Charsets.UTF_8))

            val fis = FileInputStream(apkFile)
            val buffer = ByteArray(8192)
            var bytesRead: Int
            while (fis.read(buffer).also { bytesRead = it } != -1) {
                output.write(buffer, 0, bytesRead)
            }
            output.flush()
            fis.close()
            client.close()
        } catch (e: Exception) {
            e.printStackTrace()
            try { client.close() } catch (ex: Exception) {}
        }
    }

    private fun startTcpServer() {
        scope.launch {
            try {
                tcpServer = ServerSocket(TCP_PORT)
                while (isRunning) {
                    val client = tcpServer?.accept() ?: continue
                    scope.launch {
                        try {
                            val reader = BufferedReader(InputStreamReader(client.getInputStream(), Charsets.UTF_8))
                            val line = reader.readLine()
                            if (line != null) {
                                handleIncomingPacket(line, client.inetAddress.hostAddress ?: "")
                            }
                            client.close()
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun getSubnetBroadcastAddresses(): List<InetAddress> {
        val list = mutableListOf<InetAddress>()
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                if (iface.isLoopback || !iface.isUp) continue
                for (interfaceAddress in iface.interfaceAddresses) {
                    val broadcast = interfaceAddress.broadcast
                    if (broadcast != null) list.add(broadcast)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    fun getLocalIpAddress(): String? {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                val addresses = iface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val addr = addresses.nextElement()
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        return addr.hostAddress
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }

    fun stop() {
        isRunning = false
        stopWalkieTalkie()
        try {
            audioTrack?.stop()
            audioTrack?.release()
            audioTrack = null
            udpSocket?.close()
            audioSocket?.close()
            tcpServer?.close()
            apkShareServer?.close()
            multicastLock?.release()
            scope.cancel()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
