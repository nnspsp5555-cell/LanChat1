package com.example.lanchat

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Base64
import android.view.MotionEvent
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.InputStream

class MainActivity : AppCompatActivity() {

    private lateinit var chatNet: ChatNet
    private val discoveredDevices = mutableMapOf<String, PeerDevice>()
    private val messagesList = mutableListOf<NetMessage>()
    private lateinit var adapter: MessageAdapter

    private lateinit var txtDeviceCount: TextView
    private lateinit var devicesSpinner: Spinner
    private lateinit var recyclerMessages: RecyclerView
    private lateinit var inputMessage: EditText
    private lateinit var btnSend: ImageButton
    private lateinit var btnGallery: ImageButton
    private lateinit var btnRecordVoice: ImageButton
    private lateinit var btnWalkieTalkie: Button
    private lateinit var btnEditProfile: Button
    private lateinit var btnSecurityKey: Button
    private lateinit var btnBuzzer: Button
    private lateinit var btnShareApp: Button

    // Reply Banner views
    private lateinit var layoutReplyBanner: View
    private lateinit var txtBannerReplySender: TextView
    private lateinit var txtBannerReplyContent: TextView
    private lateinit var btnCloseReply: ImageButton
    private var activeReplyMessage: NetMessage? = null

    // Voice Note Recording Banner views
    private lateinit var layoutRecordingVoice: View
    private lateinit var txtRecordingTimer: TextView
    private lateinit var btnCancelVoiceRecord: Button
    private lateinit var btnSendVoiceRecord: Button
    private var voiceMediaRecorder: MediaRecorder? = null
    private var voiceTempFile: File? = null
    private var isRecordingVoiceNote = false
    private var voiceRecordSeconds = 0
    private val voiceTimerHandler = Handler(Looper.getMainLooper())
    private val voiceTimerRunnable = object : Runnable {
        override fun run() {
            if (isRecordingVoiceNote) {
                voiceRecordSeconds++
                val m = voiceRecordSeconds / 60
                val s = voiceRecordSeconds % 60
                txtRecordingTimer.text = String.format("🔴 جاري تسجيل البصمة الصوتية (%02d:%02d)...", m, s)
                voiceTimerHandler.postDelayed(this, 1000)
            }
        }
    }

    private lateinit var prefs: SharedPreferences
    private var myName = "مستخدم أندرويد"
    private var myAvatarBase64: String? = null
    private var secretPassphrase = ""

    // Pick image from gallery for sending as a message
    private val pickChatImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            val base64 = uriToBase64(uri, 500)
            if (base64 != null) {
                sendChatMessage(customImageBase64 = base64)
            }
        }
    }

    // Pick image from gallery for user profile
    private var profileDialogImageView: ImageView? = null
    private val pickProfileImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            val base64 = uriToBase64(uri, 180)
            if (base64 != null) {
                myAvatarBase64 = base64
                prefs.edit().putString("my_avatar", base64).apply()
                profileDialogImageView?.let { updateAvatarImageView(it, base64) }
                chatNet.updateMyProfile(myName, myAvatarBase64)
                Toast.makeText(this, "تم تحديث صورتك الشخصية بنجاح 🖼️", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("lanchat_prefs", Context.MODE_PRIVATE)
        myName = prefs.getString("my_name", "") ?: ""
        myAvatarBase64 = prefs.getString("my_avatar", null)
        secretPassphrase = prefs.getString("secret_passphrase", "") ?: ""

        loadSavedDevices()

        // Bind Views
        txtDeviceCount = findViewById(R.id.txtDeviceCount)
        devicesSpinner = findViewById(R.id.devicesSpinner)
        recyclerMessages = findViewById(R.id.recyclerMessages)
        inputMessage = findViewById(R.id.inputMessage)
        btnSend = findViewById(R.id.btnSend)
        btnGallery = findViewById(R.id.btnGallery)
        btnRecordVoice = findViewById(R.id.btnRecordVoice)
        btnWalkieTalkie = findViewById(R.id.btnWalkieTalkie)
        btnEditProfile = findViewById(R.id.btnEditProfile)
        btnSecurityKey = findViewById(R.id.btnSecurityKey)
        btnBuzzer = findViewById(R.id.btnBuzzer)
        btnShareApp = findViewById(R.id.btnShareApp)

        // Reply Banner views
        layoutReplyBanner = findViewById(R.id.layoutReplyBanner)
        txtBannerReplySender = findViewById(R.id.txtBannerReplySender)
        txtBannerReplyContent = findViewById(R.id.txtBannerReplyContent)
        btnCloseReply = findViewById(R.id.btnCloseReply)
        btnCloseReply.setOnClickListener { cancelActiveReply() }

        // Voice Note Recording Banner views
        layoutRecordingVoice = findViewById(R.id.layoutRecordingVoice)
        txtRecordingTimer = findViewById(R.id.txtRecordingTimer)
        btnCancelVoiceRecord = findViewById(R.id.btnCancelVoiceRecord)
        btnSendVoiceRecord = findViewById(R.id.btnSendVoiceRecord)
        btnCancelVoiceRecord.setOnClickListener { cancelVoiceRecording() }
        btnSendVoiceRecord.setOnClickListener { finishAndSendVoiceRecording() }

        // Update Security Key button text if active
        updateSecurityButtonUi()

        // Setup RecyclerView & Adapter
        adapter = MessageAdapter(
            messagesList,
            onMessageClick = { msg -> setReplyToMessage(msg) },
            onMessageLongClick = { msg -> showMessageOptionsMenu(msg) }
        )
        recyclerMessages.layoutManager = LinearLayoutManager(this).apply {
            stackFromEnd = true
        }
        recyclerMessages.adapter = adapter

        updateDevicesSpinner()

        // First time launch: Prompt for user name if not set
        if (myName.isBlank()) {
            myName = "أندرويد (${(10..99).random()})"
            showEditProfileDialog(isFirstTime = true)
        }

        // Start Foreground Service so connection stays alive with screen off
        startChatBackgroundService()

        // Initialize ChatNet
        chatNet = ChatNet(
            context = this,
            myName = myName,
            myAvatarBase64 = myAvatarBase64,
            secretPassphrase = secretPassphrase,
            onDeviceFound = { device ->
                discoveredDevices[device.id] = device
                saveDevices()
                updateDevicesUI()
            },
            onDeviceStatusChanged = { device ->
                discoveredDevices[device.id] = device
                updateDevicesUI()
            },
            onMessageReceived = { msg ->
                adapter.addMessage(msg)
                recyclerMessages.scrollToPosition(messagesList.size - 1)
                vibratePhone()
            },
            onMessageDeleted = { msgId ->
                adapter.markMessageDeleted(msgId)
            },
            onBuzzerReceived = { senderName ->
                showBuzzerReceivedAlert(senderName)
            }
        )

        chatNet.start()

        // Button Actions
        btnSend.setOnClickListener { sendChatMessage() }
        btnGallery.setOnClickListener { pickChatImageLauncher.launch("image/*") }
        btnRecordVoice.setOnClickListener { toggleVoiceNoteRecording() }
        btnEditProfile.setOnClickListener { showEditProfileDialog(isFirstTime = false) }
        btnSecurityKey.setOnClickListener { showSecurityKeyDialog() }
        btnBuzzer.setOnClickListener { sendUrgentBuzzer() }
        btnShareApp.setOnClickListener { showShareApkDialog() }

        setupWalkieTalkieButton()
    }

    private fun updateSecurityButtonUi() {
        if (secretPassphrase.isNotBlank()) {
            btnSecurityKey.text = "🔒 مشفر ($secretPassphrase)"
            btnSecurityKey.setTextColor(0xFF38BDF8.toInt())
        } else {
            btnSecurityKey.text = "🔓 التشفير (عام)"
            btnSecurityKey.setTextColor(0xFF94A3B8.toInt())
        }
    }

    // 1. تشفير القناة بكلمة سر
    private fun showSecurityKeyDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_security_key, null)
        val editSecret = view.findViewById<EditText>(R.id.dialogEditSecret)
        val btnSave = view.findViewById<Button>(R.id.dialogBtnSaveSecret)

        editSecret.setText(secretPassphrase)

        val dialog = AlertDialog.Builder(this)
            .setView(view)
            .create()

        btnSave.setOnClickListener {
            secretPassphrase = editSecret.text.toString().trim()
            prefs.edit().putString("secret_passphrase", secretPassphrase).apply()
            chatNet.updateSecretPassphrase(secretPassphrase)
            updateSecurityButtonUi()
            dialog.dismiss()

            if (secretPassphrase.isNotBlank()) {
                Toast.makeText(this, "تم تفعيل التشفير العسكري AES-256 بنجاح! 🔒", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "تم إلغاء التشفير والعودة للقناة العامة", Toast.LENGTH_SHORT).show()
            }
        }

        dialog.show()
    }

    // 2. إرسال التنبيه العاجل (Buzzer)
    private fun sendUrgentBuzzer() {
        vibratePhone()
        val targetIp = getSelectedTargetIp()
        chatNet.sendBuzzer(targetIp)
        Toast.makeText(this, "🚨 تم إطلاق النداء العاجل والاهتزاز!", Toast.LENGTH_SHORT).show()
    }

    private fun showBuzzerReceivedAlert(senderName: String) {
        AlertDialog.Builder(this)
            .setTitle("🚨 نداء لاسلكي عاجل!")
            .setMessage("قام $senderName بإرسال تنبيه عاجل واهتزاز قوي لجهازك!")
            .setPositiveButton("حسناً") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    // 3. مشاركة التطبيق بدون إنترنت (ApkShare)
    private fun showShareApkDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_share_apk, null)
        val txtUrl = view.findViewById<TextView>(R.id.dialogTxtShareUrl)
        val btnCopy = view.findViewById<Button>(R.id.dialogBtnCopyShareUrl)
        val btnClose = view.findViewById<Button>(R.id.dialogBtnCloseShare)

        val myIp = chatNet.getLocalIpAddress() ?: "192.168.1.X"
        val shareUrl = "http://$myIp:8080"
        txtUrl.text = shareUrl

        val dialog = AlertDialog.Builder(this)
            .setView(view)
            .create()

        btnCopy.setOnClickListener {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("LanChat Share URL", shareUrl))
            Toast.makeText(this, "تم نسخ الرابط! افتحه في متصفح أي هاتف على نفس الشبكة", Toast.LENGTH_SHORT).show()
        }

        btnClose.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    // 4. تسجيل بصمة صوتية (Voice Note)
    private fun toggleVoiceNoteRecording() {
        if (isRecordingVoiceNote) {
            finishAndSendVoiceRecording()
        } else {
            startVoiceRecording()
        }
    }

    private fun startVoiceRecording() {
        try {
            voiceTempFile = File.createTempFile("rec_", ".3gp", cacheDir)
            voiceMediaRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(this)
            } else {
                MediaRecorder()
            }.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP)
                setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB)
                setOutputFile(voiceTempFile!!.absolutePath)
                prepare()
                start()
            }

            isRecordingVoiceNote = true
            voiceRecordSeconds = 0
            layoutRecordingVoice.visibility = View.VISIBLE
            txtRecordingTimer.text = "🔴 جاري تسجيل البصمة الصوتية (00:00)..."
            voiceTimerHandler.postDelayed(voiceTimerRunnable, 1000)
            vibratePhone()
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "تعذر تشغيل الميكروفون للتسجيل", Toast.LENGTH_SHORT).show()
            cancelVoiceRecording()
        }
    }

    private fun cancelVoiceRecording() {
        isRecordingVoiceNote = false
        voiceTimerHandler.removeCallbacks(voiceTimerRunnable)
        layoutRecordingVoice.visibility = View.GONE
        try {
            voiceMediaRecorder?.stop()
            voiceMediaRecorder?.release()
        } catch (e: Exception) {}
        voiceMediaRecorder = null
        voiceTempFile?.delete()
        voiceTempFile = null
    }

    private fun finishAndSendVoiceRecording() {
        if (!isRecordingVoiceNote) return
        isRecordingVoiceNote = false
        voiceTimerHandler.removeCallbacks(voiceTimerRunnable)
        layoutRecordingVoice.visibility = View.GONE

        try {
            voiceMediaRecorder?.stop()
            voiceMediaRecorder?.release()
        } catch (e: Exception) {}
        voiceMediaRecorder = null

        val duration = voiceRecordSeconds
        val file = voiceTempFile
        if (file != null && file.exists() && file.length() > 0) {
            val bytes = ByteArray(file.length().toInt())
            val fis = FileInputStream(file)
            fis.read(bytes)
            fis.close()
            val audioBase64 = Base64.encodeToString(bytes, Base64.NO_WRAP)

            sendChatMessage(customAudioBase64 = audioBase64, customAudioDuration = duration)
            file.delete()
        }
        voiceTempFile = null
    }

    private fun setupWalkieTalkieButton() {
        btnWalkieTalkie.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    vibratePhone()
                    val targetIp = getSelectedTargetIp()
                    chatNet.startWalkieTalkie(targetIp)
                    btnWalkieTalkie.setBackgroundColor(0xFFE11D48.toInt())
                    Toast.makeText(this, "🎙️ جاري البث الصوتي... (تحدث الآن)", Toast.LENGTH_SHORT).show()
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    chatNet.stopWalkieTalkie()
                    btnWalkieTalkie.setBackgroundResource(R.drawable.input_bg)
                    true
                }
                else -> false
            }
        }
    }

    private fun getSelectedTargetIp(): String? {
        val selectedIndex = devicesSpinner.selectedItemPosition
        val devices = discoveredDevices.values.toList()
        return if (selectedIndex > 0 && selectedIndex - 1 < devices.size) {
            devices[selectedIndex - 1].ip
        } else {
            null
        }
    }

    private fun getSelectedTargetId(): String? {
        val selectedIndex = devicesSpinner.selectedItemPosition
        val devices = discoveredDevices.values.toList()
        return if (selectedIndex > 0 && selectedIndex - 1 < devices.size) {
            devices[selectedIndex - 1].id
        } else {
            "public"
        }
    }

    private fun sendChatMessage(
        customImageBase64: String? = null,
        customAudioBase64: String? = null,
        customAudioDuration: Int = 0
    ) {
        val text = inputMessage.text.toString().trim()
        if (text.isEmpty() && customImageBase64 == null && customAudioBase64 == null) return

        val targetIp = getSelectedTargetIp()
        val targetId = getSelectedTargetId()
        val replyCopy = activeReplyMessage

        val contentText = when {
            text.isNotEmpty() -> text
            customImageBase64 != null -> "📷 صورة مرفقة"
            customAudioBase64 != null -> "🎙️ بصمة صوتية"
            else -> ""
        }

        chatNet.sendMessage(
            targetIp = targetIp,
            targetUserId = targetId,
            content = contentText,
            replyTo = replyCopy,
            imageBase64 = customImageBase64,
            audioBase64 = customAudioBase64,
            audioDuration = customAudioDuration
        ) { myMsg ->
            adapter.addMessage(myMsg)
            recyclerMessages.scrollToPosition(messagesList.size - 1)
        }

        inputMessage.setText("")
        cancelActiveReply()
    }

    private fun setReplyToMessage(msg: NetMessage) {
        if (msg.isDeleted) return
        activeReplyMessage = msg
        layoutReplyBanner.visibility = View.VISIBLE
        txtBannerReplySender.text = "الرد على: ${msg.senderName}"
        txtBannerReplyContent.text = msg.content
        inputMessage.requestFocus()
    }

    private fun cancelActiveReply() {
        activeReplyMessage = null
        layoutReplyBanner.visibility = View.GONE
    }

    private fun showMessageOptionsMenu(msg: NetMessage) {
        val options = mutableListOf<String>()
        if (!msg.isDeleted) {
            options.add("↩️ الرد على هذه الرسالة")
            options.add("📋 نسخ النص")
        }
        if (msg.isMe && !msg.isDeleted) {
            options.add("🚫 حذف لدى الجميع (Delete for everyone)")
        }

        if (options.isEmpty()) return

        AlertDialog.Builder(this)
            .setTitle("خيارات الرسالة")
            .setItems(options.toTypedArray()) { _, which ->
                val choice = options[which]
                when {
                    choice.contains("الرد") -> setReplyToMessage(msg)
                    choice.contains("نسخ") -> {
                        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("LanChat", msg.content))
                        Toast.makeText(this, "تم نسخ الرسالة 📋", Toast.LENGTH_SHORT).show()
                    }
                    choice.contains("حذف لدى الجميع") -> {
                        chatNet.sendDeleteForEveryone(msg.id, getSelectedTargetIp())
                        adapter.markMessageDeleted(msg.id)
                        Toast.makeText(this, "تم حذف الرسالة لدى الجميع 🚫", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .show()
    }

    private fun showEditProfileDialog(isFirstTime: Boolean) {
        val view = layoutInflater.inflate(R.layout.dialog_edit_profile, null)
        val editName = view.findViewById<EditText>(R.id.dialogEditName)
        val imgProfile = view.findViewById<ImageView>(R.id.dialogImgProfile)
        val btnPick = view.findViewById<Button>(R.id.dialogBtnPickGallery)
        val btnSave = view.findViewById<Button>(R.id.dialogBtnSave)

        profileDialogImageView = imgProfile
        editName.setText(myName)
        myAvatarBase64?.let { updateAvatarImageView(imgProfile, it) }

        val dialog = AlertDialog.Builder(this)
            .setView(view)
            .setCancelable(!isFirstTime)
            .create()

        btnPick.setOnClickListener {
            pickProfileImageLauncher.launch("image/*")
        }

        btnSave.setOnClickListener {
            val enteredName = editName.text.toString().trim()
            if (enteredName.isNotBlank()) {
                myName = enteredName
                prefs.edit().putString("my_name", myName).apply()
                if (::chatNet.isInitialized) {
                    chatNet.updateMyProfile(myName, myAvatarBase64)
                }
                dialog.dismiss()
                Toast.makeText(this, "أهلاً بك يا $myName! تم حفظ بياناتك 🚀", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "يرجى كتابة اسمك للمتابعة", Toast.LENGTH_SHORT).show()
            }
        }

        dialog.show()
    }

    private fun updateAvatarImageView(imageView: ImageView, base64: String) {
        try {
            val clean = if (base64.contains(",")) base64.substringAfter(",") else base64
            val bytes = Base64.decode(clean, Base64.DEFAULT)
            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            if (bitmap != null) {
                imageView.setImageBitmap(bitmap)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun uriToBase64(uri: Uri, maxDimension: Int): String? {
        return try {
            val stream: InputStream? = contentResolver.openInputStream(uri)
            val originalBitmap = BitmapFactory.decodeStream(stream) ?: return null
            stream?.close()

            val ratio = originalBitmap.width.toFloat() / originalBitmap.height.toFloat()
            val newWidth: Int
            val newHeight: Int
            if (originalBitmap.width > originalBitmap.height) {
                newWidth = maxDimension
                newHeight = (maxDimension / ratio).toInt()
            } else {
                newHeight = maxDimension
                newWidth = (maxDimension * ratio).toInt()
            }

            val scaled = Bitmap.createScaledBitmap(originalBitmap, newWidth, newHeight, true)
            val outputStream = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 75, outputStream)
            val bytes = outputStream.toByteArray()
            Base64.encodeToString(bytes, Base64.NO_WRAP)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun updateDevicesUI() {
        val onlineCount = discoveredDevices.values.count { it.isOnline }
        val totalCount = discoveredDevices.size
        txtDeviceCount.text = "$onlineCount متصل الآن (إجمالي الأجهزة: $totalCount)"
        updateDevicesSpinner()
    }

    private fun updateDevicesSpinner() {
        val currentSelectedPos = devicesSpinner.selectedItemPosition
        val items = mutableListOf("الجميع (بث عام)")
        discoveredDevices.values.forEach { dev ->
            val statusDot = if (dev.isOnline) "🟢" else "⚪"
            val pingText = if (dev.isOnline && dev.pingMs >= 0) " (${dev.pingMs}ms 📶)" else ""
            val statusDesc = if (dev.isOnline) "متصل" else "غير متصل"
            items.add("$statusDot ${dev.name}$pingText [$statusDesc - ${dev.ip}]")
        }
        val spinnerAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        devicesSpinner.adapter = spinnerAdapter
        if (currentSelectedPos < items.size) {
            devicesSpinner.setSelection(currentSelectedPos)
        }
    }

    private fun saveDevices() {
        try {
            val jsonArray = JSONArray()
            discoveredDevices.values.forEach { dev ->
                val obj = JSONObject().apply {
                    put("id", dev.id)
                    put("name", dev.name)
                    put("ip", dev.ip)
                    put("lastSeen", dev.lastSeen)
                    put("avatar", dev.avatarBase64 ?: "")
                }
                jsonArray.put(obj)
            }
            prefs.edit().putString("saved_devices", jsonArray.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun loadSavedDevices() {
        try {
            val raw = prefs.getString("saved_devices", null) ?: return
            val jsonArray = JSONArray(raw)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                val id = obj.optString("id")
                val name = obj.optString("name")
                val ip = obj.optString("ip")
                val avatar = obj.optString("avatar", null)
                discoveredDevices[id] = PeerDevice(
                    id = id,
                    name = name,
                    ip = ip,
                    lastSeen = 0,
                    isOnline = false,
                    avatarBase64 = avatar
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun startChatBackgroundService() {
        val serviceIntent = Intent(this, ChatService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }

    private fun vibratePhone() {
        try {
            val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                vibrator.vibrate(80)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        cancelVoiceRecording()
        chatNet.stop()
    }
}
