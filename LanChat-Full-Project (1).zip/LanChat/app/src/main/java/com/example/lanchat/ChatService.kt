package com.example.lanchat

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.wifi.WifiManager
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat

class ChatService : Service() {
    private val binder = LocalBinder()
    var chatNet: ChatNet? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null

    inner class LocalBinder : Binder() {
        fun getService(): ChatService = this@ChatService
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        acquireWakeAndWifiLocks()
        createNotificationChannel()
        val notification = createNotification("الدردشة اللاسلكية قيد التشغيل (بدون إنترنت)")
        startForeground(101, notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    private fun acquireWakeAndWifiLocks() {
        try {
            // 1. Partial WakeLock: يمنع المعالج من النوم حتى لو الشاشة مطفية
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LanChat::ServiceWakeLock").apply {
                setReferenceCounted(false)
                acquire()
            }

            // 2. WifiLock: يمنع شبكة الواي فاي من الدخول في وضع توفير الطاقة
            val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val wifiLockMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                WifiManager.WIFI_MODE_FULL_LOW_LATENCY
            } else {
                WifiManager.WIFI_MODE_FULL_HIGH_PERF
            }
            wifiLock = wifiManager.createWifiLock(wifiLockMode, "LanChat::ServiceWifiLock").apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "LanChatChannel",
                "الدردشة اللاسلكية LanChat",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "خدمة الاستماع والاتصال المباشر عبر شبكة Wi-Fi بدون سيرفر أو إنترنت"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(statusText: String): Notification {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0
        )

        return NotificationCompat.Builder(this, "LanChatChannel")
            .setContentTitle("👑 دردشة آل عيسى اللاسلكية")
            .setContentText(statusText)
            .setSmallIcon(android.R.drawable.ic_menu_share)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onDestroy() {
        try {
            wakeLock?.release()
            wifiLock?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        chatNet?.stop()
        super.onDestroy()
    }
}
