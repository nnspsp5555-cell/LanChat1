package com.example.lanchat

import android.graphics.BitmapFactory
import android.media.MediaPlayer
import android.util.Base64
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

class MessageAdapter(
    private val messages: MutableList<NetMessage>,
    private val onMessageClick: (NetMessage) -> Unit,
    private val onMessageLongClick: (NetMessage) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        const val TYPE_ME = 1
        const val TYPE_OTHER = 2
    }

    private var activeMediaPlayer: MediaPlayer? = null
    private var activePlayingMsgId: String? = null

    override fun getItemViewType(position: Int): Int {
        return if (messages[position].isMe) TYPE_ME else TYPE_OTHER
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val view = inflater.inflate(R.layout.item_message, parent, false)
        return MessageViewHolder(view)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val msg = messages[position]
        val vh = holder as MessageViewHolder
        val context = vh.itemView.context
        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
        val formattedTime = timeFormat.format(Date(msg.timestamp))

        vh.txtTime.text = formattedTime

        // If message is deleted
        if (msg.isDeleted) {
            vh.txtContent.text = if (msg.isMe) "🚫 قمت بحذف هذه الرسالة" else "🚫 تم حذف هذه الرسالة"
            vh.txtContent.setTextColor(0xFF94A3B8.toInt())
            vh.bubbleContainer.setBackgroundResource(R.drawable.bubble_deleted)
            vh.layoutReplyQuote.visibility = View.GONE
            vh.imgMessage.visibility = View.GONE
            vh.layoutVoiceNote.visibility = View.GONE
            vh.txtSender.visibility = View.GONE
            vh.txtStatus.visibility = View.GONE
            vh.txtEncryptedBadge.visibility = View.GONE
            return
        }

        vh.txtContent.text = msg.content
        vh.txtContent.setTextColor(0xFFFFFFFF.toInt())

        // Encrypted indicator badge
        vh.txtEncryptedBadge.visibility = if (msg.isEncrypted) View.VISIBLE else View.GONE

        // Sender Header
        if (msg.isMe) {
            vh.txtSender.visibility = View.GONE
            vh.bubbleContainer.setBackgroundResource(R.drawable.bubble_me)
            vh.txtStatus.visibility = View.VISIBLE
            vh.txtStatus.text = "✓✓"
        } else {
            vh.txtSender.visibility = View.VISIBLE
            vh.txtSender.text = msg.senderName
            vh.bubbleContainer.setBackgroundResource(R.drawable.bubble_other)
            vh.txtStatus.visibility = View.GONE
        }

        // Reply quote rendering
        if (!msg.replyToId.isNullOrEmpty() && !msg.replyToText.isNullOrEmpty()) {
            vh.layoutReplyQuote.visibility = View.VISIBLE
            vh.txtReplySender.text = msg.replyToSender ?: "رسالة سابقة"
            vh.txtReplyContent.text = msg.replyToText
        } else {
            vh.layoutReplyQuote.visibility = View.GONE
        }

        // Image rendering
        if (!msg.imageBase64.isNullOrEmpty()) {
            try {
                val cleanBase64 = if (msg.imageBase64.contains(",")) msg.imageBase64.substringAfter(",") else msg.imageBase64
                val imageBytes = Base64.decode(cleanBase64, Base64.DEFAULT)
                val bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size)
                if (bitmap != null) {
                    vh.imgMessage.visibility = View.VISIBLE
                    vh.imgMessage.setImageBitmap(bitmap)
                } else {
                    vh.imgMessage.visibility = View.GONE
                }
            } catch (e: Exception) {
                vh.imgMessage.visibility = View.GONE
            }
        } else {
            vh.imgMessage.visibility = View.GONE
        }

        // Voice Note Audio Player
        if (!msg.audioBase64.isNullOrEmpty()) {
            vh.layoutVoiceNote.visibility = View.VISIBLE
            val dur = if (msg.audioDurationSeconds > 0) "${msg.audioDurationSeconds}ث" else ""
            vh.txtVoiceDuration.text = "🎙️ بصمة صوتية $dur"

            val isCurrentlyPlaying = (activePlayingMsgId == msg.id)
            vh.btnPlayVoice.setImageResource(
                if (isCurrentlyPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
            )

            vh.btnPlayVoice.setOnClickListener {
                if (isCurrentlyPlaying) {
                    stopActiveVoiceNote()
                    notifyItemChanged(position)
                } else {
                    playVoiceNote(context, msg) {
                        notifyItemChanged(position)
                    }
                    notifyItemChanged(position)
                }
            }
        } else {
            vh.layoutVoiceNote.visibility = View.GONE
        }

        vh.bubbleContainer.setOnLongClickListener {
            onMessageLongClick(msg)
            true
        }

        vh.bubbleContainer.setOnClickListener {
            onMessageClick(msg)
        }
    }

    private fun playVoiceNote(context: android.content.Context, msg: NetMessage, onFinished: () -> Unit) {
        stopActiveVoiceNote()
        try {
            val audioBytes = Base64.decode(msg.audioBase64, Base64.DEFAULT)
            val tempFile = File.createTempFile("voice_", ".3gp", context.cacheDir)
            val fos = FileOutputStream(tempFile)
            fos.write(audioBytes)
            fos.close()

            activePlayingMsgId = msg.id
            activeMediaPlayer = MediaPlayer().apply {
                setDataSource(tempFile.absolutePath)
                prepare()
                start()
                setOnCompletionListener {
                    stopActiveVoiceNote()
                    onFinished()
                    tempFile.delete()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            stopActiveVoiceNote()
            onFinished()
        }
    }

    private fun stopActiveVoiceNote() {
        try {
            activeMediaPlayer?.stop()
            activeMediaPlayer?.release()
        } catch (e: Exception) {}
        activeMediaPlayer = null
        activePlayingMsgId = null
    }

    override fun getItemCount(): Int = messages.size

    fun addMessage(msg: NetMessage) {
        messages.add(msg)
        notifyItemInserted(messages.size - 1)
    }

    fun markMessageDeleted(messageId: String) {
        val index = messages.indexOfFirst { it.id == messageId }
        if (index != -1) {
            messages[index].isDeleted = true
            notifyItemChanged(index)
        }
    }

    class MessageViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val bubbleContainer: View = view.findViewById(R.id.bubbleContainer)
        val txtContent: TextView = view.findViewById(R.id.txtContent)
        val txtSender: TextView = view.findViewById(R.id.txtSender)
        val txtTime: TextView = view.findViewById(R.id.txtTime)
        val txtStatus: TextView = view.findViewById(R.id.txtStatus)
        val txtEncryptedBadge: TextView = view.findViewById(R.id.txtEncryptedBadge)
        val layoutReplyQuote: View = view.findViewById(R.id.layoutReplyQuote)
        val txtReplySender: TextView = view.findViewById(R.id.txtReplySender)
        val txtReplyContent: TextView = view.findViewById(R.id.txtReplyContent)
        val imgMessage: ImageView = view.findViewById(R.id.imgMessage)
        val layoutVoiceNote: View = view.findViewById(R.id.layoutVoiceNote)
        val btnPlayVoice: ImageButton = view.findViewById(R.id.btnPlayVoice)
        val txtVoiceDuration: TextView = view.findViewById(R.id.txtVoiceDuration)
    }
}
