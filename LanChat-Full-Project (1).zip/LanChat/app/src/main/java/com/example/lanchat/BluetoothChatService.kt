package com.example.lanchat

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.Context
import kotlinx.coroutines.*
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.*

/**
 * BluetoothChatService manages Bluetooth connections (Classic RFCOMM / SPP)
 * for direct device-to-device offline messaging without Wi-Fi router.
 */
class BluetoothChatService(private val context: Context, private val onMessageReceived: (String) -> Unit) {

    private val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private var acceptThread: AcceptThread? = null
    private var connectedThread: ConnectedThread? = null

    companion object {
        private const val APP_NAME = "LanChatBluetooth"
        // Standard SPP UUID for Bluetooth RFCOMM Serial Port
        val MY_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    }

    fun isBluetoothSupported(): Boolean = bluetoothAdapter != null

    fun isBluetoothEnabled(): Boolean = bluetoothAdapter?.isEnabled == true

    @Synchronized
    fun start() {
        // Cancel any existing threads
        connectedThread?.cancel()
        connectedThread = null

        acceptThread?.cancel()
        acceptThread = AcceptThread()
        acceptThread?.start()
    }

    @Synchronized
    fun connect(device: BluetoothDevice) {
        scope.launch {
            try {
                val socket = device.createRfcommSocketToServiceRecord(MY_UUID)
                bluetoothAdapter?.cancelDiscovery()
                socket.connect()
                connected(socket)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    @Synchronized
    private fun connected(socket: BluetoothSocket) {
        acceptThread?.cancel()
        acceptThread = null

        connectedThread?.cancel()
        connectedThread = ConnectedThread(socket)
        connectedThread?.start()
    }

    fun write(message: String) {
        connectedThread?.write(message.toByteArray(Charsets.UTF_8))
    }

    fun stop() {
        acceptThread?.cancel()
        acceptThread = null
        connectedThread?.cancel()
        connectedThread = null
        scope.cancel()
    }

    // Listens for incoming Bluetooth RFCOMM connections
    private inner class AcceptThread : Thread() {
        private val serverSocket: BluetoothServerSocket? by lazy {
            try {
                bluetoothAdapter?.listenUsingRfcommWithServiceRecord(APP_NAME, MY_UUID)
            } catch (e: SecurityException) {
                null
            }
        }

        override fun run() {
            var socket: BluetoothSocket?
            while (true) {
                socket = try {
                    serverSocket?.accept()
                } catch (e: IOException) {
                    break
                }

                socket?.let {
                    connected(it)
                    try {
                        serverSocket?.close()
                    } catch (e: IOException) {}
                    return
                }
            }
        }

        fun cancel() {
            try {
                serverSocket?.close()
            } catch (e: IOException) {}
        }
    }

    // Handles read/write for an established Bluetooth socket
    private inner class ConnectedThread(private val socket: BluetoothSocket) : Thread() {
        private val inStream: InputStream = socket.inputStream
        private val outStream: OutputStream = socket.outputStream
        private val buffer = ByteArray(2048)

        override fun run() {
            var bytes: Int
            while (true) {
                try {
                    bytes = inStream.read(buffer)
                    val readMessage = String(buffer, 0, bytes, Charsets.UTF_8)
                    onMessageReceived(readMessage)
                } catch (e: IOException) {
                    break
                }
            }
        }

        fun write(bytes: ByteArray) {
            try {
                outStream.write(bytes)
            } catch (e: IOException) {}
        }

        fun cancel() {
            try {
                socket.close()
            } catch (e: IOException) {}
        }
    }
}
