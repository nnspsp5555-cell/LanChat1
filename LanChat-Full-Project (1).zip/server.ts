import express from 'express';
import http from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import os from 'os';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

function resolvePort(): number {
  const portArgIndex = process.argv.indexOf('--port');
  if (portArgIndex !== -1 && process.argv[portArgIndex + 1]) {
    return parseInt(process.argv[portArgIndex + 1], 10);
  }
  const defaultPort = parseInt(process.env.DEFAULT_APP_PORT || '3000', 10);
  const envPort = process.env.PORT ? parseInt(process.env.PORT, 10) : defaultPort;
  // If envPort is 8080 (which is the nginx ingress proxy), do not collide with nginx!
  if (envPort === 8080 || envPort === Number(process.env.NGINX_PORT)) {
    return defaultPort;
  }
  return envPort || 3000;
}

const PORT = resolvePort();
const server = http.createServer(app);

server.on('error', (err: any) => {
  console.error('Server HTTP error:', err);
});

// Setup upload directory
const UPLOADS_DIR = path.join(__dirname, 'uploads');
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

// Middleware
app.use(express.json({ limit: '60mb' }));
app.use(express.urlencoded({ limit: '60mb', extended: true }));

// Serve uploaded media statically
app.use('/uploads', express.static(UPLOADS_DIR));

// Helper: Get local network IPs (LAN/Wi-Fi)
function getLocalNetworkAddresses(): { address: string; family: string; interfaceName: string }[] {
  const interfaces = os.networkInterfaces();
  const addresses: { address: string; family: string; interfaceName: string }[] = [];

  for (const [name, netInterface] of Object.entries(interfaces)) {
    if (!netInterface) continue;
    for (const iface of netInterface) {
      // IPv4 only, skip loopback
      if (iface.family === 'IPv4' && !iface.internal) {
        addresses.push({
          address: iface.address,
          family: iface.family,
          interfaceName: name,
        });
      }
    }
  }
  return addresses;
}

// API: Local Network Information (for Wi-Fi peer discovery and connection)
app.get('/api/network-info', (req, res) => {
  const ips = getLocalNetworkAddresses();
  const clientIp = req.headers['x-forwarded-for']?.toString() || req.socket.remoteAddress || '127.0.0.1';

  res.json({
    status: 'ok',
    port: PORT,
    hostname: os.hostname(),
    platform: os.platform(),
    localIps: ips,
    clientIp,
    uptimeSeconds: Math.floor(process.uptime()),
    timestamp: Date.now(),
  });
});

// API: Download All-In-One Complete Project ZIP
app.get('/api/download-all-in-one', (req, res) => {
  const zipPath = path.join(__dirname, 'LanChat-Complete-All-In-One.zip');
  if (fs.existsSync(zipPath)) {
    res.setHeader('Content-Disposition', 'attachment; filename="LanChat-Complete-All-In-One.zip"');
    res.setHeader('Content-Type', 'application/zip');
    fs.createReadStream(zipPath).pipe(res);
  } else {
    res.status(404).json({ error: 'ملف المشروع غير موجود' });
  }
});

// API: Download LanChat Android Studio Project ZIP
app.get('/api/download-android-zip', (req, res) => {
  const zipPath = path.join(__dirname, 'LanChat.zip');
  if (fs.existsSync(zipPath)) {
    res.setHeader('Content-Disposition', 'attachment; filename="LanChat-Android-Project.zip"');
    res.setHeader('Content-Type', 'application/zip');
    fs.createReadStream(zipPath).pipe(res);
  } else {
    res.status(404).json({ error: 'ملف المشروع غير موجود' });
  }
});

// API: Download Complete GitHub Ready ZIP
app.get('/api/download-full-project-zip', (req, res) => {
  const zipPath = path.join(__dirname, 'Full-Project-GitHub.zip');
  if (fs.existsSync(zipPath)) {
    res.setHeader('Content-Disposition', 'attachment; filename="LanChat-Full-Project.zip"');
    res.setHeader('Content-Type', 'application/zip');
    fs.createReadStream(zipPath).pipe(res);
  } else {
    res.status(404).json({ error: 'ملف المشروع غير موجود' });
  }
});

// API: Discover Local Subnet Devices (ARP Table & Active IPs)
app.get('/api/discover-devices', (req, res) => {
  const devices: { ip: string; mac: string; type: string }[] = [];

  // Read Linux ARP table if available
  try {
    if (fs.existsSync('/proc/net/arp')) {
      const arpContent = fs.readFileSync('/proc/net/arp', 'utf-8');
      const lines = arpContent.split('\n').slice(1);
      for (const line of lines) {
        const parts = line.trim().split(/\s+/);
        if (parts.length >= 4 && parts[0] && parts[3] && parts[3] !== '00:00:00:00:00:00') {
          devices.push({
            ip: parts[0],
            mac: parts[3],
            type: 'هاتف أندرويد / جهاز على Wi-Fi',
          });
        }
      }
    }
  } catch (err) {
    console.warn('ARP inspection failed:', err);
  }

  res.json({
    status: 'ok',
    devices,
    count: devices.length,
    timestamp: Date.now(),
  });
});

// API: Upload Media or File
app.post('/api/upload', (req, res) => {
  try {
    const { fileName, fileType, dataUrl } = req.body;
    if (!dataUrl || !fileName) {
      return res.status(400).json({ error: 'بيانات الملف غير مكتملة' });
    }

    // Extract base64 data
    const matches = dataUrl.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
    let buffer: Buffer;
    let mimeType = fileType || 'application/octet-stream';

    if (matches && matches.length === 3) {
      mimeType = matches[1];
      buffer = Buffer.from(matches[2], 'base64');
    } else {
      buffer = Buffer.from(dataUrl, 'base64');
    }

    // Generate safe unique filename
    const safeBaseName = path.basename(fileName).replace(/[^a-zA-Z0-9._\-\u0600-\u06FF]/g, '_');
    const uniqueId = `${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
    const finalFileName = `${uniqueId}_${safeBaseName}`;
    const filePath = path.join(UPLOADS_DIR, finalFileName);

    fs.writeFileSync(filePath, buffer);

    const fileUrl = `/uploads/${encodeURIComponent(finalFileName)}`;

    return res.json({
      success: true,
      fileUrl,
      fileName,
      fileSize: buffer.length,
      fileType: mimeType,
    });
  } catch (error: any) {
    console.error('Error saving upload:', error);
    return res.status(500).json({ error: 'تعذر حفظ الملف على الخادم', details: error.message });
  }
});

// ================= WebSocket Server for Local Chat =================
interface ChatUser {
  id: string;
  name: string;
  avatar: string;
  deviceType: 'android' | 'mobile' | 'desktop' | 'tablet';
  status: 'online' | 'busy' | 'away' | 'offline';
  ip?: string;
  joinedAt: number;
}

interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  recipientId: 'public' | string;
  content: string;
  mediaType: 'text' | 'image' | 'video' | 'audio' | 'file';
  fileUrl?: string;
  fileName?: string;
  fileSize?: number;
  fileMime?: string;
  timestamp: number;
  replyTo?: {
    id: string;
    senderName: string;
    content: string;
  };
  isDeleted?: boolean;
  deletedForEveryone?: boolean;
}

const wss = new WebSocketServer({ server });

wss.on('error', (err) => {
  console.warn('WebSocketServer instance warning:', err);
});

const connectedClients = new Map<WebSocket, ChatUser>();
const userSockets = new Map<string, WebSocket>();

// Ring buffer of recent public messages for newly joined clients
const recentPublicMessages: ChatMessage[] = [];
const MAX_RECENT_MESSAGES = 100;

function broadcastUsersList() {
  const users: ChatUser[] = Array.from(connectedClients.values());
  const payload = JSON.stringify({
    type: 'users_list',
    users,
    count: users.length,
  });

  for (const client of wss.clients) {
    if (client.readyState === WebSocket.OPEN) {
      client.send(payload);
    }
  }
}

wss.on('connection', (ws: WebSocket, req) => {
  const remoteIp = req.headers['x-forwarded-for']?.toString() || req.socket.remoteAddress || '127.0.0.1';

  // Handle incoming client messages
  ws.on('message', (rawData: string) => {
    try {
      const data = JSON.parse(rawData.toString());

      switch (data.type) {
        case 'register': {
          const user: ChatUser = {
            id: data.user.id || `user_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
            name: (data.user.name || 'مستخدم مجهول').trim(),
            avatar: data.user.avatar || '⚡',
            deviceType: data.user.deviceType || 'android',
            status: data.user.status || 'online',
            ip: remoteIp,
            joinedAt: Date.now(),
          };

          connectedClients.set(ws, user);
          userSockets.set(user.id, ws);

          // Acknowledge registration with current state
          ws.send(JSON.stringify({
            type: 'registered',
            self: user,
            recentMessages: recentPublicMessages,
            users: Array.from(connectedClients.values()),
          }));

          // Notify all peers
          broadcastUsersList();
          break;
        }

        case 'update_profile': {
          const existing = connectedClients.get(ws);
          if (existing) {
            if (data.user.name) existing.name = data.user.name.trim();
            if (data.user.avatar) existing.avatar = data.user.avatar;
            if (data.user.status) existing.status = data.user.status;
            broadcastUsersList();
          }
          break;
        }

        case 'message': {
          const user = connectedClients.get(ws);
          if (!user) return;

          const msg: ChatMessage = {
            id: data.message.id || `msg_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
            senderId: user.id,
            senderName: user.name,
            senderAvatar: user.avatar,
            recipientId: data.message.recipientId || 'public',
            content: data.message.content || '',
            mediaType: data.message.mediaType || 'text',
            fileUrl: data.message.fileUrl,
            fileName: data.message.fileName,
            fileSize: data.message.fileSize,
            fileMime: data.message.fileMime,
            timestamp: Date.now(),
            replyTo: data.message.replyTo,
          };

          if (msg.recipientId === 'public' || msg.recipientId.startsWith('group_')) {
            // Save in ring buffer
            recentPublicMessages.push(msg);
            if (recentPublicMessages.length > MAX_RECENT_MESSAGES) {
              recentPublicMessages.shift();
            }

            // Broadcast to everyone on Wi-Fi
            const payload = JSON.stringify({ type: 'new_message', message: msg, isGroup: true });
            let deliveredToOther = false;
            for (const client of wss.clients) {
              if (client.readyState === WebSocket.OPEN) {
                client.send(payload);
                if (client !== ws) deliveredToOther = true;
              }
            }

            // If delivered to other peers on Wi-Fi, notify sender with double check
            if (deliveredToOther && ws.readyState === WebSocket.OPEN) {
              ws.send(
                JSON.stringify({
                  type: 'message_status',
                  messageId: msg.id,
                  status: 'delivered',
                  recipientId: msg.recipientId,
                })
              );
            }
          } else {
            // Private message: deliver to target user and echo to sender
            const recipientSocket = userSockets.get(msg.recipientId);
            const payload = JSON.stringify({ type: 'new_message', message: msg, isPrivate: true });
            let isDelivered = false;

            if (recipientSocket && recipientSocket.readyState === WebSocket.OPEN) {
              recipientSocket.send(payload);
              isDelivered = true;
            }

            // Echo back to sender
            if (ws.readyState === WebSocket.OPEN) {
              ws.send(payload);
              if (isDelivered) {
                ws.send(
                  JSON.stringify({
                    type: 'message_status',
                    messageId: msg.id,
                    status: 'delivered',
                    recipientId: msg.recipientId,
                  })
                );
              }
            }
          }
          break;
        }

        case 'delivery_ack': {
          if (!data.senderId || !data.messageId) break;
          const senderSocket = userSockets.get(data.senderId);
          if (senderSocket && senderSocket.readyState === WebSocket.OPEN) {
            senderSocket.send(
              JSON.stringify({
                type: 'message_status',
                messageId: data.messageId,
                status: 'delivered',
                recipientId: data.recipientId,
              })
            );
          }
          break;
        }

        case 'typing': {
          const user = connectedClients.get(ws);
          if (!user) return;

          const recipientId = data.recipientId || 'public';
          const payload = JSON.stringify({
            type: 'user_typing',
            senderId: user.id,
            senderName: user.name,
            recipientId,
            isTyping: !!data.isTyping,
          });

          if (recipientId === 'public') {
            for (const client of wss.clients) {
              if (client !== ws && client.readyState === WebSocket.OPEN) {
                client.send(payload);
              }
            }
          } else {
            const recipientSocket = userSockets.get(recipientId);
            if (recipientSocket && recipientSocket.readyState === WebSocket.OPEN) {
              recipientSocket.send(payload);
            }
          }
          break;
        }

        case 'nudge': {
          // Buzz / Nudge user to draw attention
          const user = connectedClients.get(ws);
          if (!user) return;

          const targetId = data.targetId;
          const payload = JSON.stringify({
            type: 'nudge_alert',
            senderName: user.name,
            targetId,
          });

          if (targetId === 'public') {
            for (const client of wss.clients) {
              if (client !== ws && client.readyState === WebSocket.OPEN) {
                client.send(payload);
              }
            }
          } else {
            const recipientSocket = userSockets.get(targetId);
            if (recipientSocket && recipientSocket.readyState === WebSocket.OPEN) {
              recipientSocket.send(payload);
            }
          }
          break;
        }

        case 'delete_message': {
          const user = connectedClients.get(ws);
          if (!user) return;

          const { messageId, recipientId, forEveryone } = data;
          if (!messageId) break;

          // Update message in memory buffer if found
          const existing = recentPublicMessages.find((m) => m.id === messageId);
          if (existing) {
            existing.isDeleted = true;
            existing.deletedForEveryone = !!forEveryone;
            existing.content = 'تم حذف هذه الرسالة';
            existing.fileUrl = undefined;
            existing.fileName = undefined;
          }

          const deletePayload = JSON.stringify({
            type: 'message_deleted',
            messageId,
            recipientId: recipientId || 'public',
            deletedBy: user.id,
            forEveryone: !!forEveryone,
          });

          if (recipientId === 'public' || (recipientId && recipientId.startsWith('group_'))) {
            for (const client of wss.clients) {
              if (client.readyState === WebSocket.OPEN) {
                client.send(deletePayload);
              }
            }
          } else {
            const recipientSocket = userSockets.get(recipientId);
            if (recipientSocket && recipientSocket.readyState === WebSocket.OPEN) {
              recipientSocket.send(deletePayload);
            }
            if (ws.readyState === WebSocket.OPEN) {
              ws.send(deletePayload);
            }
          }
          break;
        }

        case 'call_signal': {
          // WebRTC / Voice Call Signaling for local offline calls
          const user = connectedClients.get(ws);
          if (!user) return;

          const { targetUserId, signalType, payload } = data;
          if (!targetUserId) break;

          const targetSocket = userSockets.get(targetUserId);
          if (targetSocket && targetSocket.readyState === WebSocket.OPEN) {
            targetSocket.send(
              JSON.stringify({
                type: 'call_signal',
                fromUser: user,
                targetUserId,
                signalType,
                payload,
              })
            );
          } else {
            // Target is offline or unavailable
            if (signalType === 'offer') {
              ws.send(
                JSON.stringify({
                  type: 'call_signal',
                  fromUser: { id: targetUserId, name: 'مستخدم' },
                  targetUserId: user.id,
                  signalType: 'unavailable',
                  payload: { reason: 'offline' },
                })
              );
            }
          }
          break;
        }

        case 'ping': {
          ws.send(JSON.stringify({ type: 'pong', timestamp: Date.now() }));
          break;
        }
      }
    } catch (err) {
      console.error('Error handling WebSocket message:', err);
    }
  });

  ws.on('close', () => {
    const user = connectedClients.get(ws);
    if (user) {
      userSockets.delete(user.id);
      connectedClients.delete(ws);
      broadcastUsersList();
    }
  });

  ws.on('error', (err) => {
    console.error('WebSocket connection error:', err);
  });
});

// Setup Vite middlewares in development or static serve in production
async function startServer() {
  const isDev = process.env.NODE_ENV !== 'production';

  if (isDev) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR === 'true' ? false : { server },
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get('*', (req, res) => {
        res.sendFile(path.join(distPath, 'index.html'));
      });
    }
  }

  server.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`=======================================================`);
    console.log(`🚀 خادم الدردشة بدون إنترنت يعمل بنجاح على المنفذ: ${PORT}`);
    console.log(`🌐 العناوين المتاحة على شبكة Wi-Fi المحلية:`);
    const ips = getLocalNetworkAddresses();
    if (ips.length > 0) {
      ips.forEach((ip) => {
        console.log(`   👉 http://${ip.address}:${PORT} (${ip.interfaceName})`);
      });
    } else {
      console.log(`   👉 http://localhost:${PORT}`);
    }
    console.log(`📱 افتح هذا الرابط من أي هاتف أندرويد متصل بنفس الشبكة!`);
    console.log(`=======================================================`);
  });
}

startServer().catch((err) => {
  console.error('فشل بدء تشغيل الخادم:', err);
});
