// Offline WebRTC & Local LAN Audio Streaming Call Manager
// 100% works without internet using local Wi-Fi / hotspot IP candidates

import { User, ActiveCallState } from '../types/chat';
import { sound } from './sound';

export type CallSignalSender = (targetUserId: string, signalType: string, payload: any) => void;

class WebRtcCallManager {
  private peerConnection: RTCPeerConnection | null = null;
  private localStream: MediaStream | null = null;
  private remoteAudio: HTMLAudioElement | null = null;
  private stateListener: ((state: ActiveCallState | null) => void) | null = null;
  private durationInterval: any = null;
  private mediaRecorder: MediaRecorder | null = null;
  private sendSignalFn: CallSignalSender | null = null;

  private currentState: ActiveCallState | null = null;

  setStateListener(listener: (state: ActiveCallState | null) => void) {
    this.stateListener = listener;
  }

  setSignalSender(fn: CallSignalSender) {
    this.sendSignalFn = fn;
  }

  getState(): ActiveCallState | null {
    return this.currentState;
  }

  private updateState(partial: Partial<ActiveCallState> | null) {
    if (partial === null) {
      this.currentState = null;
    } else if (this.currentState) {
      this.currentState = { ...this.currentState, ...partial };
    }
    if (this.stateListener) {
      this.stateListener(this.currentState);
    }
  }

  // Start outgoing call to peer
  async startCall(targetPeer: User, currentUser: User): Promise<boolean> {
    try {
      this.stopAll();

      // Acquire microphone
      this.localStream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
        video: false,
      });

      const callId = `call_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
      this.currentState = {
        callId,
        peer: targetPeer,
        isCaller: true,
        status: 'calling',
        durationSeconds: 0,
        isMuted: false,
        isSpeaker: true,
      };
      this.updateState({});

      // Play outgoing ring sound
      sound.startOutgoingRing();

      // Create WebRTC PeerConnection with no external STUN (LAN offline mode)
      this.setupPeerConnection(targetPeer.id);

      // Create Offer
      if (this.peerConnection) {
        const offer = await this.peerConnection.createOffer();
        await this.peerConnection.setLocalDescription(offer);

        if (this.sendSignalFn) {
          this.sendSignalFn(targetPeer.id, 'offer', {
            callId,
            sdp: offer,
            caller: currentUser,
          });
        }
      }

      // Start fallback audio chunk sender
      this.startAudioStreaming(targetPeer.id);

      return true;
    } catch (err: any) {
      console.warn('Could not start call:', err);
      sound.stopRing();
      alert('تعذر الوصول إلى الميكروفون للاتصال الصوتي. يرجى السماح بصلاحية الميكروفون.');
      this.stopAll();
      return false;
    }
  }

  // Handle incoming call signal from WebSocket
  async handleIncomingSignal(fromUser: User, signalType: string, payload: any) {
    switch (signalType) {
      case 'offer': {
        // If already in a call, send busy signal
        if (this.currentState && this.currentState.status !== 'idle') {
          if (this.sendSignalFn) {
            this.sendSignalFn(fromUser.id, 'busy', { callId: payload?.callId });
          }
          return;
        }

        // Incoming call received
        const callId = payload?.callId || `call_${Date.now()}`;
        this.currentState = {
          callId,
          peer: fromUser,
          isCaller: false,
          status: 'incoming',
          durationSeconds: 0,
          isMuted: false,
          isSpeaker: true,
        };
        this.updateState({});

        // Store offer SDP for when user accepts
        (this as any).pendingOffer = payload?.sdp;

        // Play incoming ringtone
        sound.startIncomingRing();
        break;
      }

      case 'answer': {
        if (this.peerConnection && payload?.sdp) {
          try {
            await this.peerConnection.setRemoteDescription(new RTCSessionDescription(payload.sdp));
          } catch (e) {
            console.warn('Error setting remote description:', e);
          }
        }
        // Connected!
        this.onCallConnected();
        break;
      }

      case 'candidate': {
        if (this.peerConnection && payload?.candidate) {
          try {
            await this.peerConnection.addIceCandidate(new RTCIceCandidate(payload.candidate));
          } catch (e) {
            console.warn('Error adding ICE candidate:', e);
          }
        }
        break;
      }

      case 'audio_chunk': {
        // Fallback audio playback through Web Audio API
        if (payload?.audioData && this.currentState?.status === 'connected') {
          this.playAudioChunk(payload.audioData);
        }
        break;
      }

      case 'reject': {
        sound.stopRing();
        sound.playCallEnded();
        this.updateState({ status: 'ended' });
        setTimeout(() => this.stopAll(), 1500);
        break;
      }

      case 'busy': {
        sound.stopRing();
        sound.playCallEnded();
        alert('المستخدم مشغول في مكالمة أخرى حالياً.');
        this.stopAll();
        break;
      }

      case 'unavailable': {
        sound.stopRing();
        sound.playCallEnded();
        alert('المستخدم غير متصل حالياً بالشبكة المحلية.');
        this.stopAll();
        break;
      }

      case 'hangup': {
        sound.stopRing();
        sound.playCallEnded();
        this.updateState({ status: 'ended' });
        setTimeout(() => this.stopAll(), 1200);
        break;
      }
    }
  }

  // Callee accepts incoming call
  async acceptCall(): Promise<void> {
    if (!this.currentState || !this.currentState.peer) return;
    sound.stopRing();

    try {
      this.localStream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
        video: false,
      });

      this.setupPeerConnection(this.currentState.peer.id);

      const pendingOffer = (this as any).pendingOffer;
      if (this.peerConnection && pendingOffer) {
        await this.peerConnection.setRemoteDescription(new RTCSessionDescription(pendingOffer));
        const answer = await this.peerConnection.createAnswer();
        await this.peerConnection.setLocalDescription(answer);

        if (this.sendSignalFn) {
          this.sendSignalFn(this.currentState.peer.id, 'answer', {
            callId: this.currentState.callId,
            sdp: answer,
          });
        }
      }

      this.startAudioStreaming(this.currentState.peer.id);
      this.onCallConnected();
    } catch (err) {
      console.warn('Accept call error:', err);
      alert('تعذر فتح الميكروفون.');
      this.rejectCall();
    }
  }

  // Callee rejects incoming call
  rejectCall() {
    sound.stopRing();
    if (this.currentState && this.currentState.peer && this.sendSignalFn) {
      this.sendSignalFn(this.currentState.peer.id, 'reject', {
        callId: this.currentState.callId,
      });
    }
    this.stopAll();
  }

  // End active call or cancel outgoing
  endCall() {
    sound.stopRing();
    sound.playCallEnded();
    if (this.currentState && this.currentState.peer && this.sendSignalFn) {
      this.sendSignalFn(this.currentState.peer.id, 'hangup', {
        callId: this.currentState.callId,
      });
    }
    this.updateState({ status: 'ended' });
    setTimeout(() => this.stopAll(), 1000);
  }

  // Toggle microphone mute
  toggleMute(): boolean {
    if (!this.localStream) return false;
    const audioTrack = this.localStream.getAudioTracks()[0];
    if (audioTrack) {
      audioTrack.enabled = !audioTrack.enabled;
      const isMuted = !audioTrack.enabled;
      this.updateState({ isMuted });
      return isMuted;
    }
    return false;
  }

  // Toggle speakerphone (volume output)
  toggleSpeaker(): boolean {
    if (!this.currentState) return false;
    const isSpeaker = !this.currentState.isSpeaker;
    if (this.remoteAudio) {
      this.remoteAudio.volume = isSpeaker ? 1.0 : 0.4;
    }
    this.updateState({ isSpeaker });
    return isSpeaker;
  }

  private onCallConnected() {
    sound.stopRing();
    sound.playCallConnected();

    this.updateState({
      status: 'connected',
      startTime: Date.now(),
      durationSeconds: 0,
    });

    if (this.durationInterval) clearInterval(this.durationInterval);
    this.durationInterval = setInterval(() => {
      if (this.currentState && this.currentState.status === 'connected') {
        this.updateState({
          durationSeconds: this.currentState.durationSeconds + 1,
        });
      }
    }, 1000);
  }

  private setupPeerConnection(targetUserId: string) {
    // Offline local configuration: no STUN server needed on LAN
    const config: RTCConfiguration = {
      iceServers: [],
      iceCandidatePoolSize: 2,
    };

    this.peerConnection = new RTCPeerConnection(config);

    if (this.localStream) {
      this.localStream.getTracks().forEach((track) => {
        this.peerConnection?.addTrack(track, this.localStream!);
      });
    }

    this.peerConnection.onicecandidate = (event) => {
      if (event.candidate && this.sendSignalFn) {
        this.sendSignalFn(targetUserId, 'candidate', {
          candidate: event.candidate,
        });
      }
    };

    this.peerConnection.ontrack = (event) => {
      if (event.streams && event.streams[0]) {
        if (!this.remoteAudio) {
          this.remoteAudio = new Audio();
          this.remoteAudio.autoplay = true;
        }
        this.remoteAudio.srcObject = event.streams[0];
        this.remoteAudio.play().catch(() => {});
      }
    };

    this.peerConnection.onconnectionstatechange = () => {
      if (this.peerConnection?.connectionState === 'connected') {
        this.onCallConnected();
      } else if (
        this.peerConnection?.connectionState === 'disconnected' ||
        this.peerConnection?.connectionState === 'failed'
      ) {
        console.log('WebRTC connection state changed, relying on local audio streaming fallback');
      }
    };
  }

  // Reliable offline audio chunk streaming fallback via WebSocket
  private startAudioStreaming(targetUserId: string) {
    if (!this.localStream) return;
    try {
      const mimeType = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
        ? 'audio/webm;codecs=opus'
        : 'audio/webm';

      this.mediaRecorder = new MediaRecorder(this.localStream, { mimeType });
      this.mediaRecorder.ondataavailable = async (e) => {
        if (e.data.size > 0 && this.currentState?.status === 'connected' && this.sendSignalFn) {
          const reader = new FileReader();
          reader.onloadend = () => {
            const base64 = reader.result as string;
            this.sendSignalFn!(targetUserId, 'audio_chunk', { audioData: base64 });
          };
          reader.readAsDataURL(e.data);
        }
      };

      // Emit slices every 400ms for smooth low-latency voice transfer
      this.mediaRecorder.start(400);
    } catch (e) {
      console.warn('Audio streaming fallback init error:', e);
    }
  }

  private playAudioChunk(base64Data: string) {
    try {
      const audio = new Audio(base64Data);
      audio.volume = this.currentState?.isSpeaker ? 1.0 : 0.5;
      audio.play().catch(() => {});
    } catch {}
  }

  private stopAll() {
    sound.stopRing();
    if (this.durationInterval) {
      clearInterval(this.durationInterval);
      this.durationInterval = null;
    }
    if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
      try {
        this.mediaRecorder.stop();
      } catch {}
      this.mediaRecorder = null;
    }
    if (this.localStream) {
      this.localStream.getTracks().forEach((t) => t.stop());
      this.localStream = null;
    }
    if (this.peerConnection) {
      this.peerConnection.close();
      this.peerConnection = null;
    }
    if (this.remoteAudio) {
      this.remoteAudio.srcObject = null;
      this.remoteAudio = null;
    }
    this.updateState(null);
  }
}

export const webrtcCallManager = new WebRtcCallManager();
