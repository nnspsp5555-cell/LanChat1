import { ChatMessage, ThemeSettings, User, ChatGroup } from '../types/chat';

const STORAGE_KEYS = {
  USER: 'wifi_chat_user',
  PUBLIC_MESSAGES: 'wifi_chat_public_messages',
  PRIVATE_MESSAGES: 'wifi_chat_private_messages',
  GROUP_MESSAGES: 'wifi_chat_group_messages',
  GROUPS: 'wifi_chat_groups',
  SETTINGS: 'wifi_chat_settings',
};

export const defaultGroups: ChatGroup[] = [
  {
    id: 'public',
    name: 'الغرفة العامة (الجميع)',
    avatar: '🌐',
    description: 'محادثة عامة مفتوحة لجميع أجهزة شبكة Wi-Fi',
    isProtected: true,
    createdAt: 1,
  },
  {
    id: 'group_al_issa',
    name: 'مجموعة آل عيسى',
    avatar: '👑',
    description: 'المجموعة الرسمية لآل عيسى على الشبكة',
    isProtected: true,
    createdAt: 2,
  },
  {
    id: 'group_family',
    name: 'العائلة والمنزل',
    avatar: '🏡',
    description: 'دردشة الأهل والعائلة بدون إنترنت',
    isProtected: true,
    createdAt: 3,
  },
  {
    id: 'group_work',
    name: 'العمل وتبادل الملفات',
    avatar: '💼',
    description: 'مشاركة المستندات والملفات السريعة',
    isProtected: true,
    createdAt: 4,
  },
];

export const defaultSettings: ThemeSettings = {
  preset: 'slate',
  pattern: 'dots',
  accent: 'cyan',
  fontSize: 'md',
  soundEnabled: true,
  vibrationEnabled: true,
  encryptionEnabled: true,
  secretPassphrase: '',
};

export function getStoredUser(): Partial<User> | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.USER);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function saveStoredUser(user: Partial<User>) {
  try {
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
  } catch (e) {
    console.error('Failed to save user profile:', e);
  }
}

export function getStoredSettings(): ThemeSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    return raw ? { ...defaultSettings, ...JSON.parse(raw) } : defaultSettings;
  } catch {
    return defaultSettings;
  }
}

export function saveStoredSettings(settings: ThemeSettings) {
  try {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  } catch (e) {
    console.error('Failed to save settings:', e);
  }
}

export function getStoredPublicMessages(): ChatMessage[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PUBLIC_MESSAGES);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveStoredPublicMessages(messages: ChatMessage[]) {
  try {
    // Keep max 500 local messages to avoid localStorage quota limits
    const trimmed = messages.slice(-500);
    localStorage.setItem(STORAGE_KEYS.PUBLIC_MESSAGES, JSON.stringify(trimmed));
  } catch (e) {
    console.warn('LocalStorage limit reached when saving public messages:', e);
  }
}

export function getStoredPrivateMessages(): Record<string, ChatMessage[]> {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PRIVATE_MESSAGES);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function saveStoredPrivateMessages(records: Record<string, ChatMessage[]>) {
  try {
    localStorage.setItem(STORAGE_KEYS.PRIVATE_MESSAGES, JSON.stringify(records));
  } catch (e) {
    console.warn('LocalStorage limit reached when saving private messages:', e);
  }
}

export function exportChatHistory(messages: ChatMessage[], filename: string = 'wifi-chat-backup.json') {
  const blob = new Blob([JSON.stringify(messages, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function exportChatAsText(messages: ChatMessage[], title: string = 'محادثة شبكة Wi-Fi') {
  let text = `========================================\nسجل: ${title}\nتاريخ التصدير: ${new Date().toLocaleString('ar-SA')}\n========================================\n\n`;

  messages.forEach((m) => {
    const time = new Date(m.timestamp).toLocaleTimeString('ar-SA');
    const sender = m.senderName;
    const mediaNotice = m.mediaType !== 'text' ? ` [مرفق: ${m.mediaType} ${m.fileName || ''}]` : '';
    text += `[${time}] ${sender}: ${m.content}${mediaNotice}\n`;
  });

  const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${title}-${Date.now()}.txt`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function getStoredGroups(): ChatGroup[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.GROUPS);
    if (!raw) return defaultGroups;
    const parsed: ChatGroup[] = JSON.parse(raw);
    // Ensure all default groups exist
    const defaultIds = new Set(defaultGroups.map((g) => g.id));
    const customGroups = parsed.filter((g) => !defaultIds.has(g.id));
    return [...defaultGroups, ...customGroups];
  } catch {
    return defaultGroups;
  }
}

export function saveStoredGroups(groups: ChatGroup[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.GROUPS, JSON.stringify(groups));
  } catch (e) {
    console.warn('LocalStorage limit when saving groups:', e);
  }
}

export function getStoredGroupMessages(): Record<string, ChatMessage[]> {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.GROUP_MESSAGES);
    const parsed = raw ? JSON.parse(raw) : {};
    // Ensure public messages are populated if available
    const pub = getStoredPublicMessages();
    if (pub.length > 0 && (!parsed['public'] || parsed['public'].length === 0)) {
      parsed['public'] = pub;
    }
    return parsed;
  } catch {
    return { public: getStoredPublicMessages() };
  }
}

export function saveStoredGroupMessages(records: Record<string, ChatMessage[]>) {
  try {
    localStorage.setItem(STORAGE_KEYS.GROUP_MESSAGES, JSON.stringify(records));
    if (records['public']) {
      saveStoredPublicMessages(records['public']);
    }
  } catch (e) {
    console.warn('LocalStorage limit when saving group messages:', e);
  }
}

export function clearAllLocalChatHistory() {
  localStorage.removeItem(STORAGE_KEYS.PUBLIC_MESSAGES);
  localStorage.removeItem(STORAGE_KEYS.PRIVATE_MESSAGES);
  localStorage.removeItem(STORAGE_KEYS.GROUP_MESSAGES);
}
