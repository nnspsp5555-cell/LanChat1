// Simple & robust client-side AES-GCM encryption using native Web Crypto API
// 100% offline, zero external dependencies

const DEFAULT_KEY_PHRASE = 'lanchat-local-wifi-secure-key-2026';

// Derive an AES-GCM CryptoKey from a passphrase
async function deriveKey(passphrase: string): Promise<CryptoKey> {
  const enc = new TextEncoder();
  const keyMaterial = await window.crypto.subtle.importKey(
    'raw',
    enc.encode(passphrase),
    { name: 'PBKDF2' },
    false,
    ['deriveKey']
  );

  // Salt for local network chat key derivation
  const salt = enc.encode('wifi-chat-salt-local');

  return window.crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt,
      iterations: 50000,
      hash: 'SHA-256',
    },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

// Encrypt a plain text string into Base64 format: IV + Ciphertext
export async function encryptText(text: string, customKey?: string): Promise<string> {
  if (!text) return '';
  try {
    const key = await deriveKey(customKey || DEFAULT_KEY_PHRASE);
    const iv = window.crypto.getRandomValues(new Uint8Array(12));
    const encoded = new TextEncoder().encode(text);

    const ciphertext = await window.crypto.subtle.encrypt(
      {
        name: 'AES-GCM',
        iv,
      },
      key,
      encoded
    );

    // Combine IV (12 bytes) + Ciphertext into one buffer
    const combined = new Uint8Array(iv.length + ciphertext.byteLength);
    combined.set(iv, 0);
    combined.set(new Uint8Array(ciphertext), iv.length);

    // Convert to Base64 with 'enc:' prefix so receivers know it's encrypted
    let binary = '';
    combined.forEach((b) => (binary += String.fromCharCode(b)));
    return 'enc:' + btoa(binary);
  } catch (err) {
    console.error('Encryption error, sending fallback:', err);
    return text;
  }
}

// Decrypt ciphertext. If not encrypted or fails, safely returns original text.
export async function decryptText(encryptedText: string, customKey?: string): Promise<string> {
  if (!encryptedText) return '';
  if (!encryptedText.startsWith('enc:')) {
    // Already plain text
    return encryptedText;
  }

  try {
    const key = await deriveKey(customKey || DEFAULT_KEY_PHRASE);
    const base64Data = encryptedText.substring(4);
    const binary = atob(base64Data);
    const combined = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      combined[i] = binary.charCodeAt(i);
    }

    const iv = combined.slice(0, 12);
    const ciphertext = combined.slice(12);

    const decrypted = await window.crypto.subtle.decrypt(
      {
        name: 'AES-GCM',
        iv,
      },
      key,
      ciphertext
    );

    return new TextDecoder().decode(decrypted);
  } catch (err) {
    // If decryption fails (e.g. wrong key), return placeholder
    return '[رسالة مشفرة 🔒 - مفتاح فك التشفير غير متطابق]';
  }
}
