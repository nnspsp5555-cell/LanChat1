export type DeviceType = 'android' | 'mobile' | 'desktop' | 'tablet';

export type UserStatus = 'online' | 'busy' | 'away' | 'offline';

export interface User {
  id: string;
  name: string;
  avatar: string;
  deviceType: DeviceType;
  status: UserStatus;
  ip?: string;
  joinedAt: number;
  hasCustomName?: boolean;
}

export type MediaType = 'text' | 'image' | 'video' | 'audio' | 'file';

export interface ReplyContext {
  id: string;
  senderName: string;
  content: string;
  mediaType?: MediaType;
}

export interface ChatGroup {
  id: string; // 'public' | 'group_al_issa' | string
  name: string;
  avatar: string;
  description: string;
  isProtected?: boolean;
  createdAt: number;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  recipientId: 'public' | string; // 'public' or recipient's userId
  content: string;
  mediaType: MediaType;
  fileUrl?: string;
  fileName?: string;
  fileSize?: number;
  fileMime?: string;
  timestamp: number;
  replyTo?: ReplyContext;
  isEncrypted?: boolean;
  status?: 'sending' | 'sent' | 'delivered' | 'read';
  isDeleted?: boolean;
  deletedForEveryone?: boolean;
}

export type ThemePreset = 'slate' | 'navy' | 'amoled' | 'emerald' | 'violet';
export type PatternStyle = 'none' | 'dots' | 'grid' | 'waves';
export type AccentColor = 'cyan' | 'emerald' | 'violet' | 'amber' | 'rose' | 'sky';
export type FontSize = 'sm' | 'md' | 'lg';

export interface ThemeSettings {
  preset: ThemePreset;
  pattern: PatternStyle;
  accent: AccentColor;
  fontSize: FontSize;
  soundEnabled: boolean;
  vibrationEnabled: boolean;
  encryptionEnabled: boolean;
  secretPassphrase?: string;
}

export interface NetworkInfo {
  port: number;
  hostname: string;
  platform: string;
  localIps: { address: string; family: string; interfaceName: string }[];
  clientIp: string;
  uptimeSeconds: number;
  timestamp: number;
}

export type ConnectionMode = 'wifi' | 'bluetooth';

export interface BluetoothDevicePeer {
  id: string;
  name: string;
  connected: boolean;
  rssi?: number;
  lastSeen: number;
}

export type CallStatus = 'idle' | 'calling' | 'incoming' | 'connected' | 'ended';

export interface ActiveCallState {
  callId: string;
  peer: User;
  isCaller: boolean;
  status: CallStatus;
  startTime?: number;
  durationSeconds: number;
  isMuted: boolean;
  isSpeaker: boolean;
}

