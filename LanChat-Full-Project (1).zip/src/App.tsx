import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  User,
  ChatMessage,
  ThemeSettings,
  NetworkInfo,
  ReplyContext,
  ChatGroup,
  ConnectionMode,
  ActiveCallState,
  UserStatus,
} from './types/chat';
import {
  getStoredUser,
  saveStoredUser,
  getStoredSettings,
  saveStoredSettings,
  getStoredPrivateMessages,
  saveStoredPrivateMessages,
  getStoredGroups,
  saveStoredGroups,
  getStoredGroupMessages,
  saveStoredGroupMessages,
} from './utils/storage';
import { detectDeviceType } from './utils/media';
import { sound } from './utils/sound';
import { Navbar } from './components/Navbar';
import { PeersList } from './components/PeersList';
import { ChatArea } from './components/ChatArea';
import { NetworkModal } from './components/NetworkModal';
import { SettingsModal } from './components/SettingsModal';
import { MediaLightbox } from './components/MediaLightbox';
import { InstallModal } from './components/InstallModal';
import { VoiceCallModal } from './components/VoiceCallModal';
import { WelcomeNameModal } from './components/WelcomeNameModal';
import { encryptText, decryptText } from './utils/crypto';
import { webrtcCallManager } from './utils/webrtcCall';

export default function App() {
  // User state
  const [currentUser, setCurrentUser] = useState<User>(() => {
    const saved = getStoredUser();
    const devType = detectDeviceType();
    const defaultAvatars = ['👑', '⚡', '🤖', '🚀', '🌟', '🦁', '🔥'];
    const randomAvatar = defaultAvatars[Math.floor(Math.random() * defaultAvatars.length)];

    const hasExplicitName = Boolean(
      saved?.hasCustomName &&
      saved?.name &&
      saved.name.trim() !== '' &&
      saved.name !== 'مستخدم أندرويد' &&
      saved.name !== 'مستخدم محلي'
    );

    return {
      id: saved?.id || `user_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      name: hasExplicitName ? (saved!.name as string) : (saved?.name || ''),
      avatar: saved?.avatar || randomAvatar,
      deviceType: saved?.deviceType || devType,
      status: saved?.status || 'online',
      joinedAt: saved?.joinedAt || Date.now(),
      hasCustomName: hasExplicitName,
    };
  });

  // Modal to prompt every user to add their name on entry
  const [isNameModalOpen, setIsNameModalOpen] = useState<boolean>(() => {
    const saved = getStoredUser();
    const hasExplicitName = Boolean(
      saved?.hasCustomName &&
      saved?.name &&
      saved.name.trim() !== '' &&
      saved.name !== 'مستخدم أندرويد' &&
      saved.name !== 'مستخدم محلي'
    );
    return !hasExplicitName;
  });

  // Persist user profile when updated
  useEffect(() => {
    if (currentUser.hasCustomName) {
      saveStoredUser(currentUser);
    }
  }, [currentUser]);

  // Settings & Theme
  const [settings, setSettings] = useState<ThemeSettings>(getStoredSettings);

  // Connection & Peers
  const [isConnected, setIsConnected] = useState(false);
  const [connectionMode, setConnectionMode] = useState<ConnectionMode>('wifi');
  const [activeCall, setActiveCall] = useState<ActiveCallState | null>(null);
  const [peers, setPeers] = useState<User[]>([]);
  const [activeChatId, setActiveChatId] = useState<string>('public'); // 'public' or userId
  const [networkInfo, setNetworkInfo] = useState<NetworkInfo | null>(null);

  // Groups & Messages
  const [groups, setGroups] = useState<ChatGroup[]>(getStoredGroups);
  const [groupMessages, setGroupMessages] = useState<Record<string, ChatMessage[]>>(
    getStoredGroupMessages
  );
  const [privateMessages, setPrivateMessages] = useState<Record<string, ChatMessage[]>>(
    getStoredPrivateMessages
  );
  const [unreadCounts, setUnreadCounts] = useState<Record<string, number>>({});

  // Group handlers
  const handleCreateGroup = (name: string, avatar: string, description: string) => {
    const newGroup: ChatGroup = {
      id: `group_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      name,
      avatar: avatar || '👥',
      description: description || 'مجموعة محلية جديدة على Wi-Fi',
      isProtected: false,
      createdAt: Date.now(),
    };
    setGroups((prev) => [...prev, newGroup]);
    setActiveChatId(newGroup.id);
  };

  const handleDeleteGroup = (groupId: string) => {
    setGroups((prev) => prev.filter((g) => g.id !== groupId));
    if (activeChatId === groupId) {
      setActiveChatId('public');
    }
  };

  useEffect(() => {
    saveStoredGroups(groups);
  }, [groups]);

  useEffect(() => {
    saveStoredGroupMessages(groupMessages);
  }, [groupMessages]);

  // Typing state
  const [typingUsers, setTypingUsers] = useState<{ id: string; name: string }[]>([]);

  // Modals & Drawers
  const [isNetworkModalOpen, setIsNetworkModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);
  const [isMobileDrawerOpen, setIsMobileDrawerOpen] = useState(false);
  const [mobileView, setMobileView] = useState<'list' | 'chat'>('chat');
  const [isSearching, setIsSearching] = useState(false);
  const [lightboxImage, setLightboxImage] = useState<{ url: string; fileName?: string } | null>(
    null
  );
  const [isShaking, setIsShaking] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  // Capture PWA install prompt event
  useEffect(() => {
    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
  }, []);

  const handleInstallNative = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice;
      if (choice.outcome === 'accepted') {
        setDeferredPrompt(null);
        setIsInstallModalOpen(false);
      }
    }
  };

  // WebSocket ref
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<any>(null);
  const pingIntervalRef = useRef<any>(null);

  // WebRTC Call Manager setup for offline LAN calls
  useEffect(() => {
    webrtcCallManager.setStateListener((callState) => {
      setActiveCall(callState);
    });

    webrtcCallManager.setSignalSender((targetUserId, signalType, payload) => {
      if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
        wsRef.current.send(
          JSON.stringify({
            type: 'call_signal',
            targetUserId,
            signalType,
            payload,
          })
        );
      }
    });
  }, []);

  const handleStartVoiceCall = (peer: User) => {
    webrtcCallManager.startCall(peer, currentUser);
  };

  // Fetch local network info from Express API
  const fetchNetworkInfo = async () => {
    try {
      const res = await fetch('/api/network-info');
      if (res.ok) {
        const data = await res.json();
        setNetworkInfo(data);
        if (data.clientIp) {
          setCurrentUser((prev) => ({ ...prev, ip: data.clientIp }));
        }
      }
    } catch (err) {
      console.warn('Network info endpoint unreachable:', err);
    }
  };

  useEffect(() => {
    fetchNetworkInfo();
  }, []);

  // Save changes to storage
  useEffect(() => {
    saveStoredUser(currentUser);
  }, [currentUser]);

  useEffect(() => {
    saveStoredSettings(settings);
  }, [settings]);

  useEffect(() => {
    saveStoredPrivateMessages(privateMessages);
  }, [privateMessages]);

  // Connect WebSocket
  useEffect(() => {
    let isMounted = true;

    function connectWs() {
      if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) return;

      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}`;

      try {
        const ws = new WebSocket(wsUrl);
        wsRef.current = ws;

        ws.onopen = () => {
          if (!isMounted) return;
          setIsConnected(true);

          // Register client with server
          ws.send(
            JSON.stringify({
              type: 'register',
              user: currentUser,
            })
          );

          // Setup ping heartbeat
          if (pingIntervalRef.current) clearInterval(pingIntervalRef.current);
          pingIntervalRef.current = setInterval(() => {
            if (ws.readyState === WebSocket.OPEN) {
              ws.send(JSON.stringify({ type: 'ping' }));
            }
          }, 25000);
        };

        ws.onmessage = async (event) => {
          if (!isMounted) return;
          try {
            const data = JSON.parse(event.data);

            switch (data.type) {
              case 'registered': {
                if (data.self) {
                  setCurrentUser((prev) => ({ ...prev, id: data.self.id, ip: data.self.ip }));
                }
                if (Array.isArray(data.users)) {
                  setPeers(data.users);
                }
                if (Array.isArray(data.recentMessages) && data.recentMessages.length > 0) {
                  // Decrypt recent messages asynchronously
                  const decryptedRecent = await Promise.all(
                    data.recentMessages.map(async (m: ChatMessage) => {
                      const isEnc = m.content?.startsWith('enc:') || m.isEncrypted;
                      const plainContent = await decryptText(m.content, settings.secretPassphrase);
                      return { ...m, content: plainContent, isEncrypted: isEnc };
                    })
                  );

                  // Merge recent messages into groupMessages
                  setGroupMessages((prev) => {
                    const next = { ...prev };
                    for (const m of decryptedRecent) {
                      const gId = m.recipientId || 'public';
                      const list = next[gId] || [];
                      if (!list.some((item) => item.id === m.id)) {
                        next[gId] = [...list, m];
                      }
                    }
                    return next;
                  });
                }
                break;
              }

              case 'users_list': {
                if (Array.isArray(data.users)) {
                  setPeers(data.users);
                }
                break;
              }

              case 'new_message': {
                const rawMsg: ChatMessage = data.message;
                const isSelf = rawMsg.senderId === currentUser.id;

                // Decrypt message content
                const isEnc = rawMsg.content?.startsWith('enc:') || rawMsg.isEncrypted;
                const plainContent = await decryptText(rawMsg.content, settings.secretPassphrase);
                const msg: ChatMessage = { ...rawMsg, content: plainContent, isEncrypted: isEnc };

                const isGroup = msg.recipientId === 'public' || msg.recipientId.startsWith('group_');

                if (isGroup) {
                  // Group message
                  const groupId = msg.recipientId;
                  setGroupMessages((prev) => {
                    const list = prev[groupId] || [];
                    if (list.some((m) => m.id === msg.id)) return prev;
                    return {
                      ...prev,
                      [groupId]: [...list, msg],
                    };
                  });

                  if (!isSelf) {
                    if (settings.soundEnabled) sound.playReceive();
                    if (settings.vibrationEnabled) sound.vibrate(80);

                    // Increment unread if not on this group chat
                    setActiveChatId((current) => {
                      if (current !== groupId) {
                        setUnreadCounts((counts) => ({
                          ...counts,
                          [groupId]: (counts[groupId] || 0) + 1,
                        }));
                      }
                      return current;
                    });
                  }
                } else {
                  // Private message
                  const peerKey = isSelf ? msg.recipientId : msg.senderId;
                  setPrivateMessages((prev) => {
                    const list = prev[peerKey] || [];
                    if (list.some((m) => m.id === msg.id)) return prev;
                    return {
                      ...prev,
                      [peerKey]: [...list, msg],
                    };
                  });

                  if (!isSelf) {
                    if (settings.soundEnabled) sound.playReceive();
                    if (settings.vibrationEnabled) sound.vibrate([100, 50, 100]);

                    setActiveChatId((current) => {
                      if (current !== peerKey) {
                        setUnreadCounts((counts) => ({
                          ...counts,
                          [peerKey]: (counts[peerKey] || 0) + 1,
                        }));
                      }
                      return current;
                    });
                  }
                }

                // Send back delivery acknowledgment to sender if not self
                if (!isSelf && ws.readyState === WebSocket.OPEN) {
                  ws.send(
                    JSON.stringify({
                      type: 'delivery_ack',
                      messageId: msg.id,
                      senderId: msg.senderId,
                      recipientId: msg.recipientId,
                    })
                  );
                }
                break;
              }

              case 'message_status': {
                const { messageId, status } = data;
                if (!messageId || !status) break;

                // Update status in groupMessages
                setGroupMessages((prev) => {
                  let changed = false;
                  const next: Record<string, ChatMessage[]> = {};
                  for (const key in prev) {
                    const list = prev[key];
                    if (list.some((m) => m.id === messageId && m.status !== status)) {
                      next[key] = list.map((m) => (m.id === messageId ? { ...m, status } : m));
                      changed = true;
                    } else {
                      next[key] = list;
                    }
                  }
                  return changed ? next : prev;
                });

                // Update status in privateMessages
                setPrivateMessages((prev) => {
                  let changed = false;
                  const next: Record<string, ChatMessage[]> = {};
                  for (const key in prev) {
                    const list = prev[key];
                    if (list.some((m) => m.id === messageId && m.status !== status)) {
                      next[key] = list.map((m) => (m.id === messageId ? { ...m, status } : m));
                      changed = true;
                    } else {
                      next[key] = list;
                    }
                  }
                  return changed ? next : prev;
                });
                break;
              }

              case 'message_deleted': {
                const { messageId } = data;
                if (!messageId) break;

                const markDeleted = (list: ChatMessage[]) =>
                  list.map((m) =>
                    m.id === messageId
                      ? {
                          ...m,
                          isDeleted: true,
                          deletedForEveryone: true,
                          content: 'تم حذف هذه الرسالة',
                          fileUrl: undefined,
                          fileName: undefined,
                        }
                      : m
                  );

                setGroupMessages((prev) => {
                  let changed = false;
                  const next: Record<string, ChatMessage[]> = {};
                  for (const key in prev) {
                    const list = prev[key];
                    if (list.some((m) => m.id === messageId)) {
                      next[key] = markDeleted(list);
                      changed = true;
                    } else {
                      next[key] = list;
                    }
                  }
                  return changed ? next : prev;
                });

                setPrivateMessages((prev) => {
                  let changed = false;
                  const next: Record<string, ChatMessage[]> = {};
                  for (const key in prev) {
                    const list = prev[key];
                    if (list.some((m) => m.id === messageId)) {
                      next[key] = markDeleted(list);
                      changed = true;
                    } else {
                      next[key] = list;
                    }
                  }
                  return changed ? next : prev;
                });
                break;
              }

              case 'user_typing': {
                if (data.senderId === currentUser.id) return;
                const matchesRoom =
                  (data.recipientId === 'public' && activeChatId === 'public') ||
                  (data.recipientId === currentUser.id && activeChatId === data.senderId);

                if (matchesRoom) {
                  if (data.isTyping) {
                    setTypingUsers((prev) => {
                      if (prev.some((u) => u.id === data.senderId)) return prev;
                      return [...prev, { id: data.senderId, name: data.senderName }];
                    });
                  } else {
                    setTypingUsers((prev) => prev.filter((u) => u.id !== data.senderId));
                  }
                }
                break;
              }

              case 'nudge_alert': {
                // Buzz alert
                if (settings.soundEnabled) sound.playNudge();
                if (settings.vibrationEnabled) sound.vibrate([200, 100, 200, 100, 300]);

                setIsShaking(true);
                setTimeout(() => setIsShaking(false), 1200);
                break;
              }

              case 'call_signal': {
                // Incoming Voice Call signal (WebRTC / Audio Streaming)
                const { fromUser, signalType, payload } = data;
                if (fromUser && signalType) {
                  webrtcCallManager.handleIncomingSignal(fromUser, signalType, payload);
                }
                break;
              }
            }
          } catch (err) {
            console.error('Error parsing WS message:', err);
          }
        };

        ws.onclose = () => {
          if (!isMounted) return;
          setIsConnected(false);
          if (pingIntervalRef.current) clearInterval(pingIntervalRef.current);

          // Retry connection in 3 seconds
          if (reconnectTimeoutRef.current) clearTimeout(reconnectTimeoutRef.current);
          reconnectTimeoutRef.current = setTimeout(connectWs, 3000);
        };

        ws.onerror = (e) => {
          console.warn('WebSocket error, waiting for retry:', e);
          ws.close();
        };
      } catch (e) {
        console.error('Error initializing WebSocket:', e);
        if (reconnectTimeoutRef.current) clearTimeout(reconnectTimeoutRef.current);
        reconnectTimeoutRef.current = setTimeout(connectWs, 3000);
      }
    }

    connectWs();

    return () => {
      isMounted = false;
      if (pingIntervalRef.current) clearInterval(pingIntervalRef.current);
      if (reconnectTimeoutRef.current) clearTimeout(reconnectTimeoutRef.current);
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [currentUser.id]);

  // Handle switching chats
  const handleSelectChat = (chatId: string) => {
    setActiveChatId(chatId);
    setMobileView('chat');
    setIsMobileDrawerOpen(false);
    setTypingUsers([]);
    // Clear unread count for this chat
    setUnreadCounts((prev) => {
      const next = { ...prev };
      delete next[chatId];
      return next;
    });
  };

  // Send message
  const handleSendMessage = async ({
    content,
    mediaType = 'text',
    fileUrl,
    fileName,
    fileSize,
    fileMime,
    replyTo,
  }: {
    content: string;
    mediaType?: 'text' | 'image' | 'video' | 'audio' | 'file';
    fileUrl?: string;
    fileName?: string;
    fileSize?: number;
    fileMime?: string;
    replyTo?: ReplyContext;
  }) => {
    if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
      alert('غير متصل بالخادم المحلي حالياً. يرجى الانتظار لإعادة الاتصال.');
      return;
    }

    // Encrypt message content if encryption is enabled
    const isEncrypted = settings.encryptionEnabled;
    const encryptedPayload = (content && isEncrypted)
      ? await encryptText(content, settings.secretPassphrase)
      : content;

    const newMsg: ChatMessage = {
      id: `msg_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderAvatar: currentUser.avatar,
      recipientId: activeChatId,
      content: encryptedPayload,
      mediaType,
      fileUrl,
      fileName,
      fileSize,
      fileMime,
      timestamp: Date.now(),
      replyTo,
      isEncrypted,
      status: 'sent',
    };

    // Send encrypted payload through WebSocket
    wsRef.current.send(
      JSON.stringify({
        type: 'message',
        message: newMsg,
      })
    );

    // Audio feedback
    if (settings.soundEnabled) sound.playSend();
    if (settings.vibrationEnabled) sound.vibrate(40);
  };

  // Delete message handler (for everyone or for me)
  const handleDeleteMessage = (messageId: string, forEveryone: boolean = true) => {
    const markDeleted = (list: ChatMessage[]) =>
      forEveryone
        ? list.map((m) =>
            m.id === messageId
              ? {
                  ...m,
                  isDeleted: true,
                  deletedForEveryone: true,
                  content: 'تم حذف هذه الرسالة',
                  fileUrl: undefined,
                  fileName: undefined,
                }
              : m
          )
        : list.filter((m) => m.id !== messageId);

    setGroupMessages((prev) => {
      const next: Record<string, ChatMessage[]> = {};
      for (const key in prev) {
        next[key] = markDeleted(prev[key] || []);
      }
      return next;
    });

    setPrivateMessages((prev) => {
      const next: Record<string, ChatMessage[]> = {};
      for (const key in prev) {
        next[key] = markDeleted(prev[key] || []);
      }
      return next;
    });

    if (forEveryone && wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(
        JSON.stringify({
          type: 'delete_message',
          messageId,
          recipientId: activeChatId,
          forEveryone: true,
        })
      );
    }
  };

  // Notify typing
  const handleTyping = (isTyping: boolean) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(
        JSON.stringify({
          type: 'typing',
          recipientId: activeChatId,
          isTyping,
        })
      );
    }
  };

  // Send Buzz / Nudge
  const handleSendNudge = (targetId: string = activeChatId) => {
    if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) return;

    wsRef.current.send(
      JSON.stringify({
        type: 'nudge',
        targetId,
      })
    );

    if (settings.soundEnabled) sound.playNudge();
    if (settings.vibrationEnabled) sound.vibrate([100, 50, 100]);
  };

  // Update profile
  const handleUpdateProfile = (
    name: string,
    avatar: string,
    status: UserStatus
  ) => {
    const updated: User = { ...currentUser, name: name.trim(), avatar, status, hasCustomName: true };
    setCurrentUser(updated);
    saveStoredUser(updated);

    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(
        JSON.stringify({
          type: 'update_profile',
          user: updated,
        })
      );
    }
  };

  // Save user name from entry/welcome modal
  const handleSaveName = (name: string, avatar: string, status: UserStatus) => {
    const updated: User = {
      ...currentUser,
      name: name.trim(),
      avatar,
      status,
      hasCustomName: true,
    };
    setCurrentUser(updated);
    saveStoredUser(updated);
    setIsNameModalOpen(false);

    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(
        JSON.stringify({
          type: 'update_profile',
          user: updated,
        })
      );
    }

    if (settings.soundEnabled) sound.playJoin();
  };

  // Group detection
  const isGroupChat = activeChatId === 'public' || activeChatId.startsWith('group_');
  const activeGroup = isGroupChat ? groups.find((g) => g.id === activeChatId) || null : null;

  // Current active conversation messages
  const activeMessages = useMemo(() => {
    if (isGroupChat) {
      return groupMessages[activeChatId] || [];
    }
    return privateMessages[activeChatId] || [];
  }, [isGroupChat, activeChatId, groupMessages, privateMessages]);

  const targetPeer = useMemo(() => {
    if (isGroupChat) return null;
    return peers.find((p) => p.id === activeChatId) || null;
  }, [isGroupChat, activeChatId, peers]);

  const unreadTotal = useMemo(() => {
    return Object.values(unreadCounts).reduce((a, b) => a + b, 0);
  }, [unreadCounts]);

  // Combined messages for backup export
  const allMessagesForExport = useMemo(() => {
    const groupMsgs = Object.values(groupMessages).flat();
    const privates = Object.values(privateMessages).flat();
    return [...groupMsgs, ...privates];
  }, [groupMessages, privateMessages]);

  // Dark themes mapping
  const themeBackgroundClasses = {
    slate: 'bg-slate-950 text-slate-100',
    amoled: 'bg-black text-slate-100',
    navy: 'bg-[#030712] text-slate-100',
    emerald: 'bg-[#02130e] text-slate-100',
    violet: 'bg-[#0b0617] text-slate-100',
  };

  return (
    <div
      dir="rtl"
      className={`h-screen h-[100dvh] max-h-screen max-h-[100dvh] w-full w-screen max-w-full flex flex-col font-cairo overflow-hidden transition-colors duration-300 ${
        themeBackgroundClasses[settings.preset]
      } ${isShaking ? 'animate-[shake_0.5s_ease-in-out_infinite]' : ''}`}
    >
      {/* Navbar Header */}
      <Navbar
        isConnected={isConnected}
        onlineCount={peers.length}
        connectionMode={connectionMode}
        onToggleConnectionMode={setConnectionMode}
        onOpenNetworkModal={() => setIsNetworkModalOpen(true)}
        onOpenSettingsModal={() => setIsSettingsModalOpen(true)}
        onOpenInstallModal={() => setIsInstallModalOpen(true)}
        onToggleMobileDrawer={() => setMobileView((prev) => (prev === 'list' ? 'chat' : 'list'))}
        onSendNudge={() => handleSendNudge(activeChatId)}
        onToggleSearch={() => setIsSearching((prev) => !prev)}
        isSearching={isSearching}
        unreadTotal={unreadTotal}
        accent={settings.accent}
        isMobileList={mobileView === 'list'}
        currentUser={currentUser}
        onEditProfile={() => setIsNameModalOpen(true)}
      />

      {/* Main Content Layout - Full Screen Edge to Edge */}
      <div className="flex-1 flex overflow-hidden relative w-full h-full">
        {/* Desktop Sidebar & Mobile Full-Screen Contacts/Groups List */}
        <aside
          className={`${
            mobileView === 'list' ? 'flex flex-1 w-full' : 'hidden'
          } lg:flex lg:w-72 xl:w-80 h-full shrink-0`}
        >
          <PeersList
            currentUser={currentUser}
            peers={peers}
            groups={groups}
            activeChatId={activeChatId}
            connectionMode={connectionMode}
            onToggleConnectionMode={setConnectionMode}
            onSelectChat={handleSelectChat}
            onSendNudge={handleSendNudge}
            onCreateGroup={handleCreateGroup}
            onDeleteGroup={handleDeleteGroup}
            unreadCounts={unreadCounts}
            accent={settings.accent}
            onCloseMobileDrawer={() => setMobileView('chat')}
            onEditProfile={() => setIsNameModalOpen(true)}
          />
        </aside>

        {/* Mobile Full-Screen Drawer Backdrop (if opened specifically) */}
        {isMobileDrawerOpen && (
          <div
            className="lg:hidden fixed inset-0 z-40 bg-black/70 backdrop-blur-sm animate-in fade-in"
            onClick={() => setIsMobileDrawerOpen(false)}
          >
            <div
              className="w-full sm:w-4/5 max-w-sm h-full bg-slate-950 shadow-2xl animate-in slide-in-from-right duration-200"
              onClick={(e) => e.stopPropagation()}
            >
              <PeersList
                currentUser={currentUser}
                peers={peers}
                groups={groups}
                activeChatId={activeChatId}
                connectionMode={connectionMode}
                onToggleConnectionMode={setConnectionMode}
                onSelectChat={handleSelectChat}
                onSendNudge={handleSendNudge}
                onCreateGroup={handleCreateGroup}
                onDeleteGroup={handleDeleteGroup}
                unreadCounts={unreadCounts}
                accent={settings.accent}
                onCloseMobileDrawer={() => {
                  setIsMobileDrawerOpen(false);
                  setMobileView('chat');
                }}
                onEditProfile={() => {
                  setIsMobileDrawerOpen(false);
                  setIsNameModalOpen(true);
                }}
              />
            </div>
          </div>
        )}

        {/* Chat Area - Full Screen on mobile when mobileView === 'chat' & Main Content on desktop */}
        <main
          className={`${
            mobileView === 'chat' ? 'flex flex-1' : 'hidden'
          } lg:flex flex-col h-full min-w-0 w-full`}
        >
          <ChatArea
            activeChatId={activeChatId}
            activeGroup={activeGroup}
            currentUser={currentUser}
            targetPeer={targetPeer}
            onlineCount={peers.length}
            messages={activeMessages}
            typingUsers={typingUsers}
            settings={settings}
            onSendMessage={handleSendMessage}
            onTyping={handleTyping}
            onSendNudge={handleSendNudge}
            onOpenImage={(url, fileName) => setLightboxImage({ url, fileName })}
            onRecordSoundFeedback={() => sound.playRecordStart()}
            isSearching={isSearching}
            onCloseSearch={() => setIsSearching(false)}
            onStartVoiceCall={handleStartVoiceCall}
            onBackToList={() => setMobileView('list')}
            onDeleteMessage={handleDeleteMessage}
          />
        </main>
      </div>

      {/* Network & QR Code Modal */}
      <NetworkModal
        isOpen={isNetworkModalOpen}
        onClose={() => setIsNetworkModalOpen(false)}
        networkInfo={networkInfo}
        onRefreshNetwork={fetchNetworkInfo}
      />

      {/* Settings & Appearance Modal */}
      <SettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        currentUser={currentUser}
        onUpdateProfile={handleUpdateProfile}
        settings={settings}
        onUpdateSettings={setSettings}
        messagesToExport={allMessagesForExport}
        onClearHistory={() => {
          setGroupMessages({});
          setPrivateMessages({});
        }}
      />

      {/* Media Lightbox */}
      <MediaLightbox
        imageUrl={lightboxImage?.url || null}
        fileName={lightboxImage?.fileName}
        onClose={() => setLightboxImage(null)}
      />

      {/* App Installation Modal */}
      <InstallModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
        deferredPrompt={deferredPrompt}
        onInstallNative={handleInstallNative}
      />

      {/* Offline Voice Call Modal */}
      <VoiceCallModal
        callState={activeCall}
        onAccept={() => webrtcCallManager.acceptCall()}
        onReject={() => webrtcCallManager.rejectCall()}
        onEndCall={() => webrtcCallManager.endCall()}
        onToggleMute={() => webrtcCallManager.toggleMute()}
        onToggleSpeaker={() => webrtcCallManager.toggleSpeaker()}
      />

      {/* Welcome & Prompt Name on Entry Modal */}
      <WelcomeNameModal
        isOpen={isNameModalOpen}
        isFirstTime={!currentUser.hasCustomName}
        currentUser={currentUser}
        onSave={handleSaveName}
        onClose={() => {
          // If first time and user doesn't have custom name yet, keep open or close only if they already have one
          if (currentUser.hasCustomName) {
            setIsNameModalOpen(false);
          }
        }}
      />
    </div>
  );
}
