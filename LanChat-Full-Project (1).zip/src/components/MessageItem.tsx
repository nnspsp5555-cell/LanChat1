import React, { useState } from 'react';
import {
  Reply,
  Copy,
  Check,
  CheckCheck,
  FileText,
  Download,
  CornerUpLeft,
  Lock,
  Trash2,
  Ban,
  X,
} from 'lucide-react';
import { ChatMessage, AccentColor } from '../types/chat';
import { formatFileSize } from '../utils/media';
import { AudioPlayer } from './AudioPlayer';
import { UserAvatar } from './UserAvatar';

interface MessageItemProps {
  message: ChatMessage;
  isSelf: boolean;
  accent: AccentColor;
  onReply: (msg: ChatMessage) => void;
  onOpenImage: (url: string, fileName?: string) => void;
  onDeleteMessage?: (messageId: string, forEveryone: boolean) => void;
}

export const MessageItem: React.FC<MessageItemProps> = ({
  message,
  isSelf,
  accent,
  onReply,
  onOpenImage,
  onDeleteMessage,
}) => {
  const [copied, setCopied] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const handleCopy = () => {
    if (message.content && !message.isDeleted) {
      navigator.clipboard.writeText(message.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const formattedTime = new Date(message.timestamp).toLocaleTimeString('ar-SA', {
    hour: '2-digit',
    minute: '2-digit',
  });

  // Dynamic bubble styling based on accent and sender
  const selfBubbleClasses: Record<AccentColor, string> = {
    cyan: 'bg-cyan-600 text-white rounded-tr-sm shadow-cyan-950/40',
    emerald: 'bg-emerald-600 text-white rounded-tr-sm shadow-emerald-950/40',
    violet: 'bg-violet-600 text-white rounded-tr-sm shadow-violet-950/40',
    amber: 'bg-amber-600 text-white rounded-tr-sm shadow-amber-950/40',
    rose: 'bg-rose-600 text-white rounded-tr-sm shadow-rose-950/40',
    sky: 'bg-sky-600 text-white rounded-tr-sm shadow-sky-950/40',
  };

  const peerBubbleClass = 'bg-slate-800/90 text-slate-100 rounded-tl-sm border border-slate-700/50 shadow-black/20';
  const deletedBubbleClass = 'bg-slate-900/80 text-slate-400 border border-slate-800/80 rounded-2xl';

  return (
    <div
      className={`group flex items-end gap-2 w-full my-1.5 transition-all relative ${
        isSelf ? 'justify-start flex-row-reverse' : 'justify-start'
      }`}
    >
      {/* Avatar for peer */}
      {!isSelf && (
        <UserAvatar
          avatar={message.senderAvatar}
          name={message.senderName}
          size="sm"
          className="shadow-sm"
        />
      )}

      {/* Message Bubble Container */}
      <div
        className={`relative max-w-[85%] sm:max-w-[70%] rounded-2xl p-3 shadow-md transition-all ${
          message.isDeleted
            ? deletedBubbleClass
            : isSelf
            ? selfBubbleClasses[accent]
            : peerBubbleClass
        }`}
      >
        {/* Peer name header in public room or group */}
        {!isSelf && !message.isDeleted && (message.recipientId === 'public' || message.recipientId.startsWith('group_')) && (
          <div className="text-xs font-bold text-cyan-400 mb-1 flex items-center gap-1">
            <span>{message.senderName}</span>
          </div>
        )}

        {/* Deleted Message State */}
        {message.isDeleted ? (
          <div className="flex items-center gap-2 text-xs italic text-slate-400/90 select-none py-1 px-1">
            <Ban size={15} className="text-slate-500 shrink-0" />
            <span>{isSelf ? '🚫 قمت بحذف هذه الرسالة' : '🚫 تم حذف هذه الرسالة'}</span>
          </div>
        ) : (
          <>
            {/* Reply Quote Banner */}
            {message.replyTo && (
              <div
                className={`mb-2 p-2 rounded-lg text-xs border-r-4 flex flex-col gap-0.5 cursor-pointer hover:opacity-90 transition-opacity ${
                  isSelf
                    ? 'bg-black/20 border-white/70 text-slate-100'
                    : 'bg-slate-900/60 border-cyan-500 text-slate-300'
                }`}
                title="الرسالة المقتبسة"
              >
                <div className="font-semibold flex items-center gap-1 opacity-90">
                  <CornerUpLeft size={12} />
                  <span>{message.replyTo.senderName}</span>
                </div>
                <div className="truncate opacity-80">{message.replyTo.content || '[مرفق وسائط]'}</div>
              </div>
            )}

            {/* Media: Image */}
            {message.mediaType === 'image' && message.fileUrl && (
              <div className="mb-2 overflow-hidden rounded-xl bg-black/30">
                <img
                  src={message.fileUrl}
                  alt={message.fileName || 'صورة مرسلة'}
                  onClick={() => onOpenImage(message.fileUrl!, message.fileName)}
                  className="max-h-80 w-auto rounded-xl object-contain cursor-pointer hover:opacity-95 transition-opacity"
                  loading="lazy"
                />
              </div>
            )}

            {/* Media: Video */}
            {message.mediaType === 'video' && message.fileUrl && (
              <div className="mb-2 overflow-hidden rounded-xl bg-black/40">
                <video
                  src={message.fileUrl}
                  controls
                  playsInline
                  preload="metadata"
                  className="max-h-72 w-full rounded-xl bg-black"
                />
              </div>
            )}

            {/* Media: Audio / Voice note */}
            {message.mediaType === 'audio' && message.fileUrl && (
              <div className="mb-2">
                <AudioPlayer src={message.fileUrl} fileName={message.fileName} accentColor={accent} />
              </div>
            )}

            {/* Media: Generic File / Document / APK */}
            {message.mediaType === 'file' && message.fileUrl && (
              <div
                className={`mb-2 flex items-center justify-between gap-3 p-2.5 rounded-xl border ${
                  isSelf
                    ? 'bg-black/25 border-white/20'
                    : 'bg-slate-900/70 border-slate-700/80'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="w-9 h-9 rounded-lg bg-cyan-500/20 text-cyan-300 flex items-center justify-center shrink-0">
                    <FileText size={20} />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-medium truncate max-w-[170px] sm:max-w-[240px]">
                      {message.fileName || 'ملف مرفق'}
                    </p>
                    <p className="text-[10px] opacity-75">{formatFileSize(message.fileSize)}</p>
                  </div>
                </div>

                <a
                  href={message.fileUrl}
                  download={message.fileName || 'file'}
                  className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors shrink-0"
                  title="تنزيل الملف"
                >
                  <Download size={16} />
                </a>
              </div>
            )}

            {/* Text Content */}
            {message.content && (
              <p className="text-sm whitespace-pre-wrap break-words leading-relaxed select-text dir-rtl">
                {message.content}
              </p>
            )}
          </>
        )}

        {/* Metadata Footer: Timestamp, Lock & Checkmarks */}
        <div
          className={`flex items-center gap-1.5 mt-1 text-[10px] ${
            message.isDeleted
              ? 'justify-end text-slate-500'
              : isSelf
              ? 'justify-start text-white/80'
              : 'justify-end text-slate-400'
          }`}
        >
          {message.isEncrypted && !message.isDeleted && (
            <span title="محادثة مشفرة من طرف لطرف 🔒" className="inline-flex items-center opacity-85">
              <Lock size={10} className={isSelf ? 'text-white/80' : 'text-cyan-400'} />
            </span>
          )}
          <span className="font-mono">{formattedTime}</span>
          {isSelf && !message.isDeleted && (
            <span
              className="inline-flex items-center"
              title={
                message.status === 'delivered' || message.status === 'read'
                  ? 'تم استلام الرسالة من الطرف الآخر (✓✓)'
                  : 'تم الإرسال عبر الشبكة (✓)'
              }
            >
              {message.status === 'delivered' || message.status === 'read' ? (
                <CheckCheck size={14} className="text-cyan-300 stroke-[2.5]" />
              ) : (
                <Check size={12} className="text-white/70 stroke-[2]" />
              )}
            </span>
          )}
        </div>

        {/* Hover/Touch Quick Action Bar (Only for non-deleted messages) */}
        {!message.isDeleted && (
          <div
            className={`absolute top-0 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 bg-slate-900/95 backdrop-blur-md border border-slate-700/80 rounded-full px-2 py-0.5 shadow-xl z-20 ${
              isSelf ? 'left-2' : 'right-2'
            }`}
          >
            {/* Reply */}
            <button
              onClick={() => onReply(message)}
              className="p-1 text-slate-300 hover:text-cyan-400 transition-colors cursor-pointer"
              title="رد على هذه الرسالة"
            >
              <Reply size={13} />
            </button>

            {/* Copy */}
            {message.content && (
              <button
                onClick={handleCopy}
                className="p-1 text-slate-300 hover:text-emerald-400 transition-colors cursor-pointer"
                title={copied ? 'تم النسخ!' : 'نسخ النص'}
              >
                {copied ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
              </button>
            )}

            {/* Delete Options Button */}
            {onDeleteMessage && (
              <button
                onClick={() => setShowDeleteConfirm(true)}
                className="p-1 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                title="حذف الرسالة"
              >
                <Trash2 size={13} />
              </button>
            )}
          </div>
        )}

        {/* Delete Confirmation Modal / Popover */}
        {showDeleteConfirm && onDeleteMessage && (
          <div
            className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3 select-none animate-in fade-in"
            onClick={(e) => {
              e.stopPropagation();
              setShowDeleteConfirm(false);
            }}
          >
            <div
              className="bg-slate-900 border border-slate-700 rounded-3xl p-4 sm:p-5 max-w-xs w-full shadow-2xl space-y-3 text-slate-100"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <div className="flex items-center gap-2 text-rose-400 font-bold text-xs sm:text-sm">
                  <Trash2 size={16} />
                  <span>حذف الرسالة</span>
                </div>
                <button
                  onClick={() => setShowDeleteConfirm(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
                >
                  <X size={15} />
                </button>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">
                هل ترغب في حذف هذه الرسالة لدى الجميع أم لديك فقط؟
              </p>

              <div className="space-y-2 pt-1">
                {isSelf && (
                  <button
                    onClick={() => {
                      onDeleteMessage(message.id, true);
                      setShowDeleteConfirm(false);
                    }}
                    className="w-full py-2.5 px-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md cursor-pointer"
                  >
                    <Ban size={14} />
                    <span>حذف لدى الجميع (Delete for everyone)</span>
                  </button>
                )}

                <button
                  onClick={() => {
                    onDeleteMessage(message.id, false);
                    setShowDeleteConfirm(false);
                  }}
                  className="w-full py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                >
                  <Trash2 size={13} />
                  <span>حذف لدي فقط</span>
                </button>

                <button
                  onClick={() => setShowDeleteConfirm(false)}
                  className="w-full py-1.5 px-3 text-slate-400 hover:text-slate-200 text-xs transition-colors cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
