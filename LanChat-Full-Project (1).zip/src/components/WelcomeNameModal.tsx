import React, { useState, useRef } from 'react';
import {
  Sparkles,
  Check,
  Crown,
  Smartphone,
  Wifi,
  X,
  Smile,
  Image as ImageIcon,
  Trash2,
  Upload,
} from 'lucide-react';
import { User, UserStatus } from '../types/chat';
import { UserAvatar, isImageAvatar } from './UserAvatar';
import { compressProfileImage } from '../utils/media';

interface WelcomeNameModalProps {
  isOpen: boolean;
  isFirstTime?: boolean;
  currentUser: User;
  onSave: (name: string, avatar: string, status: UserStatus) => void;
  onClose?: () => void;
}

const PRESET_AVATARS = [
  '👑', '⚡', '🤖', '🦁', '🔥', '🚀',
  '🌟', '💎', '🦅', '🎯', '🏎️', '🐺',
  '🐯', '😎', '🎩', '🛡️', '⚔️', '🌊',
];

const STATUS_OPTIONS: { id: UserStatus; label: string; dotClass: string }[] = [
  { id: 'online', label: 'متصل الآن', dotClass: 'bg-emerald-400' },
  { id: 'busy', label: 'مشغول', dotClass: 'bg-rose-500' },
  { id: 'away', label: 'في استراحة', dotClass: 'bg-amber-400' },
  { id: 'offline', label: 'غير متصل (متخفي)', dotClass: 'bg-slate-400' },
];

export const WelcomeNameModal: React.FC<WelcomeNameModalProps> = ({
  isOpen,
  isFirstTime = false,
  currentUser,
  onSave,
  onClose,
}) => {
  const [name, setName] = useState(
    currentUser.hasCustomName ? currentUser.name : ''
  );
  const [avatar, setAvatar] = useState(currentUser.avatar || '👑');
  const [status, setStatus] = useState<UserStatus>(currentUser.status || 'online');
  const [customEmoji, setCustomEmoji] = useState('');
  const [error, setError] = useState('');
  const [isProcessingImage, setIsProcessingImage] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleGalleryImageSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsProcessingImage(true);
      setError('');
      // Compress and crop to center square
      const compressedDataUrl = await compressProfileImage(file, 256);
      setAvatar(compressedDataUrl);
      setCustomEmoji('');
    } catch (err: any) {
      console.error('Error processing gallery image:', err);
      setError('تعذر تحميل الصورة من المعرض. يرجى تجربة صورة أخرى.');
    } finally {
      setIsProcessingImage(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleResetToDefaultEmoji = () => {
    setAvatar('👑');
    setCustomEmoji('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = name.trim();
    if (!trimmed) {
      setError('يرجى كتابة اسمك للمتابعة والدخول إلى الدردشة');
      return;
    }
    if (trimmed.length < 2) {
      setError('يجب أن يتكون الاسم من حرفين على الأقل');
      return;
    }

    const selectedAvatar = customEmoji.trim() || avatar;
    onSave(trimmed, selectedAvatar, status);
  };

  const isCurrentAvatarImage = isImageAvatar(avatar);

  return (
    <div
      dir="rtl"
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 select-none animate-in fade-in duration-200"
    >
      <div
        className="bg-slate-900 border border-amber-500/30 rounded-3xl w-full max-w-md max-h-[92vh] overflow-y-auto shadow-[0_0_50px_rgba(245,158,11,0.15)] p-5 sm:p-6 flex flex-col gap-4 text-slate-100 relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Hidden file input for gallery upload */}
        <input
          type="file"
          ref={fileInputRef}
          accept="image/*"
          onChange={handleGalleryImageSelected}
          className="hidden"
        />

        {/* Decorative Top Accent Glow */}
        <div className="absolute top-0 right-1/4 left-1/4 h-[2px] bg-gradient-to-r from-transparent via-amber-400 to-transparent shadow-[0_0_12px_#f59e0b]" />

        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="relative group">
              <UserAvatar
                avatar={avatar}
                name={name}
                size="lg"
                status={status}
                showStatus={true}
                borderClass="border-amber-500/50 shadow-md shadow-amber-950/30"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                title="تغيير الصورة من المعرض"
                className="absolute -bottom-1 -left-1 p-1 rounded-full bg-amber-500 text-slate-950 hover:bg-amber-400 transition-all shadow-md cursor-pointer"
              >
                <Upload size={11} className="stroke-[3]" />
              </button>
            </div>

            <div>
              <div className="flex items-center gap-1.5 text-amber-400 text-xs font-bold uppercase tracking-wider mb-0.5">
                <Crown size={14} className="text-amber-400" />
                <span>شبكة آل عيسى المحلية</span>
              </div>
              <h2 className="text-lg sm:text-xl font-bold text-white">
                {isFirstTime ? 'أهلاً بك! يرجى إضافة اسمك' : 'تعديل اسمك وملفك الشخصي'}
              </h2>
            </div>
          </div>

          {!isFirstTime && onClose && (
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              <X size={18} />
            </button>
          )}
        </div>

        <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/70 p-3 rounded-2xl border border-slate-800 flex items-start gap-2">
          <Sparkles size={16} className="text-amber-400 shrink-0 mt-0.5" />
          <span>
            {isFirstTime
              ? 'أدخل اسمك واختر صورتك من المعرض أو رمزاً تعبيرياً ليظهر لجميع الأجهزة على نفس شبكة Wi-Fi.'
              : 'سيتم تحديث اسمك وصورتك وحالتك فوراً لدى جميع المتصلين في نفس الشبكة.'}
          </span>
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Name Field */}
          <div>
            <label className="text-xs font-bold text-slate-200 block mb-1.5">
              اسم المستخدم <span className="text-amber-400">*</span>
            </label>
            <div className="relative">
              <input
                type="text"
                autoFocus
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                  if (error) setError('');
                }}
                maxLength={30}
                placeholder="اكتب اسمك هنا (مثال: علي العيسى، محمد، سيف...)"
                className="w-full bg-slate-950 border border-slate-700/80 rounded-2xl px-3.5 py-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition-all font-medium"
              />
              <div className="absolute left-3 top-1/2 -translate-y-1/2 text-[11px] text-slate-500 font-mono">
                {name.length}/30
              </div>
            </div>
            {error && (
              <p className="text-xs text-rose-400 mt-1.5 flex items-center gap-1">
                <span>⚠️</span>
                <span>{error}</span>
              </p>
            )}
          </div>

          {/* Profile Picture: Gallery Upload Option */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-slate-200">
                صورة الملف الشخصي:
              </label>
              {isCurrentAvatarImage && (
                <button
                  type="button"
                  onClick={handleResetToDefaultEmoji}
                  className="text-[11px] text-rose-400 hover:text-rose-300 flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <Trash2 size={12} />
                  <span>الرجوع إلى الرموز التعبيرية</span>
                </button>
              )}
            </div>

            {/* Gallery Upload Card Button */}
            <div className="flex items-center gap-2 mb-2">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={isProcessingImage}
                className="flex-1 py-2.5 px-3 rounded-2xl bg-slate-950/90 border border-amber-500/40 hover:border-amber-400 hover:bg-amber-500/10 text-amber-300 text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer group"
              >
                <ImageIcon size={16} className="text-amber-400 group-hover:scale-110 transition-transform" />
                <span>{isProcessingImage ? 'جاري تجهيز الصورة...' : 'اختيار صورة من معرض الصور 🖼️'}</span>
              </button>
            </div>

            {/* Quick Avatar Selector (Emojis) */}
            <div className="grid grid-cols-6 gap-2 bg-slate-950/80 p-2.5 rounded-2xl border border-slate-800/90 max-h-32 overflow-y-auto">
              {PRESET_AVATARS.map((em) => (
                <button
                  type="button"
                  key={em}
                  onClick={() => {
                    setAvatar(em);
                    setCustomEmoji('');
                  }}
                  className={`h-9 rounded-xl flex items-center justify-center text-lg transition-all cursor-pointer ${
                    avatar === em && !customEmoji && !isCurrentAvatarImage
                      ? 'bg-amber-500/25 border-2 border-amber-400 scale-105 shadow-md shadow-amber-500/20'
                      : 'bg-slate-900 border border-slate-800/80 hover:bg-slate-800 hover:scale-105'
                  }`}
                >
                  {em}
                </button>
              ))}
            </div>

            {/* Custom Emoji / Text Input */}
            <div className="mt-2 flex items-center gap-2">
              <Smile size={16} className="text-slate-400 shrink-0" />
              <input
                type="text"
                value={customEmoji}
                onChange={(e) => {
                  setCustomEmoji(e.target.value);
                  if (e.target.value) setAvatar(e.target.value);
                }}
                maxLength={4}
                placeholder="أو اكتب رمزاً مخصصاً (مثال: 🦅 أو 👨‍💻)"
                className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>

          {/* Status Selection (Includes Offline / Invisible) */}
          <div>
            <label className="text-xs font-bold text-slate-200 block mb-1.5">
              حالتك على الشبكة:
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
              {STATUS_OPTIONS.map((st) => (
                <button
                  type="button"
                  key={st.id}
                  onClick={() => setStatus(st.id)}
                  className={`py-2 px-1.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 border transition-all cursor-pointer ${
                    status === st.id
                      ? 'border-amber-400 bg-amber-400/15 text-amber-200 shadow-sm'
                      : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <span className={`w-2 h-2 rounded-full ${st.dotClass}`} />
                  <span className="truncate">{st.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Device & Wi-Fi Info Badge */}
          <div className="flex items-center justify-between text-[11px] text-slate-400 px-1 py-1">
            <span className="flex items-center gap-1">
              <Smartphone size={13} className="text-emerald-400" />
              <span>جهازك: {currentUser.deviceType === 'android' ? 'هاتف أندرويد' : 'متصفح محلي'}</span>
            </span>
            <span className="flex items-center gap-1 font-mono text-slate-400">
              <Wifi size={13} className="text-sky-400" />
              <span>اتصال Wi-Fi محلي</span>
            </span>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-[0_4px_20px_rgba(245,158,11,0.35)] transition-all transform active:scale-[0.99] cursor-pointer mt-2"
          >
            <Check size={18} className="stroke-[3]" />
            <span>{isFirstTime ? 'انضمام ودخول الدردشة الآن 🚀' : 'حفظ التعديلات والملف الشخصي'}</span>
          </button>
        </form>
      </div>
    </div>
  );
};
