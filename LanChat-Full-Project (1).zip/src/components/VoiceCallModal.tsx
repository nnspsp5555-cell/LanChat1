import React, { useState } from 'react';
import {
  Phone,
  PhoneCall,
  PhoneOff,
  Mic,
  MicOff,
  Volume2,
  Volume1,
  Minimize2,
  Maximize2,
  Lock,
  Wifi,
  Sparkles,
  ShieldCheck,
} from 'lucide-react';
import { ActiveCallState } from '../types/chat';

interface VoiceCallModalProps {
  callState: ActiveCallState | null;
  onAccept: () => void;
  onReject: () => void;
  onEndCall: () => void;
  onToggleMute: () => void;
  onToggleSpeaker: () => void;
}

export const VoiceCallModal: React.FC<VoiceCallModalProps> = ({
  callState,
  onAccept,
  onReject,
  onEndCall,
  onToggleMute,
  onToggleSpeaker,
}) => {
  const [isMinimized, setIsMinimized] = useState(false);

  if (!callState || callState.status === 'idle') return null;

  const formatDuration = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // 1. Minimized Active Call Floating Bar
  if (isMinimized && callState.status === 'connected') {
    return (
      <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 bg-slate-900/95 backdrop-blur-md border border-emerald-500/50 rounded-full px-4 py-2 shadow-2xl shadow-emerald-950/50 flex items-center gap-3 animate-in fade-in slide-in-from-top">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-xs font-bold text-slate-100">{callState.peer.name}</span>
          <span className="font-mono text-xs text-emerald-400">{formatDuration(callState.durationSeconds)}</span>
        </div>

        <div className="flex items-center gap-1.5 border-r border-slate-700 pr-2">
          <button
            onClick={onToggleMute}
            className={`p-1.5 rounded-full ${callState.isMuted ? 'bg-rose-500/30 text-rose-300' : 'bg-slate-800 text-slate-300'}`}
            title={callState.isMuted ? 'إلغاء كتم الصوت' : 'كتم الصوت'}
          >
            {callState.isMuted ? <MicOff size={13} /> : <Mic size={13} />}
          </button>
          <button
            onClick={onEndCall}
            className="p-1.5 rounded-full bg-rose-600 text-white hover:bg-rose-700"
            title="إنهاء المكالمة"
          >
            <PhoneOff size={13} />
          </button>
          <button
            onClick={() => setIsMinimized(false)}
            className="p-1.5 rounded-full bg-slate-800 text-slate-300 hover:text-white"
            title="تكبير نافذة المكالمة"
          >
            <Maximize2 size={13} />
          </button>
        </div>
      </div>
    );
  }

  // 2. Incoming Call Screen
  if (callState.status === 'incoming') {
    return (
      <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-xl flex items-center justify-center p-4 animate-in fade-in">
        <div className="w-full max-w-sm bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border border-emerald-500/40 rounded-3xl p-6 text-center shadow-2xl shadow-emerald-950/60 relative overflow-hidden">
          {/* Animated background ripples */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-20">
            <div className="w-72 h-72 rounded-full border border-emerald-400 animate-ping" />
            <div className="w-96 h-96 rounded-full border border-emerald-500 animate-pulse" />
          </div>

          {/* Badge */}
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-semibold mb-6">
            <Wifi size={13} className="text-emerald-400" />
            <span>مكالمة صوتية محلية (بدون إنترنت)</span>
          </div>

          {/* Caller Avatar */}
          <div className="relative inline-block mb-4">
            <div className="w-24 h-24 rounded-full bg-slate-800 border-2 border-emerald-400/80 flex items-center justify-center text-4xl shadow-xl shadow-emerald-900/40 animate-bounce duration-1000">
              {callState.peer.avatar || '👤'}
            </div>
            <div className="absolute bottom-0 right-0 w-7 h-7 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center shadow-md">
              <PhoneCall size={14} className="animate-spin" />
            </div>
          </div>

          <h3 className="text-lg font-bold text-white mb-1">{callState.peer.name}</h3>
          <p className="text-xs text-slate-400 mb-2 font-mono">{callState.peer.ip || 'شبكة محلية'}</p>
          <p className="text-xs text-emerald-400 font-semibold mb-8 animate-pulse">يرن الآن...</p>

          {/* Action buttons */}
          <div className="flex items-center justify-center gap-6">
            {/* Decline */}
            <button
              onClick={onReject}
              className="flex flex-col items-center gap-1.5 text-xs text-slate-300 group cursor-pointer"
            >
              <div className="w-14 h-14 rounded-full bg-rose-600/90 group-hover:bg-rose-600 text-white flex items-center justify-center shadow-lg shadow-rose-950/50 transition-transform active:scale-90">
                <PhoneOff size={24} />
              </div>
              <span className="font-semibold text-rose-400">رفض</span>
            </button>

            {/* Accept */}
            <button
              onClick={onAccept}
              className="flex flex-col items-center gap-1.5 text-xs text-slate-300 group cursor-pointer"
            >
              <div className="w-16 h-16 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center shadow-xl shadow-emerald-500/40 transition-transform active:scale-95 animate-pulse">
                <Phone size={28} className="fill-current" />
              </div>
              <span className="font-bold text-emerald-400 text-sm">رد ومحادثة</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // 3. Outgoing Calling Screen
  if (callState.status === 'calling') {
    return (
      <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-xl flex items-center justify-center p-4 animate-in fade-in">
        <div className="w-full max-w-sm bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border border-slate-700 rounded-3xl p-6 text-center shadow-2xl relative">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-semibold mb-6">
            <Sparkles size={13} className="text-cyan-400" />
            <span>جاري الاتصال الصوتي بدون نت...</span>
          </div>

          <div className="relative inline-block mb-4">
            <div className="w-24 h-24 rounded-full bg-slate-800 border-2 border-cyan-400/60 flex items-center justify-center text-4xl shadow-xl shadow-cyan-900/40">
              {callState.peer.avatar || '👤'}
            </div>
            <div className="absolute -inset-1 rounded-full border border-cyan-400/40 animate-ping pointer-events-none" />
          </div>

          <h3 className="text-lg font-bold text-white mb-1">{callState.peer.name}</h3>
          <p className="text-xs text-slate-400 mb-6 font-mono">{callState.peer.ip || 'شبكة Wi-Fi محلية'}</p>

          <p className="text-xs text-cyan-400 font-medium mb-8 animate-pulse">
            جاري انتظار رد الطرف الآخر...
          </p>

          <div className="flex justify-center">
            <button
              onClick={onEndCall}
              className="flex flex-col items-center gap-1.5 text-xs text-slate-300 group cursor-pointer"
            >
              <div className="w-14 h-14 rounded-full bg-rose-600 hover:bg-rose-700 text-white flex items-center justify-center shadow-lg shadow-rose-950/50 transition-transform active:scale-95">
                <PhoneOff size={22} />
              </div>
              <span className="font-semibold text-rose-400">إلغاء الاتصال</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // 4. Connected Active Call Modal / Sheet
  if (callState.status === 'connected') {
    return (
      <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
        <div className="w-full max-w-sm bg-gradient-to-b from-slate-900 via-slate-900/95 to-slate-950 border border-emerald-500/50 rounded-3xl p-6 text-center shadow-2xl shadow-emerald-950/40 relative">
          {/* Header Minimize Button */}
          <div className="absolute top-4 left-4">
            <button
              onClick={() => setIsMinimized(true)}
              className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition-colors"
              title="تصغير المكالمة ومتابعة الدردشة"
            >
              <Minimize2 size={16} />
            </button>
          </div>

          {/* Secure LAN Badge */}
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-semibold mb-6">
            <ShieldCheck size={14} className="text-emerald-400" />
            <span>مكالمة صوتية مباشرة ومشفرة محلياً 🔒</span>
          </div>

          {/* Peer Avatar & Audio Waves */}
          <div className="relative inline-block mb-4">
            <div className="w-24 h-24 rounded-full bg-slate-800 border-2 border-emerald-400 flex items-center justify-center text-4xl shadow-xl shadow-emerald-950/60">
              {callState.peer.avatar || '👤'}
            </div>
            {/* Dynamic visual audio waves */}
            <div className="flex items-center justify-center gap-1 mt-4 h-6">
              {[40, 75, 100, 60, 90, 45, 80].map((height, idx) => (
                <div
                  key={idx}
                  className="w-1 bg-emerald-400 rounded-full animate-pulse"
                  style={{
                    height: `${height}%`,
                    animationDelay: `${idx * 120}ms`,
                    animationDuration: '600ms',
                  }}
                />
              ))}
            </div>
          </div>

          <h3 className="text-lg font-bold text-white mb-1">{callState.peer.name}</h3>
          <p className="text-xs text-slate-400 font-mono mb-2">{callState.peer.ip || 'شبكة Wi-Fi مباشرة'}</p>

          {/* Call Duration Counter */}
          <div className="text-sm font-mono font-bold text-emerald-400 mb-8 bg-emerald-950/40 border border-emerald-800/40 rounded-full py-1 px-4 inline-block">
            {formatDuration(callState.durationSeconds)}
          </div>

          {/* Call Controls Toolbar */}
          <div className="flex items-center justify-center gap-4">
            {/* Mute Toggle */}
            <button
              onClick={onToggleMute}
              className={`p-3.5 rounded-2xl border transition-all cursor-pointer ${
                callState.isMuted
                  ? 'bg-rose-500/20 border-rose-500/50 text-rose-300'
                  : 'bg-slate-800/80 border-slate-700 text-slate-200 hover:bg-slate-800'
              }`}
              title={callState.isMuted ? 'إلغاء كتم المايك' : 'كتم المايك'}
            >
              {callState.isMuted ? <MicOff size={20} /> : <Mic size={20} />}
            </button>

            {/* End Call Button */}
            <button
              onClick={onEndCall}
              className="px-6 py-3.5 rounded-2xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-sm flex items-center gap-2 shadow-lg shadow-rose-950/60 transition-transform active:scale-95 cursor-pointer"
            >
              <PhoneOff size={18} />
              <span>إنهاء المكالمة</span>
            </button>

            {/* Speaker Toggle */}
            <button
              onClick={onToggleSpeaker}
              className={`p-3.5 rounded-2xl border transition-all cursor-pointer ${
                callState.isSpeaker
                  ? 'bg-cyan-500/20 border-cyan-500/50 text-cyan-300'
                  : 'bg-slate-800/80 border-slate-700 text-slate-200 hover:bg-slate-800'
              }`}
              title="مكبر الصوت"
            >
              {callState.isSpeaker ? <Volume2 size={20} /> : <Volume1 size={20} />}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // 5. Call Ended Screen
  if (callState.status === 'ended') {
    return (
      <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 text-center shadow-2xl">
          <PhoneOff size={32} className="text-rose-400 mx-auto mb-2" />
          <h4 className="text-sm font-bold text-slate-100">انتهت المكالمة</h4>
          <p className="text-xs text-slate-400 mt-1 font-mono">
            المدة: {formatDuration(callState.durationSeconds)}
          </p>
        </div>
      </div>
    );
  }

  return null;
};
