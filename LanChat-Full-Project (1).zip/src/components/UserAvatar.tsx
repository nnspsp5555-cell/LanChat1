import React from 'react';
import { UserStatus } from '../types/chat';

interface UserAvatarProps {
  avatar?: string | null;
  name?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  status?: UserStatus;
  showStatus?: boolean;
  className?: string;
  borderClass?: string;
  onClick?: () => void;
}

const sizeClasses = {
  xs: 'w-6 h-6 text-xs',
  sm: 'w-8 h-8 text-sm',
  md: 'w-10 h-10 text-base',
  lg: 'w-12 h-12 text-xl',
  xl: 'w-16 h-16 text-3xl',
};

const statusDotSize = {
  xs: 'w-1.5 h-1.5 border',
  sm: 'w-2.5 h-2.5 border-2',
  md: 'w-3 h-3 border-2',
  lg: 'w-3.5 h-3.5 border-2',
  xl: 'w-4 h-4 border-2',
};

const statusColors: Record<UserStatus, string> = {
  online: 'bg-emerald-400 shadow-[0_0_8px_#34d399]',
  busy: 'bg-rose-500 shadow-[0_0_8px_#f43f5e]',
  away: 'bg-amber-400 shadow-[0_0_8px_#fbbf24]',
  offline: 'bg-slate-400 shadow-[0_0_6px_#94a3b8]',
};

export const isImageAvatar = (avatar?: string | null): boolean => {
  if (!avatar) return false;
  return (
    avatar.startsWith('data:image/') ||
    avatar.startsWith('/uploads/') ||
    avatar.startsWith('http://') ||
    avatar.startsWith('https://') ||
    avatar.startsWith('blob:')
  );
};

export const UserAvatar: React.FC<UserAvatarProps> = ({
  avatar,
  name,
  size = 'md',
  status,
  showStatus = false,
  className = '',
  borderClass = 'border-slate-700/80',
  onClick,
}) => {
  const isImage = isImageAvatar(avatar);

  return (
    <div
      onClick={onClick}
      className={`relative rounded-full flex items-center justify-center shrink-0 select-none overflow-visible ${sizeClasses[size]} ${className}`}
    >
      <div
        className={`w-full h-full rounded-full overflow-hidden border flex items-center justify-center bg-slate-900 shadow-sm ${borderClass}`}
      >
        {isImage ? (
          <img
            src={avatar!}
            alt={name || 'صورة الملف الشخصي'}
            className="w-full h-full object-cover rounded-full"
            loading="lazy"
            onError={(e) => {
              // Fallback if image fails to load
              (e.target as HTMLElement).style.display = 'none';
            }}
          />
        ) : (
          <span className="flex items-center justify-center font-bold">
            {avatar || '👑'}
          </span>
        )}
      </div>

      {showStatus && status && (
        <span
          title={
            status === 'online'
              ? 'متصل'
              : status === 'busy'
              ? 'مشغول'
              : status === 'away'
              ? 'في استراحة'
              : 'غير متصل (متخفي)'
          }
          className={`absolute -bottom-0.5 -right-0.5 rounded-full border-slate-950 z-10 ${statusDotSize[size]} ${statusColors[status]}`}
        />
      )}
    </div>
  );
};
