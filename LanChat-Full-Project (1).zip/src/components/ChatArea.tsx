import React, { useRef, useEffect, useState } from 'react';
import {
  Users,
  Smartphone,
  Laptop,
  Tablet,
  Search,
  ArrowDown,
  X,
  Zap,
  Info,
  Sparkles,
  Lock,
  Crown,
  PhoneCall,
  ArrowRight,
} from 'lucide-react';
import {
  ChatMessage,
  User,
  AccentColor,
  ReplyContext,
  ThemeSettings,
  ChatGroup,
} from '../types/chat';
import { MessageItem } from './MessageItem';
import { ChatInput } from './ChatInput';
import { UserAvatar } from './UserAvatar';

interface ChatAreaProps {
  activeChatId: string;
  activeGroup?: ChatGroup | null;
  currentUser: User | null;
  targetPeer: User | null;
  onlineCount: number;
  messages: ChatMessage[];
  typingUsers: { id: string; name: string }[];
  settings: ThemeSettings;
  onSendMessage: (params: {
    content: string;
    mediaType?: 'text' | 'image' | 'video' | 'audio' | 'file';
    fileUrl?: string;
    fileName?: string;
    fileSize?: number;
    fileMime?: string;
    replyTo?: ReplyContext;
  }) => void;
  onTyping: (isTyping: boolean) => void;
  onSendNudge: (targetId: string) => void;
  onOpenImage: (url: string, fileName?: string) => void;
  onRecordSoundFeedback: () => void;
  isSearching: boolean;
  onCloseSearch: () => void;
  onStartVoiceCall?: (peer: User) => void;
  onBackToList?: () => void;
  onDeleteMessage?: (messageId: string, forEveryone: boolean) => void;
}

export const ChatArea: React.FC<ChatAreaProps> = ({
  activeChatId,
  activeGroup,
  currentUser,
  targetPeer,
  onlineCount,
  messages,
  typingUsers,
  settings,
  onSendMessage,
  onTyping,
  onSendNudge,
  onOpenImage,
  onRecordSoundFeedback,
  isSearching,
  onCloseSearch,
  onStartVoiceCall,
  onBackToList,
  onDeleteMessage,
}) => {
  const [replyTo, setReplyTo] = useState<ReplyContext | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showScrollBottom, setShowScrollBottom] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const scrollContainerRef = useRef<HTMLDivElement | null>(null);

  const isGroup = !!activeGroup || activeChatId === 'public' || activeChatId.startsWith('group_');

  // Filter messages based on search query
  const filteredMessages = searchQuery.trim()
    ? messages.filter((m) =>
        m.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
        m.senderName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (m.fileName && m.fileName.toLowerCase().includes(searchQuery.toLowerCase()))
      )
    : messages;

  // Auto scroll to bottom
  const scrollToBottom = (behavior: ScrollBehavior = 'smooth') => {
    messagesEndRef.current?.scrollIntoView({ behavior });
  };

  useEffect(() => {
    scrollToBottom('auto');
  }, [activeChatId]);

  useEffect(() => {
    // Only auto scroll if user is near bottom
    const container = scrollContainerRef.current;
    if (container) {
      const isNearBottom =
        container.scrollHeight - container.scrollTop - container.clientHeight < 160;
      if (isNearBottom) {
        scrollToBottom('smooth');
      }
    }
  }, [messages.length]);

  const handleScroll = () => {
    const container = scrollContainerRef.current;
    if (container) {
      const isUp = container.scrollHeight - container.scrollTop - container.clientHeight > 220;
      setShowScrollBottom(isUp);
    }
  };

  const handleReplyMessage = (msg: ChatMessage) => {
    setReplyTo({
      id: msg.id,
      senderName: msg.senderName,
      content: msg.content,
      mediaType: msg.mediaType,
    });
  };

  // Font size classes
  const fontSizes = {
    sm: 'text-xs',
    md: 'text-sm',
    lg: 'text-base',
  };

  // Background pattern classes
  const patternClasses = {
    none: '',
    dots: 'chat-pattern-dots',
    grid: 'chat-pattern-grid',
    waves: 'chat-pattern-waves',
  };

  return (
    <div
      className={`flex-1 flex flex-col h-full overflow-hidden relative ${patternClasses[settings.pattern]}`}
    >
      {/* Decorative Brand Background Watermark: آل عيسى */}
      <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none select-none opacity-[0.05] z-0">
        <Crown size={130} className="text-amber-400 stroke-1" />
        <span className="font-black text-6xl sm:text-7xl tracking-widest text-amber-300 font-cairo mt-3">
          آل عيسى
        </span>
        <span className="text-xs text-amber-200 tracking-widest font-mono mt-1">
          LAN CHAT • SECURE WI-FI
        </span>
      </div>

      {/* Chat Area Header */}
      <div className="h-14 border-b border-slate-800/80 bg-slate-950/70 backdrop-blur-md px-3 sm:px-4 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2 sm:gap-2.5 min-w-0">
          {/* Mobile Back Button: return to full-screen chats list */}
          {onBackToList && (
            <button
              onClick={onBackToList}
              className="lg:hidden p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-cyan-400 hover:bg-slate-800 transition-colors cursor-pointer shrink-0"
              title="الرجوع إلى قائمة المحادثات"
            >
              <ArrowRight size={18} />
            </button>
          )}
          {isGroup ? (
            <>
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center text-lg shadow-md shrink-0 ${
                  activeGroup?.id === 'group_al_issa'
                    ? 'bg-gradient-to-tr from-amber-600 to-yellow-500 text-white'
                    : 'bg-gradient-to-tr from-cyan-600 to-blue-500 text-white'
                }`}
              >
                {activeGroup?.avatar || '👥'}
              </div>
              <div className="min-w-0">
                <h3 className="font-bold text-xs sm:text-sm text-slate-100 truncate flex items-center gap-1.5">
                  <span className="truncate">{activeGroup?.name || 'الغرفة العامة'}</span>
                  {activeGroup?.id === 'group_al_issa' && <span className="text-amber-400">👑</span>}
                </h3>
                <p className="text-[11px] text-slate-400 truncate">
                  {activeGroup?.description || 'محادثة مفتوحة لجميع أجهزة الشبكة'} • {onlineCount} متصل
                </p>
              </div>
            </>
          ) : (
            <>
              <UserAvatar
                avatar={targetPeer?.avatar}
                name={targetPeer?.name}
                size="sm"
                status={targetPeer?.status || 'offline'}
                showStatus={true}
              />
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 font-bold text-xs sm:text-sm text-slate-100 truncate">
                  <span className="truncate">{targetPeer?.name || 'مستخدم غير متصل'}</span>
                </div>
                <div className="text-[11px] text-slate-400 font-mono truncate flex items-center gap-2">
                  <span>{targetPeer?.ip || 'IP غير متاح'}</span>
                  {targetPeer?.status && (
                    <span className="text-[10px] text-cyan-400">
                      • {targetPeer.status === 'online' ? 'متصل الآن' : targetPeer.status === 'busy' ? 'مشغول' : targetPeer.status === 'away' ? 'في استراحة' : 'غير متصل (متخفي)'}
                    </span>
                  )}
                </div>
              </div>
            </>
          )}
        </div>

        {/* Header Right Action: Encryption Badge, Voice Call & Buzz / Nudge */}
        <div className="flex items-center gap-2">
          {settings.encryptionEnabled && (
            <div
              className="flex items-center gap-1 text-[11px] text-emerald-300 bg-emerald-950/60 border border-emerald-800/50 px-2 py-1 rounded-xl shadow-sm"
              title="تشفير محلي مفعل للرسائل 🔒"
            >
              <Lock size={12} className="text-emerald-400" />
              <span className="hidden sm:inline font-semibold">مشفرة</span>
            </div>
          )}

          {/* Voice Call without internet (LAN / P2P) */}
          {!isGroup && targetPeer && onStartVoiceCall && (
            <button
              onClick={() => onStartVoiceCall(targetPeer)}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 text-xs font-semibold shadow-sm transition-all cursor-pointer active:scale-95"
              title="بدء مكالمة صوتية محلية بدون إنترنت"
            >
              <PhoneCall size={13} className="text-emerald-400" />
              <span className="hidden sm:inline">مكالمة صوتية</span>
            </button>
          )}

          <button
            onClick={() => onSendNudge(activeChatId)}
            className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-300 text-xs font-semibold transition-all cursor-pointer"
            title="إرسال تنبيه واهتزاز إلى الطرف الآخر"
          >
            <Zap size={13} className="text-amber-400" />
            <span className="hidden sm:inline">نكز / تنبيه</span>
          </button>
        </div>
      </div>

      {/* In-Chat Search Bar */}
      {isSearching && (
        <div className="bg-slate-900 border-b border-slate-800 p-2 px-3 flex items-center justify-between gap-2 animate-in slide-in-from-top-2">
          <div className="flex items-center gap-2 flex-1">
            <Search size={15} className="text-slate-400 shrink-0" />
            <input
              type="text"
              autoFocus
              placeholder="ابحث في رسائل هذه المحادثة..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-transparent text-xs text-slate-100 placeholder-slate-500 outline-none w-full"
            />
          </div>
          {searchQuery && (
            <span className="text-[10px] text-slate-400 font-mono">
              {filteredMessages.length} نتيجة
            </span>
          )}
          <button
            onClick={() => {
              setSearchQuery('');
              onCloseSearch();
            }}
            className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white"
          >
            <X size={15} />
          </button>
        </div>
      )}

      {/* Messages Scroll Container */}
      <div
        ref={scrollContainerRef}
        onScroll={handleScroll}
        className={`flex-1 overflow-y-auto p-3 sm:p-4 space-y-1 ${fontSizes[settings.fontSize]}`}
      >
        {/* Empty State */}
        {filteredMessages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-3 select-none">
            <div className="w-14 h-14 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center justify-center text-cyan-400 shadow-xl">
              <Sparkles size={26} />
            </div>
            <div>
              <h4 className="font-bold text-sm text-slate-200">
                {isGroup ? `مرحباً بك في ${activeGroup?.name || 'المجموعة'}!` : `محادثة خاصة مع ${targetPeer?.name || 'المستخدم'}`}
              </h4>
              <p className="text-xs text-slate-400 max-w-xs mt-1 leading-relaxed">
                {isGroup
                  ? 'يمكنك إرسال الرسائل والصور والمقاطع الصوتية والملفات إلى جميع أعضاء هذه المجموعة على شبكة Wi-Fi.'
                  : 'هذه المحادثة خاصة بينكما فقط وتُنقل مباشرة عبر شبكة Wi-Fi المحلية دون المرور بالإنترنت.'}
              </p>
            </div>

            {/* Quick Starters */}
            <div className="flex flex-wrap justify-center gap-2 pt-2">
              {[
                'سلام عليكم ورحمة الله 👋',
                'مرحباً، هل الصوت والصورة واضحة؟',
                'أنا متصل عبر شبكة Wi-Fi المحلية 📱',
              ].map((starter) => (
                <button
                  key={starter}
                  onClick={() => onSendMessage({ content: starter, mediaType: 'text' })}
                  className="px-3 py-1.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-cyan-400 text-xs transition-colors cursor-pointer"
                >
                  {starter}
                </button>
              ))}
            </div>
          </div>
        ) : (
          filteredMessages.map((msg) => {
            const isSelf = msg.senderId === currentUser?.id;
            return (
              <MessageItem
                key={msg.id}
                message={msg}
                isSelf={isSelf}
                accent={settings.accent}
                onReply={handleReplyMessage}
                onOpenImage={onOpenImage}
                onDeleteMessage={onDeleteMessage}
              />
            );
          })
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Typing indicator */}
      {typingUsers.length > 0 && (
        <div className="px-4 py-1 text-[11px] text-cyan-400 flex items-center gap-1.5 bg-slate-950/60 border-t border-slate-900 select-none animate-pulse">
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
          <span>
            {typingUsers.map((u) => u.name).join('، ')} يكتب الآن... ✍️
          </span>
        </div>
      )}

      {/* Floating Scroll to Bottom Button */}
      {showScrollBottom && (
        <button
          onClick={() => scrollToBottom('smooth')}
          className="absolute bottom-20 left-4 p-2.5 rounded-full bg-cyan-600 hover:bg-cyan-500 text-white shadow-xl transition-all cursor-pointer z-20 animate-in fade-in"
          title="الانتقال لآخر الرسائل"
        >
          <ArrowDown size={18} />
        </button>
      )}

      {/* Chat Input */}
      <ChatInput
        accent={settings.accent}
        replyTo={replyTo}
        onCancelReply={() => setReplyTo(null)}
        onSendMessage={(params) => {
          onSendMessage({ ...params, replyTo: replyTo || undefined });
          setReplyTo(null);
        }}
        onTyping={onTyping}
        onRecordSoundFeedback={onRecordSoundFeedback}
      />
    </div>
  );
};
