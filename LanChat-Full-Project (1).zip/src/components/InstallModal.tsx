import React from 'react';
import { X, Smartphone, Download, Check, Sparkles, MoreVertical } from 'lucide-react';

interface InstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  deferredPrompt: any;
  onInstallNative: () => void;
}

export const InstallModal: React.FC<InstallModalProps> = ({
  isOpen,
  onClose,
  deferredPrompt,
  onInstallNative,
}) => {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 select-none animate-in fade-in"
      onClick={onClose}
    >
      <div
        className="bg-slate-900 border border-slate-700/80 rounded-3xl w-full max-w-md shadow-2xl p-5 flex flex-col gap-4 text-slate-100"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-cyan-500/20 text-cyan-400">
              <Smartphone size={22} />
            </div>
            <div>
              <h2 className="font-bold text-base flex items-center gap-1.5">
                <span>تثبيت تطبيق آل عيسى 👑</span>
              </h2>
              <p className="text-xs text-slate-400">تطبيق محادثة آل عيسى عبر Wi-Fi بدون إنترنت</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Main 1-Click Project ZIP Download Banner for GitHub */}
        <div className="bg-gradient-to-r from-emerald-950/90 to-cyan-950/90 border-2 border-emerald-400/80 rounded-2xl p-4 text-center space-y-3 shadow-xl shadow-emerald-950/50">
          <div className="flex items-center justify-center gap-2 text-emerald-400 font-bold text-sm sm:text-base">
            <Download size={22} className="animate-pulse" />
            <span>تحميل ملف المشروع بالكامل (دفعة واحدة للرفع على GitHub)</span>
          </div>
          <p className="text-xs text-slate-200 leading-relaxed">
            اضغط على الزر الأخضر أدناه لتنزيل حزمة <strong className="text-emerald-300 font-mono">LanChat-Full-Project.zip</strong> كاملة بضغطة واحدة إلى هاتفك أو جهازك:
          </p>
          <a
            href="/api/download-full-project-zip"
            download="LanChat-Full-Project.zip"
            className="w-full py-3.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-sm sm:text-base flex items-center justify-center gap-2.5 transition-all active:scale-95 shadow-xl shadow-emerald-900/60 cursor-pointer block text-center"
          >
            <Download size={20} />
            <span>📥 اضغط هنا لتنزيل ملف المشروع كاملاً (ZIP)</span>
          </a>
        </div>

        {/* Native 1-Click Install Button if supported */}
        {deferredPrompt && (
          <div className="bg-gradient-to-r from-cyan-950/60 to-blue-950/60 border border-cyan-500/40 rounded-2xl p-4 text-center space-y-2.5">
            <Sparkles size={24} className="mx-auto text-cyan-400 animate-bounce" />
            <h3 className="font-bold text-sm text-cyan-200">هاتفك يدعم التثبيت الفوري بضغطة واحدة!</h3>
            <button
              onClick={onInstallNative}
              className="w-full py-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-extrabold text-sm flex items-center justify-center gap-2 transition-transform active:scale-95 shadow-xl cursor-pointer"
            >
              <Download size={18} />
              <span>اضغط هنا لتثبيت التطبيق على الشاشة الرئيسية 📲</span>
            </button>
          </div>
        )}

        {/* Visual Guide for Android & iPhone */}
        <div className="space-y-3">
          <h4 className="text-xs font-bold text-slate-300">
            خطوات التثبيت من الهاتف:
          </h4>

          <div className="space-y-2">
            <div className="bg-slate-950/60 border border-slate-800 p-2.5 rounded-xl text-xs space-y-1.5">
              <span className="font-bold text-emerald-400 block">📱 لأجهزة أندرويد (متصفح Chrome):</span>
              <p className="text-slate-300 leading-relaxed">
                اضغط على زر خيارات المتصفح <strong className="text-cyan-300 font-mono">(⋮)</strong> ثم اختر <strong className="text-emerald-400">«تثبيت التطبيق» (Install App)</strong> أو «إضافة للشاشة الرئيسية».
              </p>
            </div>

            <div className="bg-slate-950/60 border border-slate-800 p-2.5 rounded-xl text-xs space-y-1.5">
              <span className="font-bold text-sky-400 block">🍏 لأجهزة آيفون (متصفح Safari):</span>
              <p className="text-slate-300 leading-relaxed">
                اضغط على زر المشاركة بالأسفل <strong className="text-cyan-300 font-mono">[⎋]</strong> ثم اختر <strong className="text-sky-300">«إضافة إلى الصفحة الرئيسية»</strong>.
              </p>
            </div>
          </div>

          {/* Copy Link Button for opening on other phones */}
          <button
            onClick={() => {
              if (typeof window !== 'undefined') {
                navigator.clipboard.writeText(window.location.href);
                alert('تم نسخ رابط التطبيق! يمكنك إرساله لأي هاتف لتثبيته.');
              }
            }}
            className="w-full py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 hover:text-cyan-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
          >
            <span>📋 نسخ رابط التطبيق المباشر</span>
          </button>
        </div>

        {/* APK & Android Studio Section */}
        <div className="bg-slate-950/80 border border-emerald-500/40 rounded-2xl p-3.5 space-y-2.5">
          <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs">
            <Smartphone size={16} />
            <span>خيارات ملف APK لنظام أندرويد:</span>
          </div>

          <p className="text-[11px] text-slate-300 leading-relaxed">
            يمكنك استخراج ملف <strong className="text-emerald-300 font-mono">.apk</strong> جاهز ومخصص لهاتفك بعدة طرق:
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
            <a
              href="/api/download-android-zip"
              download="LanChat-Android-Project.zip"
              className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-emerald-300 text-[11px] font-semibold flex items-center justify-center gap-1.5 transition-all text-center cursor-pointer shadow-sm"
            >
              <Download size={14} />
              <span>تحميل مشروع Android Studio (ZIP)</span>
            </a>

            <a
              href="/api/download-full-project-zip"
              download="LanChat-Full-Project.zip"
              className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-cyan-300 text-[11px] font-semibold flex items-center justify-center gap-1.5 transition-all text-center cursor-pointer shadow-sm"
            >
              <Download size={14} />
              <span>حزمة GitHub لبناء APK أوتوماتيكياً</span>
            </a>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 p-2 rounded-xl text-[10px] text-slate-400 leading-relaxed">
            💡 <strong className="text-slate-200">طريقة سريعة لـ APK فوري:</strong> ادخل على موقع <strong className="text-emerald-400">PWABuilder.com</strong> أو <strong className="text-emerald-400">Webintoapp.com</strong> وضع رابط هذا التطبيق واضغط Generate APK لتنزيل ملف تثبيت مباشر!
          </div>
        </div>

        {/* Advantages */}
        <div className="bg-slate-950/40 p-3 rounded-2xl border border-slate-800/80 text-[11px] text-slate-400 space-y-1">
          <div className="flex items-center gap-1.5 text-slate-300 font-semibold">
            <Check size={14} className="text-emerald-400" />
            <span>يعمل بدون متجر بلاي وبدون ملفات APK معقدة كـ PWA</span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-300 font-semibold">
            <Check size={14} className="text-emerald-400" />
            <span>حجمه خفيف جداً ولا يستهلك ذاكرة الهاتف</span>
          </div>
        </div>

        {/* Footer */}
        <button
          onClick={onClose}
          className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors cursor-pointer"
        >
          فهمت، شكراً
        </button>
      </div>
    </div>
  );
};
