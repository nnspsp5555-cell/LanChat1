import React, { useState, useEffect } from 'react';
import {
  Users,
  Smartphone,
  Laptop,
  Tablet,
  Radio,
  Search,
  Zap,
  MessageSquare,
  ShieldAlert,
  Radar,
  Loader2,
  Wifi,
  Plus,
  Crown,
  Lock,
  X,
  Trash2,
  Bluetooth,
  Edit3,
} from 'lucide-react';
import { User, DeviceType, AccentColor, ChatGroup, ConnectionMode } from '../types/chat';
import { BluetoothPanel } from './BluetoothPanel';
import { UserAvatar } from './UserAvatar';

interface PeersListProps {
  currentUser: User | null;
  peers: User[];
  groups: ChatGroup[];
  activeChatId: string; // 'public', 'group_*' or userId
  connectionMode: ConnectionMode;
  onToggleConnectionMode: (mode: ConnectionMode) => void;
  onSelectChat: (chatId: string) => void;
  onSendNudge: (targetId: string) => void;
  onCreateGroup: (name: string, avatar: string, description: string) => void;
  onDeleteGroup?: (id: string) => void;
  unreadCounts: Record<string, number>;
  accent: AccentColor;
  onCloseMobileDrawer?: () => void;
  onEditProfile?: () => void;
}

const GROUP_EMOJIS = ['👥', '👑', '🏡', '💼', '⚽', '🚗', '🌴', '☕', '🎮', '💡', '🎉', '🔥'];

export const PeersList: React.FC<PeersListProps> = ({
  currentUser,
  peers,
  groups,
  activeChatId,
  connectionMode,
  onToggleConnectionMode,
  onSelectChat,
  onSendNudge,
  onCreateGroup,
  onDeleteGroup,
  unreadCounts,
  accent,
  onCloseMobileDrawer,
  onEditProfile,
}) => {
  // WhatsApp Tabs: 'private' (الخاص) or 'groups' (المجموعات)
  const isCurrentlyGroup = activeChatId === 'public' || activeChatId.startsWith('group_');
  const [activeTab, setActiveTab] = useState<'private' | 'groups'>(isCurrentlyGroup ? 'groups' : 'private');

  const [searchTerm, setSearchTerm] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [networkDevices, setNetworkDevices] = useState<{ ip: string; mac: string; type: string }[]>([]);

  // Modal to create group
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newGroupName, setNewGroupName] = useState('');
  const [newGroupDesc, setNewGroupDesc] = useState('');
  const [newGroupEmoji, setNewGroupEmoji] = useState('👥');

  // Function to scan local router for connected devices immediately
  const scanRouterDevices = async () => {
    setIsScanning(true);
    try {
      const res = await fetch('/api/discover-devices');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.devices)) {
          setNetworkDevices(data.devices);
        }
      }
    } catch (e) {
      console.warn('Network discovery error:', e);
    } finally {
      setTimeout(() => setIsScanning(false), 800);
    }
  };

  useEffect(() => {
    scanRouterDevices();
  }, []);

  // Update active tab when user switches chat
  useEffect(() => {
    if (activeChatId === 'public' || activeChatId.startsWith('group_')) {
      setActiveTab('groups');
    } else {
      setActiveTab('private');
    }
  }, [activeChatId]);

  // Calculate unread totals
  const otherPeers = peers.filter((p) => p.id !== currentUser?.id);
  const totalPrivateUnread = otherPeers.reduce((acc, p) => acc + (unreadCounts[p.id] || 0), 0);
  const totalGroupsUnread = groups.reduce((acc, g) => acc + (unreadCounts[g.id] || 0), 0);

  // Filter lists based on search
  const filteredPeers = otherPeers.filter((p) =>
    p.name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const filteredGroups = groups.filter(
    (g) =>
      g.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      g.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Device icon resolver
  const renderDeviceIcon = (deviceType: DeviceType) => {
    switch (deviceType) {
      case 'android':
        return (
          <span title="هاتف أندرويد" className="inline-flex items-center">
            <Smartphone size={13} className="text-emerald-400" />
          </span>
        );
      case 'mobile':
        return (
          <span title="هاتف ذكي" className="inline-flex items-center">
            <Smartphone size={13} className="text-sky-400" />
          </span>
        );
      case 'tablet':
        return (
          <span title="جهاز لوحي" className="inline-flex items-center">
            <Tablet size={13} className="text-purple-400" />
          </span>
        );
      default:
        return (
          <span title="كمبيوتر / حاسوب" className="inline-flex items-center">
            <Laptop size={13} className="text-amber-400" />
          </span>
        );
    }
  };

  const activeItemBorder: Record<AccentColor, string> = {
    cyan: 'border-cyan-500 bg-cyan-500/10 text-cyan-300',
    emerald: 'border-emerald-500 bg-emerald-500/10 text-emerald-300',
    violet: 'border-violet-500 bg-violet-500/10 text-violet-300',
    amber: 'border-amber-500 bg-amber-500/10 text-amber-300',
    rose: 'border-rose-500 bg-rose-500/10 text-rose-300',
    sky: 'border-sky-500 bg-sky-500/10 text-sky-300',
  };

  const handleSelect = (id: string) => {
    onSelectChat(id);
    if (onCloseMobileDrawer) onCloseMobileDrawer();
  };

  const handleCreateGroupSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGroupName.trim()) return;
    onCreateGroup(newGroupName.trim(), newGroupEmoji, newGroupDesc.trim());
    setNewGroupName('');
    setNewGroupDesc('');
    setShowCreateModal(false);
  };

  return (
    <div className="flex flex-col h-full bg-slate-950/70 border-l border-slate-800/80 w-full select-none">
      {/* Top Header */}
      <div className="p-3 border-b border-slate-800/70 space-y-2.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center shadow-sm">
              <Crown size={14} className="fill-current" />
            </div>
            <h2 className="font-bold text-sm text-slate-100 flex items-center gap-1">
              <span>شبكة آل عيسى</span>
            </h2>
          </div>
          <span className="text-xs bg-slate-800 text-slate-300 px-2 py-0.5 rounded-full font-mono">
            {peers.length} أجهزة
          </span>
        </div>

        {/* Connection Mode Switcher: Wi-Fi Without Net vs Bluetooth */}
        <div className="grid grid-cols-2 p-1 bg-slate-900 border border-slate-800 rounded-2xl gap-1 shadow-inner">
          <button
            onClick={() => onToggleConnectionMode('wifi')}
            className={`py-1.5 px-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              connectionMode === 'wifi'
                ? 'bg-cyan-500 text-slate-950 shadow-sm font-extrabold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Wifi size={13} />
            <span>واي فاي (بدون نت)</span>
          </button>

          <button
            onClick={() => onToggleConnectionMode('bluetooth')}
            className={`py-1.5 px-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              connectionMode === 'bluetooth'
                ? 'bg-blue-600 text-white shadow-sm font-extrabold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Bluetooth size={13} />
            <span>بلوتوث (مباشر)</span>
          </button>
        </div>

        {/* WhatsApp-Style Top Tabs (Shown in Wi-Fi Mode) */}
        {connectionMode === 'wifi' && (
          <div className="grid grid-cols-2 p-1 bg-slate-900 border border-slate-800 rounded-2xl gap-1">
            {/* Tab 1: المجموعات */}
            <button
              onClick={() => setActiveTab('groups')}
              className={`py-2 px-3 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                activeTab === 'groups'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Users size={15} />
              <span>المجموعات</span>
              {totalGroupsUnread > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-amber-500 text-slate-950">
                  {totalGroupsUnread}
                </span>
              )}
            </button>

            {/* Tab 2: الخاص */}
            <button
              onClick={() => setActiveTab('private')}
              className={`py-2 px-3 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                activeTab === 'private'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <MessageSquare size={15} />
              <span>الخاص</span>
              {totalPrivateUnread > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-cyan-500 text-slate-950">
                  {totalPrivateUnread}
                </span>
              )}
            </button>
          </div>
        )}

        {/* Search & Radar Scan Row (Wi-Fi Mode) */}
        {connectionMode === 'wifi' && (
          <div className="flex items-center gap-1.5">
            <div className="relative flex-1">
              <input
                type="text"
                placeholder={activeTab === 'groups' ? 'بحث عن مجموعة...' : 'بحث عن شخص أو جهاز...'}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-2.5 py-1.5 pr-8 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
              />
              <Search size={14} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
            </div>

            <button
              onClick={scanRouterDevices}
              disabled={isScanning}
              className="p-2 rounded-xl bg-cyan-950/60 hover:bg-cyan-900/80 border border-cyan-800/40 text-cyan-300 transition-colors cursor-pointer shrink-0"
              title="فحص أجهزة Wi-Fi على الراوتر فوراً (رادار)"
            >
              {isScanning ? (
                <Loader2 size={15} className="animate-spin text-cyan-400" />
              ) : (
                <Radar size={15} className="text-cyan-400" />
              )}
            </button>
          </div>
        )}
      </div>

      {/* Main Content Area */}
      {connectionMode === 'bluetooth' ? (
        <BluetoothPanel onSelectPeerChat={(peerName) => {}} accent={accent} />
      ) : (
        <div className="flex-1 overflow-y-auto p-2 space-y-1.5">
          {/* ================= TAB 1: المجموعات (GROUPS) ================= */}
          {activeTab === 'groups' && (
            <div className="space-y-1.5 animate-in fade-in">
            {/* Create Group Action Bar */}
            <button
              onClick={() => setShowCreateModal(true)}
              className="w-full flex items-center justify-between p-2.5 rounded-xl border border-dashed border-amber-500/40 bg-amber-950/20 hover:bg-amber-950/40 text-amber-300 text-xs font-semibold transition-all cursor-pointer"
            >
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
                  <Plus size={18} />
                </div>
                <span>إنشاء مجموعة جديدة على الـ Wi-Fi</span>
              </div>
              <span className="text-[10px] bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-md font-mono">
                + جديد
              </span>
            </button>

            {/* Groups list */}
            {filteredGroups.map((group) => {
              const isActive = activeChatId === group.id;
              const unread = unreadCounts[group.id] || 0;
              const isSpecialAlIssa = group.id === 'group_al_issa';

              return (
                <div
                  key={group.id}
                  className={`group flex items-center justify-between p-2.5 rounded-xl border text-right transition-all cursor-pointer ${
                    isActive
                      ? activeItemBorder[accent]
                      : isSpecialAlIssa
                      ? 'border-amber-500/30 bg-gradient-to-r from-amber-950/20 to-slate-900/60 hover:bg-slate-900 text-slate-100'
                      : 'border-slate-800/70 bg-slate-900/40 hover:bg-slate-900 text-slate-200'
                  }`}
                  onClick={() => handleSelect(group.id)}
                >
                  <div className="flex items-center gap-2.5 min-w-0 flex-1">
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg shadow-md shrink-0 ${
                        isSpecialAlIssa
                          ? 'bg-gradient-to-tr from-amber-600 to-yellow-500 text-white'
                          : group.id === 'public'
                          ? 'bg-gradient-to-tr from-cyan-600 to-blue-500 text-white'
                          : 'bg-slate-800 border border-slate-700'
                      }`}
                    >
                      {group.avatar}
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="font-bold text-xs truncate flex items-center gap-1.5">
                        <span className="truncate">{group.name}</span>
                        {isSpecialAlIssa && <Crown size={12} className="text-amber-400 shrink-0" />}
                      </div>
                      <div className="text-[11px] text-slate-400 truncate">
                        {group.description}
                      </div>
                    </div>
                  </div>

                  {/* Badges / Delete if custom */}
                  <div className="flex items-center gap-1.5 shrink-0">
                    {unread > 0 && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500 text-slate-950">
                        {unread}
                      </span>
                    )}

                    {!group.isProtected && onDeleteGroup && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeleteGroup(group.id);
                        }}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition-colors opacity-0 group-hover:opacity-100 cursor-pointer"
                        title="حذف المجموعة"
                      >
                        <Trash2 size={13} />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* ================= TAB 2: الخاص (DIRECT / PRIVATE) ================= */}
        {activeTab === 'private' && (
          <div className="space-y-1.5 animate-in fade-in">
            <div className="px-1 text-[11px] font-semibold text-cyan-400 flex items-center justify-between">
              <span>المحادثات الخاصة ({otherPeers.length})</span>
            </div>

            {filteredPeers.length === 0 ? (
              <div className="text-center py-6 px-3 text-slate-500 text-xs">
                {searchTerm ? (
                  'لا يوجد متصل يطابق البحث'
                ) : (
                  <div className="space-y-1.5">
                    <MessageSquare size={26} className="mx-auto text-slate-600" />
                    <p className="text-slate-300 font-semibold">لا توجد أجهزة متصلة بالخاص حالياً</p>
                    <p className="text-[10px] text-slate-500 leading-relaxed">
                      وصّل هاتف أندرويد آخر بنفس شبكة الـ Wi-Fi وافتح التطبيق لتظهر المحادثة المباشرة فوراً!
                    </p>
                  </div>
                )}
              </div>
            ) : (
              filteredPeers.map((peer) => {
                const isActive = activeChatId === peer.id;
                const unread = unreadCounts[peer.id] || 0;

                return (
                  <div
                    key={peer.id}
                    className={`group flex items-center justify-between p-2 rounded-xl border text-right transition-all ${
                      isActive
                        ? activeItemBorder[accent]
                        : 'border-slate-800/60 bg-slate-900/30 hover:bg-slate-900/80 text-slate-200'
                    }`}
                  >
                    {/* Peer trigger */}
                    <button
                      onClick={() => handleSelect(peer.id)}
                      className="flex items-center gap-2.5 min-w-0 flex-1 text-right cursor-pointer"
                    >
                      <UserAvatar
                        avatar={peer.avatar}
                        name={peer.name}
                        size="sm"
                        status={peer.status}
                        showStatus={true}
                      />

                      <div className="min-w-0 flex-1">
                        <div className="font-semibold text-xs truncate flex items-center gap-1.5">
                          <span
                            className={`w-2 h-2 rounded-full shrink-0 ${
                              peer.status === 'online'
                                ? 'bg-emerald-400 shadow-[0_0_8px_#34d399]'
                                : peer.status === 'busy'
                                ? 'bg-rose-500 shadow-[0_0_8px_#f43f5e]'
                                : peer.status === 'away'
                                ? 'bg-amber-400 shadow-[0_0_8px_#fbbf24]'
                                : 'bg-slate-400'
                            }`}
                            title={
                              peer.status === 'online'
                                ? 'متصل'
                                : peer.status === 'busy'
                                ? 'مشغول'
                                : peer.status === 'away'
                                ? 'في استراحة'
                                : 'غير متصل (متخفي)'
                            }
                          />
                          <span className="truncate">{peer.name}</span>
                          {renderDeviceIcon(peer.deviceType)}
                          <span
                            className={`text-[9px] font-semibold px-1.5 py-0.2 rounded-full shrink-0 border ${
                              peer.status === 'online'
                                ? 'text-emerald-400 bg-emerald-950/70 border-emerald-800/40'
                                : peer.status === 'busy'
                                ? 'text-rose-400 bg-rose-950/70 border-rose-800/40'
                                : peer.status === 'away'
                                ? 'text-amber-400 bg-amber-950/70 border-amber-800/40'
                                : 'text-slate-400 bg-slate-900 border-slate-700/60'
                            }`}
                          >
                            {peer.status === 'online'
                              ? 'متصل'
                              : peer.status === 'busy'
                              ? 'مشغول'
                              : peer.status === 'away'
                              ? 'استراحة'
                              : 'غير متصل'}
                          </span>
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono flex items-center gap-1">
                          <span>{peer.ip || 'Wi-Fi Peer'}</span>
                          <span className="text-[9px] text-emerald-400">🔒 خاص</span>
                        </div>
                      </div>
                    </button>

                    {/* Actions */}
                    <div className="flex items-center gap-1">
                      {unread > 0 && (
                        <span className="px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500 text-slate-950">
                          {unread}
                        </span>
                      )}

                      {/* Nudge / Buzz button */}
                      <button
                        onClick={() => onSendNudge(peer.id)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-amber-400 hover:bg-amber-500/10 transition-colors opacity-80 group-hover:opacity-100 cursor-pointer"
                        title={`إرسال تنبيه اهتزاز إلى ${peer.name}`}
                      >
                        <Zap size={14} />
                      </button>
                    </div>
                  </div>
                );
              })
            )}

            {/* Router Discovered Wi-Fi Devices */}
            {networkDevices.length > 0 && (
              <div className="pt-3 border-t border-slate-800/80">
                <div className="px-1 text-[11px] font-semibold text-emerald-400 flex items-center justify-between mb-1.5">
                  <span className="flex items-center gap-1">
                    <Wifi size={12} />
                    <span>أجهزة نشطة على الراوتر ({networkDevices.length})</span>
                  </span>
                </div>

                <div className="space-y-1">
                  {networkDevices.map((nd) => (
                    <div
                      key={nd.ip}
                      className="p-2 rounded-xl bg-slate-900/40 border border-slate-800/50 flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <Smartphone size={14} className="text-emerald-400" />
                        <div>
                          <div className="font-mono text-[11px] text-slate-200">{nd.ip}</div>
                          <div className="text-[9px] text-slate-500 font-mono">{nd.mac}</div>
                        </div>
                      </div>
                      <span className="text-[10px] text-emerald-400/90 bg-emerald-950/40 px-1.5 py-0.5 rounded border border-emerald-800/30">
                        متصل
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
      )}

      {/* Modal: Create New Group */}
      {showCreateModal && (
        <div
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in"
          onClick={() => setShowCreateModal(false)}
        >
          <div
            className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-sm p-4 text-slate-100 space-y-3 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
              <div className="flex items-center gap-2">
                <span className="text-xl">{newGroupEmoji}</span>
                <h3 className="font-bold text-sm">إنشاء مجموعة جديدة على الـ Wi-Fi</h3>
              </div>
              <button
                onClick={() => setShowCreateModal(false)}
                className="p-1 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleCreateGroupSubmit} className="space-y-3">
              {/* Group Name */}
              <div>
                <label className="text-xs text-slate-300 block mb-1 font-semibold">اسم المجموعة:</label>
                <input
                  type="text"
                  placeholder="مثال: شباب الديوانية، أصدقاء العمل..."
                  value={newGroupName}
                  onChange={(e) => setNewGroupName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-500"
                  required
                />
              </div>

              {/* Group Description */}
              <div>
                <label className="text-xs text-slate-300 block mb-1">وصف المجموعة (اختياري):</label>
                <input
                  type="text"
                  placeholder="وصف مختصر للغرفة..."
                  value={newGroupDesc}
                  onChange={(e) => setNewGroupDesc(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Emoji Picker */}
              <div>
                <label className="text-xs text-slate-300 block mb-1">أيقونة المجموعة:</label>
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                  {GROUP_EMOJIS.map((emoji) => (
                    <button
                      type="button"
                      key={emoji}
                      onClick={() => setNewGroupEmoji(emoji)}
                      className={`text-lg p-1.5 rounded-xl border transition-transform ${
                        newGroupEmoji === emoji
                          ? 'border-amber-500 bg-amber-500/20 scale-110'
                          : 'border-slate-800 hover:bg-slate-800'
                      }`}
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md cursor-pointer mt-2"
              >
                <Plus size={16} />
                <span>إنشاء المجموعة الآن</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Self Profile Strip at bottom */}
      {currentUser && (
        <div
          onClick={onEditProfile}
          title="انقر لتعديل اسمك أو صورتك الرمزية"
          className="p-2.5 border-t border-slate-800/80 bg-slate-900/70 hover:bg-slate-800/60 transition-colors flex items-center justify-between cursor-pointer group"
        >
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-8 h-8 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 flex items-center justify-center text-sm font-bold shrink-0 group-hover:scale-105 transition-transform shadow-sm">
              {currentUser.avatar}
            </div>
            <div className="min-w-0">
              <div className="text-xs font-bold text-slate-200 truncate flex items-center gap-1.5">
                <span
                  className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_8px_#34d399] shrink-0"
                  title="أنت متصل الآن على شبكة آل عيسى"
                />
                <span className="group-hover:text-amber-300 transition-colors">
                  {currentUser.hasCustomName && currentUser.name ? currentUser.name : 'أضف اسمك هنا ✍️'}
                </span>
                <span className="text-[10px] text-amber-400 font-semibold">(أنت)</span>
              </div>
              <div className="text-[10px] text-slate-400 font-mono truncate">
                {currentUser.ip || 'شبكة آل عيسى المحلية'}
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              if (onEditProfile) onEditProfile();
            }}
            title="تعديل اسمك"
            className="p-1.5 rounded-xl bg-slate-800/80 hover:bg-amber-500/20 text-slate-400 hover:text-amber-300 border border-slate-700/60 transition-all shrink-0 flex items-center gap-1 text-[11px] font-semibold"
          >
            <Edit3 size={12} />
            <span className="hidden sm:inline">تعديل</span>
          </button>
        </div>
      )}
    </div>
  );
};
