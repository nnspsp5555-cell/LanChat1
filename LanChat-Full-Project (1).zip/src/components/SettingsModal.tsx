import React, { useState } from 'react';
import {
  X,
  Palette,
  User as UserIcon,
  Volume2,
  Vibrate,
  Download,
  Trash2,
  Check,
  Type,
  Layout,
  FileText,
  Sparkles,
  Lock,
  Shield,
  Maximize,
  Minimize,
  Image as ImageIcon,
  Upload,
} from 'lucide-react';
import {
  ThemeSettings,
  ThemePreset,
  PatternStyle,
  AccentColor,
  FontSize,
  User,
  ChatMessage,
  UserStatus,
} from '../types/chat';
import { exportChatHistory, exportChatAsText, clearAllLocalChatHistory } from '../utils/storage';
import { UserAvatar, isImageAvatar } from './UserAvatar';
import { compressProfileImage } from '../utils/media';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User | null;
  onUpdateProfile: (name: string, avatar: string, status: UserStatus) => void;
  settings: ThemeSettings;
  onUpdateSettings: (newSettings: ThemeSettings) => void;
  messagesToExport: ChatMessage[];
  onClearHistory: () => void;
}

const AVATAR_OPTIONS = [
  '⚡', '🤖', '🚀', '🦁', '🦅', '🦊', '🐺', '🌟', '👑',
  '🔥', '💎', '🎯', '🎨', '🎧', '🎮', '🛡️', '🌙', '☕'
];

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onUpdateProfile,
  settings,
  onUpdateSettings,
  messagesToExport,
  onClearHistory,
}) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'appearance' | 'data'>('profile');

  // Profile Form state
  const [name, setName] = useState(currentUser?.name || 'مستخدم Wi-Fi');
  const [avatar, setAvatar] = useState(currentUser?.avatar || '⚡');
  const [status, setStatus] = useState<UserStatus>(currentUser?.status || 'online');
  const [profileSaved, setProfileSaved] = useState(false);
  const [isProcessingImage, setIsProcessingImage] = useState(false);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleGallerySelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setIsProcessingImage(true);
      const compressed = await compressProfileImage(file, 256);
      setAvatar(compressed);
    } catch (err) {
      console.error('Error compressing profile image:', err);
    } finally {
      setIsProcessingImage(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile(name, avatar, status);
    setProfileSaved(true);
    setTimeout(() => setProfileSaved(false), 2000);
  };

  const themePresets: { id: ThemePreset; name: string; bgClass: string }[] = [
    { id: 'slate', name: 'داكن كلاسيكي (Slate)', bgClass: 'bg-slate-900 border-slate-700' },
    { id: 'amoled', name: 'أسود نقي (AMOLED)', bgClass: 'bg-black border-neutral-800' },
    { id: 'navy', name: 'أزرق ليلي (Midnight)', bgClass: 'bg-blue-950 border-blue-800' },
    { id: 'emerald', name: 'زمردي هادئ (Emerald)', bgClass: 'bg-emerald-950 border-emerald-800' },
    { id: 'violet', name: 'بنفسجي عصري (Violet)', bgClass: 'bg-purple-950 border-purple-800' },
  ];

  const patternStyles: { id: PatternStyle; name: string }[] = [
    { id: 'none', name: 'بدون نقش (ناعم)' },
    { id: 'dots', name: 'نقاط مصفوفة' },
    { id: 'grid', name: 'شبكة هندسية' },
    { id: 'waves', name: 'أمواج خافتة' },
  ];

  const accentColors: { id: AccentColor; name: string; colorClass: string }[] = [
    { id: 'cyan', name: 'فيروزي', colorClass: 'bg-cyan-500' },
    { id: 'emerald', name: 'زمردي', colorClass: 'bg-emerald-500' },
    { id: 'violet', name: 'بنفسجي', colorClass: 'bg-violet-500' },
    { id: 'amber', name: 'عنبري', colorClass: 'bg-amber-500' },
    { id: 'rose', name: 'وردي', colorClass: 'bg-rose-500' },
    { id: 'sky', name: 'سماوي', colorClass: 'bg-sky-500' },
  ];

  const fontSizes: { id: FontSize; name: string }[] = [
    { id: 'sm', name: 'صغير' },
    { id: 'md', name: 'متوسط' },
    { id: 'lg', name: 'كبير' },
  ];

  return (
    <div
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 select-none animate-in fade-in"
      onClick={onClose}
    >
      <div
        className="bg-slate-900 border border-slate-700/80 rounded-3xl w-full max-w-lg max-h-[90vh] overflow-y-auto shadow-2xl p-4 sm:p-6 flex flex-col gap-4 text-slate-100"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-400">
              <Sparkles size={20} />
            </div>
            <div>
              <h2 className="font-bold text-base sm:text-lg">إعدادات التطبيق والمظهر</h2>
              <p className="text-xs text-slate-400">خصص مظهرك وسجل محادثاتك المحلية</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-2xl border border-slate-800">
          <button
            onClick={() => setActiveTab('profile')}
            className={`flex-1 py-1.5 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'profile'
                ? 'bg-cyan-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <UserIcon size={14} />
            <span>الملف الشخصي</span>
          </button>

          <button
            onClick={() => setActiveTab('appearance')}
            className={`flex-1 py-1.5 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'appearance'
                ? 'bg-cyan-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Palette size={14} />
            <span>المظهر والخلفية</span>
          </button>

          <button
            onClick={() => setActiveTab('data')}
            className={`flex-1 py-1.5 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'data'
                ? 'bg-cyan-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Download size={14} />
            <span>السجل والبيانات</span>
          </button>
        </div>

        {/* Tab 1: Profile */}
        {activeTab === 'profile' && (
          <form onSubmit={handleSaveProfile} className="space-y-4 pt-1">
            {/* Current Avatar preview & selection */}
            <div>
              {/* Hidden file input */}
              <input
                type="file"
                ref={fileInputRef}
                accept="image/*"
                onChange={handleGallerySelected}
                className="hidden"
              />

              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-semibold text-slate-300">
                  صورة الملف الشخصي:
                </label>
                {isImageAvatar(avatar) && (
                  <button
                    type="button"
                    onClick={() => setAvatar('⚡')}
                    className="text-[11px] text-rose-400 hover:text-rose-300 flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    <Trash2 size={12} />
                    <span>الرجوع للرمز التعبيري</span>
                  </button>
                )}
              </div>

              {/* Gallery Image Upload Button & Live Preview */}
              <div className="flex items-center gap-3 mb-3 p-3 bg-slate-950 rounded-2xl border border-slate-800">
                <UserAvatar avatar={avatar} name={name} size="lg" status={status} showStatus={true} />
                <div className="flex-1 min-w-0">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isProcessingImage}
                    className="w-full py-2 px-3 rounded-xl bg-cyan-500/15 border border-cyan-500/40 hover:bg-cyan-500/25 text-cyan-300 text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <ImageIcon size={15} />
                    <span>{isProcessingImage ? 'جاري تجهيز الصورة...' : 'اختيار صورة من المعرض 🖼️'}</span>
                  </button>
                  <p className="text-[10px] text-slate-400 mt-1 truncate">
                    يمكنك اختيار صورة شخصية من جهازك أو اختيار أحد الرموز أدناه
                  </p>
                </div>
              </div>

              {/* Emojis grid */}
              <label className="text-[11px] text-slate-400 block mb-1.5 font-medium">
                أو اختر رمزاً تعبيرياً:
              </label>
              <div className="grid grid-cols-6 sm:grid-cols-9 gap-2 max-h-28 overflow-y-auto p-1 bg-slate-950/60 rounded-xl border border-slate-800/80">
                {AVATAR_OPTIONS.map((em) => (
                  <button
                    type="button"
                    key={em}
                    onClick={() => setAvatar(em)}
                    className={`h-9 rounded-xl flex items-center justify-center text-lg transition-all cursor-pointer ${
                      avatar === em && !isImageAvatar(avatar)
                        ? 'bg-cyan-500/20 border-2 border-cyan-400 scale-110 shadow-lg'
                        : 'bg-slate-900 border border-slate-800 hover:bg-slate-800'
                    }`}
                  >
                    {em}
                  </button>
                ))}
              </div>
            </div>

            {/* Name Input */}
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                اسمك الظاهر للأجهزة على الشبكة:
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                maxLength={30}
                required
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                placeholder="أدخل اسمك أو اسم جهازك..."
              />
            </div>

            {/* Status Select (Includes Offline) */}
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                الحالة:
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                {(
                  [
                    { id: 'online', label: 'متصل 🟢' },
                    { id: 'busy', label: 'مشغول 🔴' },
                    { id: 'away', label: 'استراحة 🟡' },
                    { id: 'offline', label: 'غير متصل (متخفي) ⚪' },
                  ] as const
                ).map((st) => (
                  <button
                    type="button"
                    key={st.id}
                    onClick={() => setStatus(st.id)}
                    className={`py-1.5 px-1 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                      status === st.id
                        ? 'border-cyan-500 bg-cyan-500/10 text-cyan-300'
                        : 'border-slate-800 bg-slate-950 text-slate-400 hover:bg-slate-800'
                    }`}
                  >
                    {st.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Submit */}
            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-lg cursor-pointer"
            >
              {profileSaved ? (
                <>
                  <Check size={16} />
                  <span>تم حفظ التعديلات ونشرها للشبكة!</span>
                </>
              ) : (
                <span>حفظ الملف الشخصي</span>
              )}
            </button>
          </form>
        )}

        {/* Tab 2: Appearance & Theme */}
        {activeTab === 'appearance' && (
          <div className="space-y-4 pt-1">
            {/* Theme Presets */}
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-2 flex items-center gap-1.5">
                <Palette size={14} className="text-cyan-400" />
                <span>النمط الداكن العام:</span>
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {themePresets.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => onUpdateSettings({ ...settings, preset: t.id })}
                    className={`flex items-center gap-2.5 p-2 rounded-xl border text-right transition-all cursor-pointer ${
                      settings.preset === t.id
                        ? 'border-cyan-400 ring-2 ring-cyan-500/30 bg-slate-800'
                        : 'border-slate-800 bg-slate-950 hover:bg-slate-800/60'
                    }`}
                  >
                    <div className={`w-6 h-6 rounded-lg ${t.bgClass} shrink-0`} />
                    <span className="text-xs font-medium">{t.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Accent Color */}
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-2">
                لون التمييز والأزرار (Accent):
              </label>
              <div className="flex items-center gap-2.5 flex-wrap">
                {accentColors.map((ac) => (
                  <button
                    key={ac.id}
                    onClick={() => onUpdateSettings({ ...settings, accent: ac.id })}
                    className={`flex items-center gap-1.5 px-2.5 py-1 rounded-xl border text-xs transition-all cursor-pointer ${
                      settings.accent === ac.id
                        ? 'border-white bg-slate-800 shadow-md scale-105'
                        : 'border-slate-800 bg-slate-950 text-slate-400'
                    }`}
                  >
                    <span className={`w-3.5 h-3.5 rounded-full ${ac.colorClass}`} />
                    <span>{ac.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Background Pattern */}
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-2 flex items-center gap-1.5">
                <Layout size={14} className="text-cyan-400" />
                <span>نقش خلفية المحادثة:</span>
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {patternStyles.map((pat) => (
                  <button
                    key={pat.id}
                    onClick={() => onUpdateSettings({ ...settings, pattern: pat.id })}
                    className={`p-2 rounded-xl border text-center text-xs transition-all cursor-pointer ${
                      settings.pattern === pat.id
                        ? 'border-cyan-400 bg-cyan-500/10 text-cyan-300 font-bold'
                        : 'border-slate-800 bg-slate-950 text-slate-400 hover:bg-slate-800'
                    }`}
                  >
                    {pat.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Font Size */}
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-2 flex items-center gap-1.5">
                <Type size={14} className="text-cyan-400" />
                <span>حجم خط الرسائل:</span>
              </label>
              <div className="flex gap-2">
                {fontSizes.map((fs) => (
                  <button
                    key={fs.id}
                    onClick={() => onUpdateSettings({ ...settings, fontSize: fs.id })}
                    className={`flex-1 py-1.5 rounded-xl border text-xs font-semibold transition-all cursor-pointer ${
                      settings.fontSize === fs.id
                        ? 'border-cyan-400 bg-cyan-500/10 text-cyan-300'
                        : 'border-slate-800 bg-slate-950 text-slate-400 hover:bg-slate-800'
                    }`}
                  >
                    {fs.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Audio & Vibration Toggles */}
            <div className="space-y-2 pt-1 border-t border-slate-800">
              <label className="flex items-center justify-between p-2.5 bg-slate-950 border border-slate-800 rounded-xl cursor-pointer">
                <div className="flex items-center gap-2">
                  <Volume2 size={16} className="text-cyan-400" />
                  <span className="text-xs font-medium">أصوات الرسائل والتنبيهات</span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.soundEnabled}
                  onChange={(e) =>
                    onUpdateSettings({ ...settings, soundEnabled: e.target.checked })
                  }
                  className="accent-cyan-500 w-4 h-4 cursor-pointer"
                />
              </label>

              <label className="flex items-center justify-between p-2.5 bg-slate-950 border border-slate-800 rounded-xl cursor-pointer">
                <div className="flex items-center gap-2">
                  <Vibrate size={16} className="text-cyan-400" />
                  <span className="text-xs font-medium">اهتزاز الهاتف عند التنبيه والرسائل</span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.vibrationEnabled}
                  onChange={(e) =>
                    onUpdateSettings({ ...settings, vibrationEnabled: e.target.checked })
                  }
                  className="accent-cyan-500 w-4 h-4 cursor-pointer"
                />
              </label>

              {/* Fullscreen control toggle */}
              <div className="flex items-center justify-between p-2.5 bg-slate-950 border border-slate-800 rounded-xl">
                <div className="flex items-center gap-2">
                  <Maximize size={16} className="text-cyan-400" />
                  <div>
                    <span className="text-xs font-medium text-slate-200 block">وضع ملء الشاشة (على كد الشاشة)</span>
                    <span className="text-[10px] text-slate-400 block">إخفاء أشرطة المتصفح وتوسيع التطبيق لكامل الشاشة</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    if (!document.fullscreenElement) {
                      document.documentElement.requestFullscreen?.().catch(() => {});
                    } else {
                      document.exitFullscreen?.().catch(() => {});
                    }
                  }}
                  className="px-2.5 py-1 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold transition-all shadow-sm cursor-pointer"
                >
                  {typeof document !== 'undefined' && document.fullscreenElement ? 'تصغير' : 'ملء الشاشة'}
                </button>
              </div>

              {/* Encryption Layer Settings */}
              <div className="p-3 bg-slate-950 border border-emerald-900/60 rounded-xl space-y-2">
                <label className="flex items-center justify-between cursor-pointer">
                  <div className="flex items-center gap-2">
                    <Shield size={16} className="text-emerald-400" />
                    <div>
                      <span className="text-xs font-bold text-slate-200 block">تشفير الرسائل عبر Wi-Fi</span>
                      <span className="text-[10px] text-slate-400 block">حماية المحادثات من التجسس (AES-GCM) 🔒</span>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={settings.encryptionEnabled}
                    onChange={(e) =>
                      onUpdateSettings({ ...settings, encryptionEnabled: e.target.checked })
                    }
                    className="accent-emerald-500 w-4 h-4 cursor-pointer"
                  />
                </label>

                {settings.encryptionEnabled && (
                  <div className="pt-1.5 border-t border-slate-800/80">
                    <label className="text-[11px] text-slate-400 block mb-1">
                      مفتاح التشفير الخاص (اختياري - بينك وبين صديقك):
                    </label>
                    <input
                      type="text"
                      placeholder="اتركه فارغاً للتشفير التلقائي للشبكة..."
                      value={settings.secretPassphrase || ''}
                      onChange={(e) =>
                        onUpdateSettings({ ...settings, secretPassphrase: e.target.value })
                      }
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-emerald-500 font-mono"
                    />
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Local Data & History */}
        {activeTab === 'data' && (
          <div className="space-y-4 pt-1">
            <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-3.5 space-y-2">
              <h4 className="font-bold text-xs text-slate-200">حفظ سجل الرسائل محلياً</h4>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                يتم حفظ محادثاتك تلقائياً داخل ذاكرة التخزين المحلية للمتصفح (LocalStorage) على جهازك، ولن يتم مسحها عند إغلاق التطبيق.
              </p>
              <div className="text-xs font-mono text-cyan-400 pt-1">
                الرسائل المسجلة حالياً: {messagesToExport.length} رسالة
              </div>
            </div>

            {/* Export buttons */}
            <div className="space-y-2">
              <button
                onClick={() => exportChatHistory(messagesToExport)}
                className="w-full py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-semibold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Download size={15} className="text-cyan-400" />
                <span>تصدير نسخة احتياطية من السجل (JSON)</span>
              </button>

              <button
                onClick={() => exportChatAsText(messagesToExport)}
                className="w-full py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-semibold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <FileText size={15} className="text-emerald-400" />
                <span>تصدير السجل كملف نصي قابل للقراءة (TXT)</span>
              </button>
            </div>

            {/* Clear History */}
            <div className="pt-2 border-t border-slate-800">
              <button
                onClick={() => {
                  if (confirm('هل أنت متأكد من رغبتك في مسح سجل المحادثات المحلي بالكامل من هذا الجهاز؟')) {
                    clearAllLocalChatHistory();
                    onClearHistory();
                  }
                }}
                className="w-full py-2.5 px-3 rounded-xl bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800/60 text-rose-300 font-semibold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Trash2 size={15} />
                <span>مسح سجل المحادثات من هذا الجهاز</span>
              </button>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="pt-2 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors cursor-pointer"
          >
            تم
          </button>
        </div>
      </div>
    </div>
  );
};
