import React, { useState, useEffect } from 'react';
import {
  Wifi,
  WifiOff,
  Settings,
  QrCode,
  Zap,
  Users,
  Search,
  RefreshCw,
  Download,
  Sparkles,
  Crown,
  Bluetooth,
  Maximize,
  Minimize,
  MessageSquare,
} from 'lucide-react';
import { AccentColor, ConnectionMode, User } from '../types/chat';

interface NavbarProps {
  isConnected: boolean;
  onlineCount: number;
  connectionMode: ConnectionMode;
  onToggleConnectionMode: (mode: ConnectionMode) => void;
  onOpenNetworkModal: () => void;
  onOpenSettingsModal: () => void;
  onOpenInstallModal: () => void;
  onToggleMobileDrawer: () => void;
  onSendNudge: () => void;
  onToggleSearch: () => void;
  isSearching: boolean;
  unreadTotal: number;
  accent: AccentColor;
  isMobileList?: boolean;
  currentUser?: User | null;
  onEditProfile?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  isConnected,
  onlineCount,
  connectionMode,
  onToggleConnectionMode,
  onOpenNetworkModal,
  onOpenSettingsModal,
  onOpenInstallModal,
  onToggleMobileDrawer,
  onSendNudge,
  onToggleSearch,
  isSearching,
  unreadTotal,
  accent,
  isMobileList = false,
  currentUser,
  onEditProfile,
}) => {
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    const handleFsChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement));
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    document.addEventListener('webkitfullscreenchange', handleFsChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFsChange);
      document.removeEventListener('webkitfullscreenchange', handleFsChange);
    };
  }, []);

  const toggleFullscreen = () => {
    try {
      if (!document.fullscreenElement) {
        if (document.documentElement.requestFullscreen) {
          document.documentElement.requestFullscreen();
        } else if ((document.documentElement as any).webkitRequestFullscreen) {
          (document.documentElement as any).webkitRequestFullscreen();
        }
      } else {
        if (document.exitFullscreen) {
          document.exitFullscreen();
        } else if ((document as any).webkitExitFullscreen) {
          (document as any).webkitExitFullscreen();
        }
      }
    } catch (err) {
      console.warn('Fullscreen toggle failed:', err);
    }
  };
  return (
    <header className="h-14 bg-slate-950/90 border-b border-slate-800 backdrop-blur-md px-3 sm:px-4 flex items-center justify-between select-none z-30 shrink-0">
      {/* Right side (RTL Start): Logo & Status */}
      <div className="flex items-center gap-2 sm:gap-3 shrink-0 min-w-0">
        {/* Mobile menu trigger for peers list or back to chat */}
        <button
          onClick={onToggleMobileDrawer}
          className="relative lg:hidden p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-cyan-400 transition-colors cursor-pointer shrink-0"
          title={isMobileList ? 'عرض المحادثة' : 'قائمة الأجهزة والمحادثات'}
        >
          {isMobileList ? <MessageSquare size={18} /> : <Users size={18} />}
          {unreadTotal > 0 && !isMobileList && (
            <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-cyan-500 text-slate-950 text-[10px] font-bold flex items-center justify-center">
              {unreadTotal}
            </span>
          )}
        </button>

        {/* Brand identity: آل عيسى */}
        <div className="flex items-center gap-2 min-w-0">
          <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-2xl bg-gradient-to-tr from-amber-600 via-amber-500 to-yellow-500 flex items-center justify-center text-slate-950 font-black shadow-lg shadow-amber-950/40 border border-amber-400/50 shrink-0">
            <Crown size={18} className="text-slate-950 fill-current" />
          </div>
          <div className="min-w-0">
            <h1 className="font-extrabold text-sm sm:text-base tracking-tight text-white flex items-center gap-1.5 truncate">
              <span className="bg-gradient-to-r from-amber-200 via-amber-300 to-yellow-200 bg-clip-text text-transparent">
                آل عيسى
              </span>
              <span className="text-[11px] text-slate-400 font-normal hidden sm:inline">• دردشة Wi-Fi</span>
            </h1>
            <div className="flex items-center gap-1.5 text-[10px]">
              <span
                className={`inline-block w-1.5 h-1.5 rounded-full ${
                  isConnected ? 'bg-emerald-400 shadow-[0_0_8px_#34d399]' : 'bg-rose-500'
                }`}
              />
              <span className="text-slate-400 truncate">
                {isConnected ? `متصل محلياً (${onlineCount} جهاز)` : 'انقطع الاتصال'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Center: آل عيسى Luxury Logo Badge (Hidden on mobile to save space) */}
      <div className="hidden md:flex items-center justify-center px-1 sm:px-3 shrink-0">
        <div className="relative group px-3.5 py-1.5 sm:px-5 sm:py-1.5 rounded-2xl bg-gradient-to-r from-amber-950/60 via-slate-900/90 to-amber-950/60 border border-amber-500/50 shadow-lg shadow-amber-950/30 backdrop-blur-md transition-all hover:border-amber-400">
          {/* Subtle warm glow */}
          <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-amber-500/15 via-yellow-500/15 to-amber-500/15 opacity-80 blur-xs pointer-events-none" />

          <div className="relative flex items-center gap-1.5 sm:gap-2">
            <Sparkles size={14} className="text-amber-400 animate-pulse shrink-0" />
            <span className="font-black text-xs sm:text-sm tracking-wider bg-gradient-to-r from-amber-200 via-amber-300 to-yellow-100 bg-clip-text text-transparent font-cairo select-none drop-shadow-md">
              👑 آل عيسى
            </span>
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 shadow-[0_0_8px_#f59e0b] shrink-0" />
          </div>
        </div>
      </div>

      {/* Left side (RTL End): Actions */}
      <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
        {/* Connection Mode Selector: Wi-Fi Local vs Bluetooth */}
        <div className="flex items-center bg-slate-900/90 border border-slate-800 p-0.5 rounded-xl shadow-inner shrink-0">
          <button
            onClick={() => onToggleConnectionMode('wifi')}
            className={`flex items-center gap-1 px-1.5 sm:px-2 py-1 rounded-lg text-[10px] sm:text-[11px] font-bold transition-all cursor-pointer ${
              connectionMode === 'wifi'
                ? 'bg-cyan-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title="واي فاي محلي بدون إنترنت (سريع + مكالمات)"
          >
            <Wifi size={12} className={connectionMode === 'wifi' ? 'stroke-[2.5]' : ''} />
            <span className="hidden sm:inline">Wi-Fi محلي</span>
          </button>
          <button
            onClick={() => onToggleConnectionMode('bluetooth')}
            className={`flex items-center gap-1 px-1.5 sm:px-2 py-1 rounded-lg text-[10px] sm:text-[11px] font-bold transition-all cursor-pointer ${
              connectionMode === 'bluetooth'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title="مراسلة مباشرة بالبلوتوث بدون راوتر"
          >
            <Bluetooth size={12} className={connectionMode === 'bluetooth' ? 'stroke-[2.5]' : ''} />
            <span className="hidden sm:inline">بلوتوث</span>
          </button>
        </div>

        {/* Fullscreen Button - على كد الشاشة */}
        <button
          onClick={toggleFullscreen}
          className="p-1.5 sm:p-2 rounded-xl text-slate-400 hover:text-cyan-400 hover:bg-slate-900 transition-colors cursor-pointer shrink-0"
          title={isFullscreen ? 'الخروج من وضع ملء الشاشة' : 'ملء الشاشة بالكامل (على كد الشاشة)'}
        >
          {isFullscreen ? <Minimize size={17} /> : <Maximize size={17} />}
        </button>

        {/* Search in chat */}
        <button
          onClick={onToggleSearch}
          className={`p-1.5 sm:p-2 rounded-xl transition-all cursor-pointer shrink-0 ${
            isSearching
              ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
          title="بحث في المحادثة"
        >
          <Search size={17} />
        </button>

        {/* Buzz / Nudge button */}
        <button
          onClick={onSendNudge}
          className="p-1.5 sm:p-2 rounded-xl text-slate-400 hover:text-amber-400 hover:bg-slate-900 transition-colors cursor-pointer shrink-0"
          title="إرسال تنبيه واهتزاز (نكز)"
        >
          <Zap size={17} />
        </button>

        {/* Install on phone / Download full project ZIP */}
        <button
          onClick={onOpenInstallModal}
          className="flex items-center gap-1.5 py-1.5 px-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-md shadow-emerald-950/50 cursor-pointer shrink-0"
          title="تحميل ملف المشروع بالكامل لرفعه على GitHub أو تثبيت التطبيق"
        >
          <Download size={14} />
          <span>تنزيل المشروع 📥</span>
        </button>

        {/* Wi-Fi & QR code button */}
        <button
          onClick={onOpenNetworkModal}
          className="flex items-center gap-1 sm:gap-1.5 py-1.5 px-2 sm:px-2.5 rounded-xl bg-cyan-950/60 hover:bg-cyan-900/60 border border-cyan-700/50 text-cyan-300 text-xs font-semibold transition-all shadow-sm cursor-pointer shrink-0"
          title="معلومات ربط Wi-Fi ورمز QR"
        >
          <QrCode size={15} />
          <span className="hidden md:inline">ربط الأجهزة</span>
        </button>

        {/* User profile button / Edit name */}
        {currentUser && (
          <button
            onClick={onEditProfile}
            title={`اسمك: ${currentUser.name || 'غير محدد'} - انقر لتعديل الاسم`}
            className="flex items-center gap-1.5 py-1 px-2 sm:px-2.5 rounded-xl bg-slate-900/90 hover:bg-amber-500/15 border border-slate-700/80 hover:border-amber-400/50 text-slate-200 text-xs font-semibold transition-all cursor-pointer shrink-0 max-w-[130px] sm:max-w-[180px] shadow-sm"
          >
            <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-300 flex items-center justify-center text-xs shrink-0">
              {currentUser.avatar}
            </span>
            <span className="truncate text-[11px] sm:text-xs">
              {currentUser.hasCustomName && currentUser.name ? currentUser.name : 'أضف اسمك'}
            </span>
          </button>
        )}

        {/* Settings button */}
        <button
          onClick={onOpenSettingsModal}
          className="p-1.5 sm:p-2 rounded-xl text-slate-400 hover:text-slate-200 hover:bg-slate-900 transition-colors cursor-pointer shrink-0"
          title="الإعدادات والمظهر"
        >
          <Settings size={17} />
        </button>
      </div>
    </header>
  );
};
