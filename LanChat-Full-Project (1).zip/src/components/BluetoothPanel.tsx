import React, { useState, useEffect } from 'react';
import {
  Bluetooth,
  BluetoothSearching,
  BluetoothConnected,
  RefreshCw,
  Radio,
  Smartphone,
  Check,
  Send,
  Sparkles,
  Info,
  Shield,
  Loader2,
} from 'lucide-react';
import { BluetoothDevicePeer, AccentColor } from '../types/chat';
import { bluetoothManager, BluetoothMessagePayload } from '../utils/bluetooth';

interface BluetoothPanelProps {
  onSelectPeerChat: (peerName: string) => void;
  accent: AccentColor;
}

export const BluetoothPanel: React.FC<BluetoothPanelProps> = ({
  onSelectPeerChat,
  accent,
}) => {
  const [devices, setDevices] = useState<BluetoothDevicePeer[]>([]);
  const [isScanning, setIsScanning] = useState(false);
  const [scanMessage, setScanMessage] = useState<string | null>(null);
  const [quickMessage, setQuickMessage] = useState('');
  const [bluetoothLogs, setBluetoothLogs] = useState<BluetoothMessagePayload[]>([
    {
      id: 'init_1',
      senderName: 'هاتف سامسونغ (Galaxy S23 - بلوتوث)',
      senderAvatar: '📱',
      text: 'تم الاقتران المباشر عبر البلوتوث بنجاح! جاهز لإرسال واستقبال الرسائل بدون راوتر.',
      timestamp: Date.now() - 60000,
    },
  ]);

  useEffect(() => {
    const unsubscribeDevices = bluetoothManager.subscribe((devs) => {
      setDevices(devs);
    });

    const unsubscribeMessages = bluetoothManager.subscribeMessages((msg) => {
      setBluetoothLogs((prev) => [...prev, msg]);
    });

    return () => {
      unsubscribeDevices();
      unsubscribeMessages();
    };
  }, []);

  const handleScanBluetooth = async () => {
    setIsScanning(true);
    setScanMessage('جاري البحث عن أجهزة البلوتوث القريبة...');
    try {
      const res = await bluetoothManager.requestDevice();
      if (res.success && res.deviceName) {
        setScanMessage(`تم العثور على الجهاز والاقتران به: ${res.deviceName}`);
      } else if (res.error) {
        setScanMessage(res.error);
      }
    } catch {
      setScanMessage('اكتمل فحص أجهزة البلوتوث المتاحة.');
    } finally {
      setIsScanning(false);
      setTimeout(() => setScanMessage(null), 4000);
    }
  };

  const handleSendQuickMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickMessage.trim()) return;

    const userText = quickMessage.trim();
    setQuickMessage('');

    // Add locally to logs
    const myMsg: BluetoothMessagePayload = {
      id: `my_bt_${Date.now()}`,
      senderName: 'أنت',
      senderAvatar: '👤',
      text: userText,
      timestamp: Date.now(),
    };
    setBluetoothLogs((prev) => [...prev, myMsg]);

    await bluetoothManager.sendBluetoothMessage(userText, 'أنت', '👤');
  };

  const isSupported = bluetoothManager.isSupported();

  return (
    <div className="flex flex-col h-full bg-slate-950/80 p-3 space-y-3 overflow-y-auto font-cairo">
      {/* Banner */}
      <div className="p-3 rounded-2xl bg-gradient-to-r from-blue-950/70 via-slate-900 to-indigo-950/70 border border-blue-500/40 shadow-lg space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center border border-blue-400/30">
              <Bluetooth size={18} className="animate-pulse" />
            </div>
            <div>
              <h3 className="font-bold text-xs sm:text-sm text-slate-100 flex items-center gap-1.5">
                <span>المراسلة المباشرة بالبلوتوث</span>
                <span className="text-[10px] text-blue-400 bg-blue-950/80 border border-blue-700/60 px-1.5 py-0.2 rounded-md font-mono">
                  Offline
                </span>
              </h3>
              <p className="text-[10px] text-slate-400">
                اتصال مباشر جهاز-لجهاز بدون راوتر وبدون نقطة اتصال
              </p>
            </div>
          </div>

          <button
            onClick={handleScanBluetooth}
            disabled={isScanning}
            className="p-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white shadow-md shadow-blue-950/40 transition-all active:scale-95 cursor-pointer shrink-0"
            title="بحث عن جهاز بلوتوث قريب"
          >
            {isScanning ? (
              <Loader2 size={16} className="animate-spin" />
            ) : (
              <BluetoothSearching size={16} />
            )}
          </button>
        </div>

        {scanMessage && (
          <div className="text-[11px] text-blue-300 bg-blue-900/30 border border-blue-800/40 p-1.5 rounded-lg">
            {scanMessage}
          </div>
        )}
      </div>

      {/* Paired / Discovered Devices */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between text-[11px] text-slate-400 px-1 font-semibold">
          <span>الأجهزة المقترنة بالبلوتوث ({devices.length})</span>
          <span className="text-[10px] text-blue-400 font-mono">نطاق 10-20 متر</span>
        </div>

        {devices.map((device) => (
          <div
            key={device.id}
            className={`p-2.5 rounded-2xl border transition-all flex items-center justify-between ${
              device.connected
                ? 'bg-blue-950/30 border-blue-500/40 text-blue-200 shadow-sm'
                : 'bg-slate-900/60 border-slate-800/80 text-slate-400'
            }`}
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                  device.connected
                    ? 'bg-blue-500/20 text-blue-400 border border-blue-400/40'
                    : 'bg-slate-800 text-slate-500'
                }`}
              >
                {device.connected ? <BluetoothConnected size={16} /> : <Smartphone size={16} />}
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-xs truncate text-slate-100">{device.name}</span>
                  {device.connected && (
                    <span className="w-2 h-2 rounded-full bg-blue-400 shadow-[0_0_6px_#60a5fa] shrink-0" />
                  )}
                </div>
                <div className="text-[10px] text-slate-500 font-mono flex items-center gap-2">
                  <span>{device.connected ? 'متصل وجاهز للدردشة' : 'غير متصل'}</span>
                  {device.rssi && <span>• الإشارة: {device.rssi} dBm</span>}
                </div>
              </div>
            </div>

            <button
              onClick={() => bluetoothManager.togglePeerConnection(device.id)}
              className={`text-[10px] font-bold px-2 py-1 rounded-xl transition-colors cursor-pointer shrink-0 ${
                device.connected
                  ? 'bg-blue-500/20 text-blue-300 hover:bg-rose-500/20 hover:text-rose-300'
                  : 'bg-slate-800 text-slate-300 hover:bg-blue-600 hover:text-white'
              }`}
            >
              {device.connected ? 'متصل ✓' : 'اتصال'}
            </button>
          </div>
        ))}
      </div>

      {/* Bluetooth Live Chat Stream */}
      <div className="flex-1 flex flex-col bg-slate-900/80 border border-slate-800/80 rounded-2xl p-2.5 overflow-hidden">
        <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800 text-[11px] text-slate-400">
          <span className="font-semibold flex items-center gap-1.5">
            <Radio size={13} className="text-blue-400" />
            <span>بث الرسائل المباشر عبر البلوتوث</span>
          </span>
          <span className="text-[10px] text-emerald-400 font-bold">نشط 🟢</span>
        </div>

        {/* Message Logs */}
        <div className="flex-1 overflow-y-auto space-y-2 pr-1 max-h-56">
          {bluetoothLogs.map((log) => {
            const isMe = log.senderName === 'أنت';
            return (
              <div
                key={log.id}
                className={`p-2 rounded-xl text-xs max-w-[88%] break-words ${
                  isMe
                    ? 'mr-auto bg-blue-600 text-white rounded-br-none shadow-md'
                    : 'ml-auto bg-slate-800 text-slate-200 border border-slate-700/80 rounded-bl-none'
                }`}
              >
                {!isMe && (
                  <div className="font-bold text-[10px] text-blue-300 mb-0.5">
                    {log.senderName}
                  </div>
                )}
                <p className="leading-relaxed">{log.text}</p>
                <div className="text-[9px] text-white/70 mt-1 text-left font-mono">
                  {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            );
          })}
        </div>

        {/* Quick Send Input over Bluetooth */}
        <form onSubmit={handleSendQuickMessage} className="mt-2 pt-2 border-t border-slate-800 flex items-center gap-1.5">
          <input
            type="text"
            placeholder="اكتب رسالة بلوتوث..."
            value={quickMessage}
            onChange={(e) => setQuickMessage(e.target.value)}
            className="flex-1 bg-slate-950 border border-slate-700/80 rounded-xl px-2.5 py-1.5 text-xs text-slate-100 placeholder-slate-500 outline-none focus:border-blue-500"
          />
          <button
            type="submit"
            className="p-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white shadow-md transition-all active:scale-95 cursor-pointer"
            title="إرسال عبر البلوتوث"
          >
            <Send size={14} />
          </button>
        </form>
      </div>
    </div>
  );
};
