import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Paperclip,
  Image,
  Video,
  FileText,
  Mic,
  Square,
  Trash2,
  Smile,
  X,
  Music,
  Loader2,
} from 'lucide-react';
import { AccentColor, ReplyContext } from '../types/chat';
import { fileToBase64, getMediaTypeFromFile, VoiceRecorder } from '../utils/media';

interface ChatInputProps {
  accent: AccentColor;
  replyTo: ReplyContext | null;
  onCancelReply: () => void;
  onSendMessage: (params: {
    content: string;
    mediaType?: 'text' | 'image' | 'video' | 'audio' | 'file';
    fileUrl?: string;
    fileName?: string;
    fileSize?: number;
    fileMime?: string;
  }) => void;
  onTyping: (isTyping: boolean) => void;
  onRecordSoundFeedback: () => void;
}

const QUICK_EMOJIS = ['👍', '❤️', '😂', '🔥', '👏', '⚡', '🚀', '☕', '🎮', '🤝', '🎉', '👋'];

export const ChatInput: React.FC<ChatInputProps> = ({
  accent,
  replyTo,
  onCancelReply,
  onSendMessage,
  onTyping,
  onRecordSoundFeedback,
}) => {
  const [text, setText] = useState('');
  const [showAttachMenu, setShowAttachMenu] = useState(false);
  const [showEmojiBar, setShowEmojiBar] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgressText, setUploadProgressText] = useState('');

  // Voice recording state
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const recorderRef = useRef<VoiceRecorder | null>(null);
  const timerRef = useRef<any>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const fileTypeFilterRef = useRef<string>('*/*');
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const typingTimerRef = useRef<any>(null);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 120)}px`;
    }
  }, [text]);

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    setText(val);

    // Notify typing
    onTyping(true);
    if (typingTimerRef.current) clearTimeout(typingTimerRef.current);
    typingTimerRef.current = setTimeout(() => {
      onTyping(false);
    }, 1500);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleSend = () => {
    if (isUploading || isRecording) return;
    const trimmed = text.trim();
    if (!trimmed) return;

    onSendMessage({
      content: trimmed,
      mediaType: 'text',
    });

    setText('');
    onTyping(false);
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const addEmoji = (emoji: string) => {
    setText((prev) => prev + emoji);
    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  };

  // Open file selector with type filter
  const triggerFileInput = (accept: string) => {
    fileTypeFilterRef.current = accept;
    setShowAttachMenu(false);
    if (fileInputRef.current) {
      fileInputRef.current.accept = accept;
      fileInputRef.current.click();
    }
  };

  const handleFileSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsUploading(true);
      setUploadProgressText(`جاري تجهيز ${file.name}...`);

      const mediaType = getMediaTypeFromFile(file);
      const dataUrl = await fileToBase64(file);

      // Upload to local server via /api/upload
      setUploadProgressText(`جاري الرفع إلى الخادم المحلي...`);
      const res = await fetch('/api/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fileName: file.name,
          fileType: file.type,
          dataUrl,
        }),
      });

      if (!res.ok) {
        throw new Error('فشل رفع الملف إلى الخادم');
      }

      const data = await res.json();

      onSendMessage({
        content: text.trim(),
        mediaType,
        fileUrl: data.fileUrl,
        fileName: file.name,
        fileSize: file.size,
        fileMime: file.type,
      });

      setText('');
    } catch (err: any) {
      console.error('File upload error:', err);
      alert(err.message || 'حدث خطأ أثناء إرسال الملف');
    } finally {
      setIsUploading(false);
      setUploadProgressText('');
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  // Voice recording controls
  const startRecording = async () => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        alert('المتصفح الحالي لا يدعم تسجيل الصوت أو يجب فتح الرابط عبر اتصال آمن (HTTPS).');
        return;
      }

      const recorder = new VoiceRecorder();
      const started = await recorder.start();
      if (!started) {
        alert('يرجى منح صلاحية الوصول إلى الميكروفون من إعدادات المتصفح لتسجيل الصوت 🎙️');
        return;
      }

      recorderRef.current = recorder;
      setIsRecording(true);
      setRecordingSeconds(0);
      onRecordSoundFeedback();

      if (timerRef.current) clearInterval(timerRef.current);
      timerRef.current = setInterval(() => {
        setRecordingSeconds((s) => s + 1);
      }, 1000);
    } catch (err: any) {
      console.error('Error starting audio recording:', err);
      alert('تعذر الوصول إلى الميكروفون: ' + (err.message || 'خطأ غير معروف'));
    }
  };

  const stopAndSendRecording = async () => {
    if (!recorderRef.current) return;
    try {
      clearInterval(timerRef.current);
      const recordedSecs = recordingSeconds;
      setIsUploading(true);
      setUploadProgressText('جاري معالجة وإرسال التسجيل الصوتي...');

      const { blob, mimeType } = await recorderRef.current.stop();
      setIsRecording(false);
      setRecordingSeconds(0);

      // Convert audio blob to base64
      const reader = new FileReader();
      reader.onload = async () => {
        const dataUrl = reader.result as string;
        const fileName = `voice_${Date.now()}.${mimeType.includes('mp4') ? 'mp4' : 'webm'}`;

        let finalUrl = dataUrl;

        // Try server upload first, fall back to direct dataUrl seamlessly for 100% offline support
        try {
          const res = await fetch('/api/upload', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              fileName,
              fileType: mimeType,
              dataUrl,
            }),
          });
          if (res.ok) {
            const data = await res.json();
            if (data.fileUrl) finalUrl = data.fileUrl;
          }
        } catch (e) {
          console.warn('Server upload skipped, using direct dataUrl for voice message:', e);
        }

        onSendMessage({
          content: '',
          mediaType: 'audio',
          fileUrl: finalUrl,
          fileName: `تسجيل صوتي (${formatTimer(recordedSecs)})`,
          fileSize: blob.size,
          fileMime: mimeType,
        });

        setIsUploading(false);
        setUploadProgressText('');
      };
      reader.readAsDataURL(blob);
    } catch (err) {
      console.error('Error sending audio note:', err);
      setIsRecording(false);
      setIsUploading(false);
      setUploadProgressText('');
    }
  };

  const cancelRecording = () => {
    clearInterval(timerRef.current);
    if (recorderRef.current) {
      recorderRef.current.cancel();
      recorderRef.current = null;
    }
    setIsRecording(false);
    setRecordingSeconds(0);
  };

  const formatTimer = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const accentSendBtn: Record<AccentColor, string> = {
    cyan: 'bg-cyan-500 hover:bg-cyan-400 text-slate-950',
    emerald: 'bg-emerald-500 hover:bg-emerald-400 text-slate-950',
    violet: 'bg-violet-500 hover:bg-violet-400 text-white',
    amber: 'bg-amber-500 hover:bg-amber-400 text-slate-950',
    rose: 'bg-rose-500 hover:bg-rose-400 text-white',
    sky: 'bg-sky-500 hover:bg-sky-400 text-slate-950',
  };

  return (
    <div className="sticky bottom-0 z-30 w-full border-t border-slate-800/80 bg-slate-950/95 backdrop-blur-xl px-2.5 sm:px-4 pt-2 pb-[max(0.65rem,env(safe-area-inset-bottom))] shadow-[0_-8px_30px_rgba(0,0,0,0.5)] shrink-0">
      <div className="max-w-4xl mx-auto w-full relative">
        {/* Hidden file input */}
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileSelected}
          className="hidden"
        />

        {/* Reply Banner */}
        {replyTo && (
          <div className="mb-2 bg-slate-900/90 border border-slate-700/80 border-r-4 border-r-cyan-500 rounded-2xl p-2.5 px-3 flex items-center justify-between shadow-lg animate-in slide-in-from-bottom-2">
            <div className="min-w-0 text-xs">
              <span className="font-bold text-cyan-400 block text-[11px]">الرد على {replyTo.senderName}:</span>
              <span className="text-slate-200 truncate block max-w-sm mt-0.5">{replyTo.content || '[مرفق]'}</span>
            </div>
            <button
              onClick={onCancelReply}
              className="p-1 rounded-full text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X size={16} />
            </button>
          </div>
        )}

        {/* Uploading progress notification */}
        {isUploading && (
          <div className="mb-2 bg-slate-900 border border-cyan-500/40 rounded-2xl p-2 px-3 flex items-center gap-2 text-xs text-cyan-300 animate-pulse">
            <Loader2 size={16} className="animate-spin text-cyan-400" />
            <span>{uploadProgressText}</span>
          </div>
        )}

        {/* Quick Emoji Bar */}
        {showEmojiBar && (
          <div className="mb-2 p-1.5 bg-slate-900/95 border border-slate-800 rounded-2xl flex items-center gap-2 overflow-x-auto no-scrollbar shadow-xl">
            {QUICK_EMOJIS.map((emoji) => (
              <button
                key={emoji}
                onClick={() => addEmoji(emoji)}
                className="text-xl p-1.5 hover:scale-125 transition-transform shrink-0 cursor-pointer"
              >
                {emoji}
              </button>
            ))}
          </div>
        )}

        {/* Attachment Menu Popup */}
        {showAttachMenu && (
          <div
            className="absolute bottom-16 right-2 sm:right-0 bg-slate-900 border border-slate-700/90 rounded-2xl p-2 shadow-2xl z-30 flex flex-col gap-1 w-48 animate-in fade-in slide-in-from-bottom-3"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => triggerFileInput('image/*')}
              className="flex items-center gap-2.5 p-2 rounded-xl text-xs text-slate-200 hover:bg-slate-800 hover:text-cyan-400 transition-colors cursor-pointer"
            >
              <div className="p-1.5 rounded-lg bg-cyan-500/20 text-cyan-400">
                <Image size={16} />
              </div>
              <span>إرسال صورة</span>
            </button>
            <button
              onClick={() => triggerFileInput('video/*')}
              className="flex items-center gap-2.5 p-2 rounded-xl text-xs text-slate-200 hover:bg-slate-800 hover:text-purple-400 transition-colors cursor-pointer"
            >
              <div className="p-1.5 rounded-lg bg-purple-500/20 text-purple-400">
                <Video size={16} />
              </div>
              <span>إرسال فيديو</span>
            </button>
            <button
              onClick={() => triggerFileInput('audio/*')}
              className="flex items-center gap-2.5 p-2 rounded-xl text-xs text-slate-200 hover:bg-slate-800 hover:text-emerald-400 transition-colors cursor-pointer"
            >
              <div className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400">
                <Music size={16} />
              </div>
              <span>ملف صوتي / موسيقى</span>
            </button>
            <button
              onClick={() => {
                setShowAttachMenu(false);
                startRecording();
              }}
              className="flex items-center gap-2.5 p-2 rounded-xl text-xs text-slate-200 hover:bg-slate-800 hover:text-rose-400 transition-colors cursor-pointer"
            >
              <div className="p-1.5 rounded-lg bg-rose-500/20 text-rose-400">
                <Mic size={16} />
              </div>
              <span>تسجيل رسالة صوتية 🎙️</span>
            </button>
            <button
              onClick={() => triggerFileInput('*/*')}
              className="flex items-center gap-2.5 p-2 rounded-xl text-xs text-slate-200 hover:bg-slate-800 hover:text-amber-400 transition-colors cursor-pointer"
            >
              <div className="p-1.5 rounded-lg bg-amber-500/20 text-amber-400">
                <FileText size={16} />
              </div>
              <span>مستند أو ملف / APK</span>
            </button>
          </div>
        )}

        {/* Main Input Row */}
        {isRecording ? (
          // Voice recording interface
          <div className="flex items-center justify-between gap-3 bg-slate-900 border border-rose-500/40 rounded-3xl p-2 px-4 shadow-xl animate-in fade-in">
            <div className="flex items-center gap-3">
              <div className="w-3 h-3 rounded-full bg-rose-500 animate-ping" />
              <span className="font-mono text-sm text-rose-400 font-bold">
                {formatTimer(recordingSeconds)}
              </span>
              <div className="flex items-center gap-1">
                <span className="w-1 h-3 bg-rose-400 rounded-full soundwave-bar" />
                <span className="w-1 h-5 bg-rose-400 rounded-full soundwave-bar" style={{ animationDelay: '0.2s' }} />
                <span className="w-1 h-2 bg-rose-400 rounded-full soundwave-bar" style={{ animationDelay: '0.4s' }} />
                <span className="w-1 h-6 bg-rose-400 rounded-full soundwave-bar" style={{ animationDelay: '0.1s' }} />
              </div>
              <span className="text-xs text-slate-400 hidden sm:inline">جاري التسجيل...</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={cancelRecording}
                className="p-2 rounded-2xl bg-slate-800 hover:bg-rose-900/40 text-rose-400 transition-colors cursor-pointer"
                title="إلغاء التسجيل"
              >
                <Trash2 size={18} />
              </button>
              <button
                onClick={stopAndSendRecording}
                className="p-2 px-3.5 rounded-2xl bg-rose-500 hover:bg-rose-400 text-white flex items-center gap-1.5 text-xs font-bold transition-all shadow-lg cursor-pointer"
                title="إرسال الصوت"
              >
                <Send size={15} className="fill-current rotate-180" />
                <span>إرسال</span>
              </button>
            </div>
          </div>
        ) : (
          // Modern pill input row
          <div className="flex items-end gap-2">
            {/* Main Input Capsule */}
            <div className="flex-1 bg-slate-900/90 border border-slate-800/90 focus-within:border-cyan-500/60 focus-within:ring-2 focus-within:ring-cyan-500/20 rounded-3xl p-1 px-2.5 flex items-end gap-1.5 shadow-inner transition-all">
              {/* Attach Button */}
              <button
                onClick={() => setShowAttachMenu((prev) => !prev)}
                className={`p-2 rounded-full transition-all cursor-pointer shrink-0 ${
                  showAttachMenu
                    ? 'bg-slate-800 text-cyan-400 rotate-45'
                    : 'text-slate-400 hover:text-cyan-400 hover:bg-slate-800/60'
                }`}
                title="إرفاق ملف أو وسائط"
              >
                <Paperclip size={19} />
              </button>

              {/* Text Area */}
              <textarea
                ref={textareaRef}
                rows={1}
                value={text}
                onChange={handleTextChange}
                onKeyDown={handleKeyDown}
                placeholder="اكتب رسالة هنا..."
                className="flex-1 bg-transparent text-slate-100 placeholder-slate-500 text-sm outline-none resize-none max-h-32 py-2 leading-relaxed"
              />

              {/* Emoji Toggle */}
              <button
                onClick={() => setShowEmojiBar((prev) => !prev)}
                className={`p-2 rounded-full transition-all cursor-pointer shrink-0 ${
                  showEmojiBar
                    ? 'bg-slate-800 text-amber-400'
                    : 'text-slate-400 hover:text-amber-400 hover:bg-slate-800/60'
                }`}
                title="رموز تعبيرية"
              >
                <Smile size={19} />
              </button>

              {/* Mic shortcut inside capsule */}
              <button
                onClick={startRecording}
                className="p-2 rounded-full text-slate-400 hover:text-rose-400 hover:bg-slate-800/60 transition-all cursor-pointer shrink-0"
                title="تسجيل رسالة صوتية بالمايكروفون 🎙️"
              >
                <Mic size={19} />
              </button>
            </div>

            {/* Circular Send / Voice recording action button */}
            {text.trim() ? (
              <button
                onClick={handleSend}
                className={`w-11 h-11 flex items-center justify-center rounded-full shadow-lg transition-all active:scale-90 cursor-pointer shrink-0 ${accentSendBtn[accent]}`}
                title="إرسال (Enter)"
              >
                <Send size={18} className="rotate-180 fill-current ml-0.5" />
              </button>
            ) : (
              <button
                onClick={startRecording}
                className="w-11 h-11 flex items-center justify-center rounded-full bg-slate-900 border border-slate-800 text-slate-300 hover:text-cyan-400 hover:border-cyan-500/40 hover:bg-slate-800 transition-all active:scale-90 shadow-md cursor-pointer shrink-0"
                title="تسجيل رسالة صوتية"
              >
                <Mic size={19} />
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
